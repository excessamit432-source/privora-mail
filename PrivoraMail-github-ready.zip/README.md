# PRIVORA MAIL: Privacy Without Compromise.

Android email client (Kotlin, Jetpack Compose, Material 3). **Development build 0.1.0: foundation step.**

## Status (read this first)

**v0.3.0: PRIVORA-only.** The app no longer signs in to Gmail or other providers. It signs in to YOUR PRIVORA server
(`mail.<domain>`), where the domain is the single Gradle property `privoraDomain` (default `privora.email`). Build for another domain with
`gradle assembleDebug -PprivoraDomain=yourdomain.tld`.

| Area | State |
|---|---|
| Design system, icons, onboarding, themes, motion, app lock, screenshot protection | Built; v0.1 confirmed on a phone |
| PRIVORA sign-in, create/unlock encryption key (Argon2id-protected OpenPGP), key fingerprint, change passphrase | Written in v0.3.0, **compiled only by CI** |
| End-to-end encrypted send/read between PRIVORA users, signature verification, honest badges | Written in v0.3.0; round-trip unit tests included (run in CI), **untested against a live server** |
| Needs the server kit (separate zip) running on a domain you own | Required for anything to work |
| Attachments, drafts, rich text, notifications, offline cache, Drive | Not built |
| Two-step login, security keys, recovery email/phone, sign-up | Need server features, not built |

## Build

1. Install Android Studio (current stable) with JDK 17+ and the Android SDK (API 35).
2. Open this folder. Studio will create the Gradle wrapper. (CLI alternative: `gradle wrapper --gradle-version 8.10.2`.)
3. **Bump versions** in `gradle/libs.versions.toml` to the latest stable. They were pinned offline from memory and are likely stale.
4. Run `./gradlew testDebugUnitTest` (contrast and motion tests), then `./gradlew installDebug`.
5. Release signing is intentionally not configured. Supply your own keystore; never commit it (`.gitignore` blocks `*.jks`, `*.keystore`).

## Architecture (current)

Single module `:app`, split by package: `core/design` (design system), `core/data` (settings), `ui/*` (screens).
MVVM with unidirectional state (`AppViewModel` exposes `StateFlow<AppSettings?>`). `null` means real startup work is still running.
Manual DI via `PrivoraApplication`. Hilt, Room and a networking layer arrive with the mail data layer.
*Change from the earlier plan:* the multi-module split (`core:*`, `feature:*`) is deferred until feature code exists, to keep an uncompiled first step low-risk.

Chosen backend direction (pending owner confirmation): **IMAP/SMTP + OAuth for existing accounts in the MVP**, behind a `MailRepository` interface so an own-platform backend can be added later.

## Design notes

- Brand palette is used as specified. Where it fails WCAG AA, tuned companions are used and documented in `Color.kt` (`Derived`).
  Raw Electric Blue under white text is 3.95:1, so buttons use `#1264E6`. Cyan is not used as text in light theme.
- Motion durations follow the spec. Full, Reduced and Minimal modes exist, and the Android system "remove animations" setting overrides the in-app choice.
- The logo is shown unmodified on its navy tile. Adaptive foreground = tile feathered into `#04081F`; no recolouring or redrawing.

## Known limitations

- Source logo is 450x440 px: below the 512 px Play Store size (`play_store_icon_512.png` is upscaled, so supply a vector or 1024 px master before release).
- No themed (monochrome) launcher icon: it needs a silhouette variant of the logo, and the approved logo must not be redrawn without sign-off.
- System fonts only; a licensed typeface should be bundled.
- Mockup items intentionally NOT reproduced because they would be false today: "End-to-end encryption for all emails", storage 78%/15.6 GB, "Privacy Score 98%", Premium plan/Upgrade, sample Google/Dropbox mail.
- Onboarding "Sign In / Create Account" buttons are deferred to the auth step (no inert buttons).
- `material-icons-extended` is a large dependency (R8 trims it in release builds).
- Indeterminate loader keeps animating in Minimal motion mode (it is a status indicator).

## Next steps

1. Owner decisions: IMAP/SMTP+OAuth for MVP, privacy-copy rules, a higher-resolution logo master.
2. Auth + account model (Keystore-backed token storage), `MailRepository`, Room + SQLCipher.
3. Inbox, reading, compose, search against a real account.
See `docs/SECURITY.md` for the security statement.

## Build the APK without Android Studio (GitHub Actions)
1. Create a new GitHub repository and upload everything in this folder (including the hidden `.github` folder).
2. Open the repo's **Actions** tab, then **Build APK**, then **Run workflow**. (It also runs on every push to `main`.)
3. When the run finishes (about 5-10 minutes), open it and download **PrivoraMail-debug-apk** from Artifacts. Unzip it to get `app-debug.apk`.
4. Copy the APK to your phone, allow "install unknown apps" for your file manager or browser, and install.
This is a *debug* build (signed with the standard debug key). A release/Play Store build needs your own signing key.

## Licence
AGPL-3.0-or-later. See `LICENSE-NOTICE.md` (it explains how to add the official LICENSE text on GitHub in one step).
