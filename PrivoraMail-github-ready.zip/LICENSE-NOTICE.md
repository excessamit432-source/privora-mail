# Licence

PRIVORA MAIL (the Android app) and the PRIVORA server kit (key directory, deployment files, tools) are free software,
licensed under the **GNU Affero General Public License, version 3 or (at your option) any later version**
(SPDX: `AGPL-3.0-or-later`).

## Add the official licence text (one step, on GitHub)
GitHub can add the exact, unmodified text for you, so nothing has to be copied by hand:
1. In your repository tap **Add file, then Create new file**.
2. Type the file name `LICENSE`.
3. Tap **Choose a license template**, pick **GNU Affero General Public License v3.0**, then commit.
Do this in BOTH repositories (the app and the server kit).

## What AGPL-3.0 means for you
- Anyone may use, study, modify and share the code. Modified versions must also be AGPL-3.0.
- **Network clause (section 13):** if you run a modified version as a service that users interact with over a network, you must offer those users the source of your modified version.
- Keep the licence headers in source files. Put the real name or organisation of the copyright holder in place of "The PRIVORA MAIL authors" if you want it on record.

## Third-party components (their own licences apply)
| Component | Licence (verify before release) |
|---|---|
| Bouncy Castle (OpenPGP, Argon2) | MIT-style (Bouncy Castle licence) |
| JavaMail for Android (android-mail) | CDDL-1.0 / GPL-2.0 with Classpath Exception (needs a licence review for AGPL distribution) |
| AndroidX, Jetpack Compose, Material 3 | Apache-2.0 |
| Stalwart Mail Server (server, separate program) | AGPL-3.0 (also offered commercially) |
| Caddy (server, separate program) | Apache-2.0 |

## Distribution notes
- As sole copyright holder you may publish the app on app stores. Outside contributors would need to agree to a contributor licence before you can do that for their code.
- This is not legal advice. Have the JavaMail and app-store questions reviewed before a public release.
