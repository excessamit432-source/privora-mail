package app.privora.mail.ui.splash

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.fadeIn
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import app.privora.mail.core.design.Brand
import app.privora.mail.core.design.MotionTokens
import app.privora.mail.core.design.Privora
import app.privora.mail.core.design.PrivoraEasing
import app.privora.mail.core.design.PrivoraLogo
import app.privora.mail.core.design.Spacing
import kotlinx.coroutines.delay

// The splash is always dark brand navy (matches the system splash and Asset 2) regardless of app theme.
private val SplashText = Color(0xFFF2F4FF)
private val SplashMuted = Color(0xFFA9B2D6)
private val WordmarkBrush = Brush.horizontalGradient(listOf(Brand.Violet, Brand.ElectricBlue, Brand.Cyan))

/**
 * Shown ONLY while startup work (reading preferences) is actually in progress. It has no timer of its own:
 * it leaves composition the moment loading finishes. The loader appears only if loading exceeds 400 ms,
 * which avoids flicker on fast starts and is not a delay to anything.
 */
@Composable
fun SplashScreen() {
    val motion = Privora.motion
    val entrance = remember { Animatable(if (motion.allowsDecorativeMotion) 0f else 1f) }
    LaunchedEffect(Unit) {
        entrance.animateTo(1f, motion.tween(MotionTokens.Entrance, PrivoraEasing.EmphasizedDecelerate))
    }
    var showLoader by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(400)
        showLoader = true
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brand.MidnightNavy)
            .drawBehind {
                drawRect(
                    Brush.radialGradient(
                        colors = listOf(Brand.ElectricBlue.copy(alpha = 0.22f), Color.Transparent),
                        center = Offset(size.width * 0.5f, size.height * 0.42f),
                        radius = size.width * 0.9f,
                    )
                )
            },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.graphicsLayer {
                alpha = entrance.value
                val scale = if (motion.allowsDecorativeMotion) 0.92f + 0.08f * entrance.value else 1f
                scaleX = scale
                scaleY = scale
            },
        ) {
            PrivoraLogo(size = 144.dp, decorative = true)
            Spacer(Modifier.height(Spacing.xxl))
            Row(modifier = Modifier.semantics(mergeDescendants = true) {}) {
                Text("PRIVORA ", style = MaterialTheme.typography.headlineLarge.copy(color = SplashText))
                Text("MAIL", style = MaterialTheme.typography.headlineLarge.copy(brush = WordmarkBrush))
            }
            Spacer(Modifier.height(Spacing.sm))
            Text(
                "Privacy Without Compromise.",
                style = MaterialTheme.typography.bodyLarge,
                color = SplashMuted,
            )
        }

        AnimatedVisibility(
            visible = showLoader,
            enter = fadeIn(motion.tween(MotionTokens.Micro)),
            modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 48.dp),
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(Spacing.md)) {
                CircularProgressIndicator(color = Brand.Cyan, strokeWidth = 2.dp, modifier = Modifier.size(24.dp))
                Text("Loading your secure space…", style = MaterialTheme.typography.bodySmall, color = SplashMuted)
            }
        }
    }
}
