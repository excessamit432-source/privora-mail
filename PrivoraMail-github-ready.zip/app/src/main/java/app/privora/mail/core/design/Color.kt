// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (C) 2026 The PRIVORA MAIL authors. See LICENSE-NOTICE.md.
package app.privora.mail.core.design

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/** Official brand palette (from the product specification). Never alter these values. */
object Brand {
    val Violet = Color(0xFF7567F8)
    val ElectricBlue = Color(0xFF167BFF)
    val Cyan = Color(0xFF48C8FF)
    val Purple = Color(0xFF5635FF)
    val NeonPurple = Color(0xFFA000F5)
    val MidnightNavy = Color(0xFF080D24)
}

/**
 * Accessibility-derived tokens. Brand colors alone miss WCAG AA in places
 * (e.g. white on #167BFF = 3.95:1, Cyan on white = 1.9:1), so these are tuned companions.
 * Ratios are asserted in ContrastTest.
 */
internal object Derived {
    val ButtonBlue = Color(0xFF1264E6)      // white on it: ~5.3:1 (brand ElectricBlue gives 3.95:1)
    val VioletLight = Color(0xFF9A90FF)     // violet usable as text on dark surfaces (>=5.1:1)
    val BlueOnLight = Color(0xFF0B5ED7)     // blue text/icons on light surfaces (~5.4:1)
}

internal val DarkScheme: ColorScheme = darkColorScheme(
    primary = Derived.ButtonBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF1A2F6B),
    onPrimaryContainer = Color(0xFFDCE6FF),
    secondary = Brand.Cyan,
    onSecondary = Brand.MidnightNavy,
    secondaryContainer = Color(0xFF12304A),
    onSecondaryContainer = Color(0xFFD2F1FF),
    tertiary = Derived.VioletLight,
    onTertiary = Brand.MidnightNavy,
    tertiaryContainer = Color(0xFF2E2680),
    onTertiaryContainer = Color(0xFFE6E2FF),
    background = Brand.MidnightNavy,
    onBackground = Color(0xFFF2F4FF),
    surface = Color(0xFF11182A),
    onSurface = Color(0xFFF2F4FF),
    surfaceVariant = Color(0xFF1A2340),
    onSurfaceVariant = Color(0xFFA9B2D6),
    surfaceContainerLowest = Brand.MidnightNavy,
    surfaceContainerLow = Color(0xFF11182A),
    surfaceContainer = Color(0xFF1A2340),
    surfaceContainerHigh = Color(0xFF202B4A),
    surfaceContainerHighest = Color(0xFF28345A),
    outline = Color(0xFF6674B0),            // >=3:1 for UI component boundaries
    outlineVariant = Color(0xFF2A3558),     // decorative dividers only
    error = Color(0xFFFF6B7A),
    onError = Color(0xFF2B0007),
)

internal val LightScheme: ColorScheme = lightColorScheme(
    primary = Derived.BlueOnLight,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDCE6FF),
    onPrimaryContainer = Color(0xFF001B4D),
    secondary = Brand.Purple,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE5E0FF),
    onSecondaryContainer = Color(0xFF1B0A6B),
    tertiary = Brand.NeonPurple,
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFF6D9FF),
    onTertiaryContainer = Color(0xFF3A0057),
    background = Color(0xFFF5F6FC),
    onBackground = Color(0xFF141A33),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF141A33),
    surfaceVariant = Color(0xFFF0F1FA),
    onSurfaceVariant = Color(0xFF4A5378),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFF8F9FE),
    surfaceContainer = Color(0xFFF0F1FA),
    surfaceContainerHigh = Color(0xFFE8EAF6),
    surfaceContainerHighest = Color(0xFFE0E3F2),
    outline = Color(0xFF6B7499),
    outlineVariant = Color(0xFFD5D9EE),
    error = Color(0xFFB3261E),
    onError = Color.White,
)

/** Tokens Material 3 has no slot for. Read via `Privora.extras`. */
@Immutable
class PrivoraExtras(
    val isDark: Boolean,
    val success: Color,
    val warning: Color,
    val info: Color,
    val textTertiary: Color,
    val border: Color,
    val accentBrush: Brush,   // primary buttons / FAB
    val brandBrush: Brush,    // wordmark, highlights
    val glow: Color,          // soft backdrop light
)

internal val DarkExtras = PrivoraExtras(
    isDark = true,
    success = Color(0xFF3DDC97),
    warning = Color(0xFFFFB84D),
    info = Brand.Cyan,
    textTertiary = Color(0xFF8791BA),
    border = Color(0xFF2A3558),
    accentBrush = Brush.horizontalGradient(listOf(Brand.Purple, Derived.ButtonBlue)),
    brandBrush = Brush.horizontalGradient(listOf(Brand.Violet, Brand.ElectricBlue, Brand.Cyan)),
    glow = Brand.ElectricBlue.copy(alpha = 0.20f),
)

internal val LightExtras = PrivoraExtras(
    isDark = false,
    success = Color(0xFF0F7B4F),
    warning = Color(0xFF8A5300),
    info = Derived.BlueOnLight,
    textTertiary = Color(0xFF5C6589),
    border = Color(0xFFD5D9EE),
    accentBrush = Brush.horizontalGradient(listOf(Brand.Purple, Derived.ButtonBlue)),
    brandBrush = Brush.horizontalGradient(listOf(Brand.Purple, Derived.BlueOnLight)),
    glow = Brand.Violet.copy(alpha = 0.10f),
)
