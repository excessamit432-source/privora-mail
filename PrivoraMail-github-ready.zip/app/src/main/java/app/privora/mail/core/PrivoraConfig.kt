// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (C) 2026 The PRIVORA MAIL authors. See LICENSE-NOTICE.md.
package app.privora.mail.core

import app.privora.mail.BuildConfig

/** Everything that depends on the PRIVORA domain, derived from the single `privoraDomain` Gradle property. */
object PrivoraConfig {
    val DOMAIN: String = BuildConfig.PRIVORA_DOMAIN.lowercase()
    val IMAP_HOST = "mail.$DOMAIN"
    const val IMAP_PORT = 993        // implicit TLS
    val SMTP_HOST = "mail.$DOMAIN"
    const val SMTP_PORT = 465        // implicit TLS
    val KEYS_URL = "https://keys.$DOMAIN"

    /** Accepts "alice" or "alice@domain"; returns the full address or null if it belongs to another domain. */
    fun normalizeAddress(input: String): String? {
        val t = input.trim().lowercase()
        if (t.isEmpty()) return null
        val full = if (t.contains('@')) t else "$t@$DOMAIN"
        return if (full.endsWith("@$DOMAIN") && full.substringBefore('@').isNotEmpty()) full else null
    }

    fun isPrivoraAddress(address: String): Boolean = address.trim().lowercase().endsWith("@$DOMAIN")
}
