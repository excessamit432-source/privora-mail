// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (C) 2026 The PRIVORA MAIL authors. See LICENSE-NOTICE.md.
package app.privora.mail.core.crypto

import app.privora.mail.core.mail.MailException
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.Base64

/**
 * Talks to the PRIVORA key directory over HTTPS (system trust store; cleartext is blocked app-wide).
 * Blocking calls: use from Dispatchers.IO. Credentials are only sent as an HTTP Basic header to the PRIVORA server.
 */
class KeyDirectoryClient(private val baseUrl: String) {

    private class Reply(val code: Int, val body: String)

    private fun call(method: String, path: String, auth: Pair<String, String>?, json: JSONObject?): Reply {
        val conn = URL(baseUrl + path).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = method
            conn.connectTimeout = 15000
            conn.readTimeout = 20000
            conn.instanceFollowRedirects = false
            if (auth != null) {
                val token = Base64.getEncoder().encodeToString("${auth.first}:${auth.second}".toByteArray(Charsets.UTF_8))
                conn.setRequestProperty("Authorization", "Basic $token")
            }
            if (json != null) {
                val bytes = json.toString().toByteArray(Charsets.UTF_8)
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json")
                conn.setFixedLengthStreamingMode(bytes.size)
                conn.outputStream.use { it.write(bytes) }
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            return Reply(code, stream?.bufferedReader()?.use { it.readText() }.orEmpty())
        } catch (e: IOException) {
            throw MailException(MailException.Kind.Network, "Could not reach the PRIVORA key service. Check your connection.")
        } finally {
            conn.disconnect()
        }
    }

    private fun fail(r: Reply, what: String): Nothing {
        val detail = runCatching { JSONObject(r.body).optString("error") }.getOrNull().orEmpty()
        val kind = if (r.code == 401 || r.code == 403 || r.code == 429) MailException.Kind.Auth else MailException.Kind.Server
        throw MailException(kind, "$what failed (${r.code})" + if (detail.isNotEmpty()) ": $detail" else ".")
    }

    /** Anyone's public key (no login needed); null if that address hasn't published one. */
    fun getPublicKey(email: String): String? {
        val r = call("GET", "/v1/keys/${email.lowercase()}", null, null)
        return when (r.code) {
            200 -> JSONObject(r.body).getString("public_key")
            404 -> null
            else -> fail(r, "Looking up a public key")
        }
    }

    /** Your own encrypted key backup (opaque to the server); null if you've never set one up. */
    fun getBackup(email: String, password: String): String? {
        val r = call("GET", "/v1/backup", email.lowercase() to password, null)
        return when (r.code) {
            200 -> JSONObject(r.body).getString("encrypted_private_key")
            404 -> null
            else -> fail(r, "Fetching your key backup")
        }
    }

    fun publish(email: String, password: String, publicArmored: String, backupBlob: String) {
        val body = JSONObject().put("public_key", publicArmored).put("encrypted_private_key", backupBlob)
        val r = call("PUT", "/v1/keys", email.lowercase() to password, body)
        if (r.code != 200) fail(r, "Publishing your key")
    }
}
