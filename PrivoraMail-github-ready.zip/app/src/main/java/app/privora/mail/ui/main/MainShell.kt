package app.privora.mail.ui.main

import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Mail
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.outlined.AllInbox
import androidx.compose.material.icons.outlined.Cloud
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Drafts
import androidx.compose.material.icons.outlined.Inbox
import androidx.compose.material.icons.outlined.Mail
import androidx.compose.material.icons.outlined.Report
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import app.privora.mail.AppViewModel
import app.privora.mail.core.data.AppSettings
import app.privora.mail.core.design.MotionTokens
import app.privora.mail.core.design.Privora
import app.privora.mail.core.design.PrivoraAvatar
import app.privora.mail.core.design.PrivoraBackdrop
import app.privora.mail.core.design.PrivoraLogo
import app.privora.mail.core.design.Spacing
import app.privora.mail.ui.drive.DriveScreen
import app.privora.mail.ui.mail.AddAccountScreen
import app.privora.mail.ui.mail.ComposeDraft
import app.privora.mail.ui.mail.ComposeScreen
import app.privora.mail.ui.mail.Drafts
import app.privora.mail.ui.mail.MailScreen
import app.privora.mail.ui.mail.MailUiState
import app.privora.mail.ui.mail.MailViewModel
import app.privora.mail.ui.mail.MessageScreen
import app.privora.mail.ui.privacy.PrivacyScreen
import app.privora.mail.ui.settings.SettingsScreen
import kotlinx.coroutines.launch

enum class MainTab(val label: String, val icon: ImageVector, val selectedIcon: ImageVector) {
    Mail("Mail", Icons.Outlined.Mail, Icons.Filled.Mail),
    Drive("Drive", Icons.Outlined.Cloud, Icons.Filled.Cloud),
    Privacy("Privacy", Icons.Outlined.Shield, Icons.Filled.Shield),
    Settings("Settings", Icons.Outlined.Settings, Icons.Filled.Settings),
}

enum class MailFolder(val label: String, val icon: ImageVector) {
    Inbox("Inbox", Icons.Outlined.Inbox),
    AllMail("All Mail", Icons.Outlined.AllInbox),
    Starred("Starred", Icons.Outlined.StarBorder),
    Sent("Sent", Icons.AutoMirrored.Outlined.Send),
    Drafts("Drafts", Icons.Outlined.Drafts),
    Spam("Spam", Icons.Outlined.Report),
    Trash("Trash", Icons.Outlined.Delete),
}

private sealed interface Overlay {
    data object AddAccount : Overlay
    data class Compose(val draft: ComposeDraft) : Overlay
}

@Composable
fun MainShell(settings: AppSettings, appVm: AppViewModel) {
    val mailVm: MailViewModel = viewModel(factory = MailViewModel.Factory)
    val mail by mailVm.state.collectAsStateWithLifecycle()

    var tab by rememberSaveable { mutableStateOf(MainTab.Mail) }
    var overlay by remember { mutableStateOf<Overlay?>(null) }
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val motion = Privora.motion
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(mail.notice) {
        val text = mail.notice
        if (text != null) {
            snackbar.showSnackbar(text)
            mailVm.consumeNotice()
        }
    }
    BackHandler(enabled = drawerState.isOpen) { scope.launch { drawerState.close() } }

    Box(Modifier.fillMaxSize()) {
        ModalNavigationDrawer(
            drawerState = drawerState,
            gesturesEnabled = tab == MainTab.Mail || drawerState.isOpen,
            drawerContent = {
                DrawerContent(
                    mail = mail,
                    tab = tab,
                    onFolder = { tab = MainTab.Mail; mailVm.setFolder(it); scope.launch { drawerState.close() } },
                    onTab = { tab = it; scope.launch { drawerState.close() } },
                    onSwitchAccount = { mailVm.setActive(it); tab = MainTab.Mail; scope.launch { drawerState.close() } },
                    onAddAccount = { overlay = Overlay.AddAccount; scope.launch { drawerState.close() } },
                )
            },
        ) {
            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                snackbarHost = { SnackbarHost(snackbar) },
                bottomBar = {
                    NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceContainerLow) {
                        MainTab.entries.forEach { item ->
                            NavigationBarItem(
                                selected = tab == item,
                                onClick = { tab = item },
                                icon = { Icon(if (tab == item) item.selectedIcon else item.icon, contentDescription = null) },
                                label = { Text(item.label) },
                                colors = NavigationBarItemDefaults.colors(
                                    indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                                    selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                                    selectedTextColor = MaterialTheme.colorScheme.onSurface,
                                ),
                            )
                        }
                    }
                },
            ) { padding ->
                PrivoraBackdrop(Modifier.padding(padding)) {
                    Crossfade(targetState = tab, animationSpec = motion.tween(MotionTokens.Screen), label = "main-tab") { current ->
                        when (current) {
                            MainTab.Mail -> MailScreen(
                                state = mail,
                                onOpenDrawer = { scope.launch { drawerState.open() } },
                                onRefresh = mailVm::refresh,
                                onQuery = mailVm::setQuery,
                                onOpen = mailVm::open,
                                onToggleStar = mailVm::toggleStar,
                                onCompose = { overlay = Overlay.Compose(Drafts.new(settings.signature)) },
                                onAddAccount = { overlay = Overlay.AddAccount },
                            )
                            MainTab.Drive -> DriveScreen()
                            MainTab.Privacy -> PrivacyScreen(settings, mail.accounts.size)
                            MainTab.Settings -> SettingsScreen(
                                settings = settings,
                                mail = mail,
                                appVm = appVm,
                                mailVm = mailVm,
                                onAddAccount = { overlay = Overlay.AddAccount },
                            )
                        }
                    }
                }
            }
        }

        // ----- full-screen overlays (later ones sit on top and handle Back first) -----
        val detail = mail.detail
        if (detail != null) {
            OverlaySurface {
                MessageScreen(
                    detail = detail,
                    confirmDelete = settings.confirmDelete,
                    onBack = mailVm::closeDetail,
                    onToggleStar = { mailVm.toggleStar(detail.header) },
                    onDelete = { mailVm.delete(detail.header) },
                    onMarkUnread = { mailVm.markUnread(detail.header) },
                    onReply = { all ->
                        val b = detail.body
                        if (b != null) overlay = Overlay.Compose(Drafts.reply(b, all, mail.active?.email.orEmpty(), settings.signature))
                    },
                    onForward = {
                        val b = detail.body
                        if (b != null) overlay = Overlay.Compose(Drafts.forward(b, settings.signature))
                    },
                )
            }
        }

        val current = overlay
        val account = mail.active
        if (current is Overlay.Compose && account != null) {
            OverlaySurface {
                ComposeScreen(
                    account = account,
                    initial = current.draft,
                    sending = mail.sending,
                    error = mail.sendError,
                    onSend = { m -> mailVm.send(m) { overlay = null } },
                    onClose = { overlay = null; mailVm.dismissSendError() },
                    onDismissError = mailVm::dismissSendError,
                )
            }
        }
        if (current is Overlay.AddAccount) {
            OverlaySurface {
                AddAccountScreen(
                    connecting = mail.connecting,
                    error = mail.connectError,
                    onConnect = { input -> mailVm.addAccount(input) { overlay = null } },
                    onClose = { overlay = null; mailVm.dismissConnectError() },
                    onDismissError = mailVm::dismissConnectError,
                )
            }
        }
    }
}

@Composable
private fun OverlaySurface(content: @Composable () -> Unit) {
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        PrivoraBackdrop {
            Box(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) { content() }
        }
    }
}

@Composable
private fun DrawerContent(
    mail: MailUiState,
    tab: MainTab,
    onFolder: (MailFolder) -> Unit,
    onTab: (MainTab) -> Unit,
    onSwitchAccount: (String) -> Unit,
    onAddAccount: () -> Unit,
) {
    val itemPadding = NavigationDrawerItemDefaults.ItemPadding
    ModalDrawerSheet(drawerContainerColor = MaterialTheme.colorScheme.surface) {
        Column(Modifier.verticalScroll(rememberScrollState())) {
            Row(Modifier.padding(Spacing.xl), verticalAlignment = Alignment.CenterVertically) {
                PrivoraLogo(size = 48.dp, decorative = true)
                Spacer(Modifier.width(Spacing.md))
                Column {
                    Text("PRIVORA MAIL", style = MaterialTheme.typography.titleMedium)
                    Text(
                        mail.active?.email ?: "No account connected",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            HorizontalDivider(color = Privora.extras.border, modifier = Modifier.padding(vertical = Spacing.sm))

            mail.accounts.forEach { a ->
                NavigationDrawerItem(
                    label = { Text(a.email, maxLines = 1) },
                    icon = { PrivoraAvatar(a.shortName, 28.dp) },
                    selected = a.id == mail.active?.id,
                    onClick = { onSwitchAccount(a.id) },
                    modifier = Modifier.padding(itemPadding),
                )
            }
            NavigationDrawerItem(
                label = { Text("Add account") },
                icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                selected = false,
                onClick = onAddAccount,
                modifier = Modifier.padding(itemPadding),
            )
            HorizontalDivider(color = Privora.extras.border, modifier = Modifier.padding(vertical = Spacing.sm))

            if (mail.active != null) {
                MailFolder.entries.forEach { f ->
                    NavigationDrawerItem(
                        label = { Text(f.label) },
                        icon = { Icon(f.icon, contentDescription = null) },
                        selected = tab == MainTab.Mail && mail.folder == f,
                        onClick = { onFolder(f) },
                        modifier = Modifier.padding(itemPadding),
                    )
                }
                HorizontalDivider(color = Privora.extras.border, modifier = Modifier.padding(vertical = Spacing.sm))
            }

            listOf(MainTab.Drive to "Drive", MainTab.Privacy to "Privacy Center", MainTab.Settings to "Settings")
                .forEach { (target, label) ->
                    NavigationDrawerItem(
                        label = { Text(label) },
                        icon = { Icon(target.icon, contentDescription = null) },
                        selected = tab == target,
                        onClick = { onTab(target) },
                        modifier = Modifier.padding(itemPadding),
                    )
                }
            // Intentionally absent until real: Snoozed, custom folders, Help & Support, Premium plan.
        }
    }
}
