package app.privora.mail.ui.main

import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Send
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Mail
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.outlined.AllInbox
import androidx.compose.material.icons.outlined.Cloud
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Drafts
import androidx.compose.material.icons.outlined.Inbox
import androidx.compose.material.icons.outlined.Mail
import androidx.compose.material.icons.outlined.Report
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.outlined.Snooze
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import app.privora.mail.AppViewModel
import app.privora.mail.core.data.AppSettings
import app.privora.mail.core.design.MotionTokens
import app.privora.mail.core.design.Privora
import app.privora.mail.core.design.PrivoraBackdrop
import app.privora.mail.core.design.PrivoraLogo
import app.privora.mail.core.design.Spacing
import app.privora.mail.ui.drive.DriveScreen
import app.privora.mail.ui.mail.MailScreen
import app.privora.mail.ui.privacy.PrivacyScreen
import app.privora.mail.ui.settings.SettingsScreen
import kotlinx.coroutines.launch

enum class MainTab(val label: String, val icon: ImageVector, val selectedIcon: ImageVector) {
    Mail("Mail", Icons.Outlined.Mail, Icons.Filled.Mail),
    Drive("Drive", Icons.Outlined.Cloud, Icons.Filled.Cloud),
    Privacy("Privacy", Icons.Outlined.Shield, Icons.Filled.Shield),
    Settings("Settings", Icons.Outlined.Settings, Icons.Filled.Settings),
}

enum class MailFolder(val label: String, val icon: ImageVector) {
    Inbox("Inbox", Icons.Outlined.Inbox),
    AllMail("All Mail", Icons.Outlined.AllInbox),
    Starred("Starred", Icons.Outlined.StarBorder),
    Snoozed("Snoozed", Icons.Outlined.Snooze),
    Sent("Sent", Icons.AutoMirrored.Outlined.Send),
    Drafts("Drafts", Icons.Outlined.Drafts),
    Spam("Spam", Icons.Outlined.Report),
    Trash("Trash", Icons.Outlined.Delete),
}

@Composable
fun MainShell(settings: AppSettings, viewModel: AppViewModel) {
    var tab by rememberSaveable { mutableStateOf(MainTab.Mail) }
    var folder by rememberSaveable { mutableStateOf(MailFolder.Inbox) }
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val motion = Privora.motion

    BackHandler(enabled = drawerState.isOpen) { scope.launch { drawerState.close() } }

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = tab == MainTab.Mail || drawerState.isOpen,
        drawerContent = {
            DrawerContent(
                tab = tab,
                folder = folder,
                onFolder = { tab = MainTab.Mail; folder = it; scope.launch { drawerState.close() } },
                onTab = { tab = it; scope.launch { drawerState.close() } },
            )
        },
    ) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceContainerLow) {
                    MainTab.entries.forEach { item ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item },
                            icon = { Icon(if (tab == item) item.selectedIcon else item.icon, contentDescription = null) },
                            label = { Text(item.label) },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                                selectedTextColor = MaterialTheme.colorScheme.onSurface,
                            ),
                        )
                    }
                }
            },
        ) { padding ->
            PrivoraBackdrop(Modifier.padding(padding)) {
                Crossfade(
                    targetState = tab,
                    animationSpec = motion.tween(MotionTokens.Screen),
                    label = "main-tab",
                ) { current ->
                    when (current) {
                        MainTab.Mail -> MailScreen(
                            folder = folder,
                            onOpenDrawer = { scope.launch { drawerState.open() } },
                        )
                        MainTab.Drive -> DriveScreen()
                        MainTab.Privacy -> PrivacyScreen()
                        MainTab.Settings -> SettingsScreen(
                            settings = settings,
                            onTheme = viewModel::setTheme,
                            onMotion = viewModel::setMotion,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DrawerContent(
    tab: MainTab,
    folder: MailFolder,
    onFolder: (MailFolder) -> Unit,
    onTab: (MainTab) -> Unit,
) {
    val itemPadding = NavigationDrawerItemDefaults.ItemPadding
    ModalDrawerSheet(drawerContainerColor = MaterialTheme.colorScheme.surface) {
        Column(Modifier.verticalScroll(rememberScrollState())) {
            Row(
                Modifier.padding(Spacing.xl),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                PrivoraLogo(size = 48.dp, decorative = true)
                Spacer(Modifier.width(Spacing.md))
                Column {
                    Text("PRIVORA MAIL", style = MaterialTheme.typography.titleMedium)
                    // Truthful until accounts exist (next step): replace with the real account profile + switcher.
                    Text(
                        "No account connected",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            HorizontalDivider(color = Privora.extras.border, modifier = Modifier.padding(vertical = Spacing.sm))

            MailFolder.entries.forEach { f ->
                NavigationDrawerItem(
                    label = { Text(f.label) },
                    icon = { Icon(f.icon, contentDescription = null) },
                    selected = tab == MainTab.Mail && folder == f,
                    onClick = { onFolder(f) },
                    modifier = Modifier.padding(itemPadding),
                )
            }
            HorizontalDivider(color = Privora.extras.border, modifier = Modifier.padding(vertical = Spacing.sm))

            listOf(MainTab.Drive to "Drive", MainTab.Privacy to "Privacy Center", MainTab.Settings to "Settings")
                .forEach { (target, label) ->
                    NavigationDrawerItem(
                        label = { Text(label) },
                        icon = { Icon(target.icon, contentDescription = null) },
                        selected = tab == target,
                        onClick = { onTab(target) },
                        modifier = Modifier.padding(itemPadding),
                    )
                }
            // Intentionally absent until they are real: custom folders, account switcher,
            // Help & Support, Premium/Manage plan.
        }
    }
}
