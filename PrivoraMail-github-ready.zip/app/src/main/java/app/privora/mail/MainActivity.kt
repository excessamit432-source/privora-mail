package app.privora.mail

import android.os.Bundle
import android.os.SystemClock
import android.view.WindowManager
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.CompositionLocalProvider
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import app.privora.mail.core.security.Authenticator
import app.privora.mail.core.security.LocalAuthenticator
import app.privora.mail.ui.PrivoraApp
import kotlinx.coroutines.launch

// FragmentActivity (a ComponentActivity subclass) is required by the system biometric prompt.
class MainActivity : FragmentActivity() {
    private val viewModel: AppViewModel by viewModels { AppViewModel.Factory }
    private lateinit var authenticator: Authenticator
    private var stoppedAt = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        authenticator = Authenticator(this)

        // Block screenshots + hide content in the app switcher when the user turns that on.
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.settings.collect { s ->
                    if (s?.blockScreenshots == true) window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
                    else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                }
            }
        }

        setContent {
            CompositionLocalProvider(LocalAuthenticator provides authenticator) {
                PrivoraApp(viewModel)
            }
        }
    }

    override fun onStop() {
        super.onStop()
        // The system unlock prompt can stop the activity briefly; that is not "leaving the app".
        if (!authenticator.inProgress) stoppedAt = SystemClock.elapsedRealtime()
    }

    override fun onStart() {
        super.onStart()
        if (stoppedAt != 0L) {
            viewModel.onReturned(SystemClock.elapsedRealtime() - stoppedAt)
            stoppedAt = 0L
        }
    }
}
