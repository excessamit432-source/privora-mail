// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (C) 2026 The PRIVORA MAIL authors. See LICENSE-NOTICE.md.
package app.privora.mail.core.design

import android.provider.Settings
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.Easing
import androidx.compose.animation.core.TweenSpec
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.platform.LocalContext

/** User-selectable motion level (spec section 13). */
enum class MotionMode { Full, Reduced, Minimal }

/** Base durations in ms, from the spec: micro 120-180, standard 250-300, screen 200-350. */
object MotionTokens {
    const val Micro = 150
    const val Standard = 270
    const val Screen = 300
    const val Entrance = 350
}

object PrivoraEasing {
    val EmphasizedDecelerate: Easing = CubicBezierEasing(0.05f, 0.7f, 0.1f, 1.0f)
    val Standard: Easing = CubicBezierEasing(0.2f, 0.0f, 0.0f, 1.0f)
}

@Immutable
class PrivoraMotion(val mode: MotionMode) {
    /** Full = as specified, Reduced = half duration and no decorative movement, Minimal = instant. */
    fun ms(base: Int): Int = when (mode) {
        MotionMode.Full -> base
        MotionMode.Reduced -> base / 2
        MotionMode.Minimal -> 0
    }

    /** Scale/translate/parallax style effects are only allowed in Full mode. */
    val allowsDecorativeMotion: Boolean get() = mode == MotionMode.Full

    fun <T> tween(base: Int, easing: Easing = PrivoraEasing.Standard): TweenSpec<T> =
        androidx.compose.animation.core.tween(durationMillis = ms(base), easing = easing)
}

val LocalMotion = staticCompositionLocalOf { PrivoraMotion(MotionMode.Full) }

/**
 * Honours Android's system "remove animations" setting: if animator scale is 0 the effective mode
 * is Minimal regardless of the in-app choice. Read once per composition entry.
 */
@Composable
fun rememberEffectiveMotionMode(userChoice: MotionMode): MotionMode {
    val resolver = LocalContext.current.contentResolver
    val systemScale = remember {
        Settings.Global.getFloat(resolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f)
    }
    return if (systemScale == 0f) MotionMode.Minimal else userChoice
}
