package app.privora.mail.ui.lock

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Fingerprint
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import app.privora.mail.core.security.LocalAuthenticator
import app.privora.mail.core.design.PrivoraBackdrop
import app.privora.mail.core.design.PrivoraGradientButton
import app.privora.mail.core.design.PrivoraLogo
import app.privora.mail.core.design.Spacing
import androidx.compose.ui.unit.dp

@Composable
fun LockScreen(onUnlocked: () -> Unit, onTurnOffLock: () -> Unit) {
    val auth = LocalAuthenticator.current
    val available = remember { auth?.canAuthenticate() == true }

    fun prompt() {
        auth?.authenticate("Unlock PRIVORA MAIL") { ok -> if (ok) onUnlocked() }
    }
    LaunchedEffect(Unit) { if (available) prompt() }

    PrivoraBackdrop {
        Column(
            Modifier.fillMaxSize().safeDrawingPadding().padding(Spacing.xxl),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            PrivoraLogo(size = 96.dp)
            Spacer(Modifier.height(Spacing.xxl))
            Text("PRIVORA MAIL is locked", style = MaterialTheme.typography.headlineSmall, textAlign = TextAlign.Center)
            Spacer(Modifier.height(Spacing.sm))
            if (available) {
                Text(
                    "Use your fingerprint, face, or screen lock to continue.",
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                )
                Spacer(Modifier.height(Spacing.xxl))
                PrivoraGradientButton("Unlock", onClick = { prompt() }, modifier = Modifier.fillMaxWidth(), leadingIcon = Icons.Outlined.Fingerprint)
            } else {
                Text(
                    "This device no longer has a screen lock or biometrics set up, so it can't verify you.",
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                )
                Spacer(Modifier.height(Spacing.xl))
                TextButton(onClick = onTurnOffLock) { Text("Turn off app lock") }
            }
        }
    }
}
