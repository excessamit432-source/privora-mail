// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (C) 2026 The PRIVORA MAIL authors. See LICENSE-NOTICE.md.
package app.privora.mail.core.crypto

import org.bouncycastle.bcpg.ArmoredOutputStream
import org.bouncycastle.bcpg.CompressionAlgorithmTags
import org.bouncycastle.bcpg.HashAlgorithmTags
import org.bouncycastle.bcpg.PublicKeyAlgorithmTags
import org.bouncycastle.bcpg.SymmetricKeyAlgorithmTags
import org.bouncycastle.bcpg.sig.KeyFlags
import org.bouncycastle.crypto.generators.Argon2BytesGenerator
import org.bouncycastle.crypto.generators.RSAKeyPairGenerator
import org.bouncycastle.crypto.params.Argon2Parameters
import org.bouncycastle.crypto.params.RSAKeyGenerationParameters
import org.bouncycastle.openpgp.PGPCompressedData
import org.bouncycastle.openpgp.PGPCompressedDataGenerator
import org.bouncycastle.openpgp.PGPEncryptedDataGenerator
import org.bouncycastle.openpgp.PGPEncryptedDataList
import org.bouncycastle.openpgp.PGPKeyRingGenerator
import org.bouncycastle.openpgp.PGPLiteralData
import org.bouncycastle.openpgp.PGPLiteralDataGenerator
import org.bouncycastle.openpgp.PGPOnePassSignature
import org.bouncycastle.openpgp.PGPOnePassSignatureList
import org.bouncycastle.openpgp.PGPObjectFactory
import org.bouncycastle.openpgp.PGPPrivateKey
import org.bouncycastle.openpgp.PGPPublicKey
import org.bouncycastle.openpgp.PGPPublicKeyEncryptedData
import org.bouncycastle.openpgp.PGPPublicKeyRing
import org.bouncycastle.openpgp.PGPSecretKeyRing
import org.bouncycastle.openpgp.PGPSignature
import org.bouncycastle.openpgp.PGPSignatureGenerator
import org.bouncycastle.openpgp.PGPSignatureList
import org.bouncycastle.openpgp.PGPSignatureSubpacketGenerator
import org.bouncycastle.openpgp.PGPSignatureSubpacketVector
import org.bouncycastle.openpgp.PGPUtil
import org.bouncycastle.openpgp.operator.PBESecretKeyDecryptor
import org.bouncycastle.openpgp.operator.bc.BcKeyFingerprintCalculator
import org.bouncycastle.openpgp.operator.bc.BcPBESecretKeyDecryptorBuilder
import org.bouncycastle.openpgp.operator.bc.BcPBESecretKeyEncryptorBuilder
import org.bouncycastle.openpgp.operator.bc.BcPGPContentSignerBuilder
import org.bouncycastle.openpgp.operator.bc.BcPGPContentVerifierBuilderProvider
import org.bouncycastle.openpgp.operator.bc.BcPGPDataEncryptorBuilder
import org.bouncycastle.openpgp.operator.bc.BcPGPDigestCalculatorProvider
import org.bouncycastle.openpgp.operator.bc.BcPGPKeyPair
import org.bouncycastle.openpgp.operator.bc.BcPublicKeyDataDecryptorFactory
import org.bouncycastle.openpgp.operator.bc.BcPublicKeyKeyEncryptionMethodGenerator
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.OutputStream
import java.math.BigInteger
import java.security.SecureRandom
import java.text.Normalizer
import java.util.Base64
import java.util.Date

class CryptoException(message: String) : Exception(message)
class WrongPassphraseException : Exception("Wrong encryption passphrase.")

/** A private key held IN MEMORY ONLY while the user has unlocked encryption. Never persisted. */
class UnlockedKey internal constructor(
    val email: String,
    internal val secretRing: PGPSecretKeyRing,
    val publicRing: PGPPublicKeyRing,
    internal val decryptor: PBESecretKeyDecryptor,
)

enum class Verification { None, Verified, Invalid, SignerUnknown }
class Decrypted(val text: String, val verification: Verification)
class NewKey(val publicArmored: String, val blobJson: String, val unlocked: UnlockedKey)

/**
 * OpenPGP for PRIVORA, built on Bouncy Castle's lightweight API (no JCA provider registration needed on Android).
 *
 * Key protection (zero-knowledge backup): the encryption passphrase is stretched with Argon2id (64 MiB, 3 passes, random salt)
 * into a 256-bit secret that protects the OpenPGP private key (AES-256 S2K). Only that protected key + salt are
 * ever uploaded. The passphrase never leaves the device.
 */
object PrivoraCrypto {
    private const val MEM_KB = 65536
    private const val ITER = 3
    private const val PAR = 1
    private const val RSA_BITS = 3072
    private const val BEGIN = "-----BEGIN PGP MESSAGE-----"
    private const val END = "-----END PGP MESSAGE-----"

    // ---------------------------------------------------------------- key derivation

    private fun derive(passphrase: String, salt: ByteArray, memKb: Int, iter: Int, par: Int): CharArray {
        val normalized = Normalizer.normalize(passphrase, Normalizer.Form.NFKC)
        val params = Argon2Parameters.Builder(Argon2Parameters.ARGON2_id)
            .withVersion(Argon2Parameters.ARGON2_VERSION_13)
            .withIterations(iter)
            .withMemoryAsKB(memKb)
            .withParallelism(par)
            .withSalt(salt)
            .build()
        val gen = Argon2BytesGenerator()
        gen.init(params)
        val out = ByteArray(32)
        gen.generateBytes(normalized.toByteArray(Charsets.UTF_8), out)
        return Base64.getEncoder().encodeToString(out).toCharArray()
    }

    private fun armor(write: (OutputStream) -> Unit): String {
        val bos = ByteArrayOutputStream()
        ArmoredOutputStream(bos).use { write(it) }
        return bos.toString("UTF-8")
    }

    private fun blob(salt: ByteArray, memKb: Int, iter: Int, par: Int, armoredSecret: String): String =
        JSONObject()
            .put("v", 1).put("kdf", "argon2id")
            .put("m", memKb).put("t", iter).put("p", par)
            .put("salt", Base64.getEncoder().encodeToString(salt))
            .put("key", armoredSecret)
            .toString()

    private fun publicRingOf(secret: PGPSecretKeyRing): PGPPublicKeyRing {
        val list = ArrayList<PGPPublicKey>()
        val it = secret.publicKeys
        while (it.hasNext()) list.add(it.next())
        return PGPPublicKeyRing(list)
    }

    private fun protect(secret: PGPSecretKeyRing, old: PBESecretKeyDecryptor, derived: CharArray): PGPSecretKeyRing {
        val sha256 = BcPGPDigestCalculatorProvider().get(HashAlgorithmTags.SHA256)
        val encryptor = BcPBESecretKeyEncryptorBuilder(SymmetricKeyAlgorithmTags.AES_256, sha256, 0xc0).build(derived)
        return PGPSecretKeyRing.copyWithNewPassword(secret, old, encryptor)
    }

    // ---------------------------------------------------------------- create / unlock / change passphrase

    /** Generates a fresh RSA-3072 identity. CPU-heavy (seconds): call off the main thread. */
    fun createKey(email: String, passphrase: String): NewKey {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val derived = derive(passphrase, salt, MEM_KB, ITER, PAR)

        val kpg = RSAKeyPairGenerator()
        kpg.init(RSAKeyGenerationParameters(BigInteger.valueOf(0x10001), SecureRandom(), RSA_BITS, 80))
        val now = Date()
        val signPair = BcPGPKeyPair(PublicKeyAlgorithmTags.RSA_GENERAL, kpg.generateKeyPair(), now)
        val encPair = BcPGPKeyPair(PublicKeyAlgorithmTags.RSA_GENERAL, kpg.generateKeyPair(), now)

        val signSub = PGPSignatureSubpacketGenerator()
        signSub.setKeyFlags(false, KeyFlags.SIGN_DATA or KeyFlags.CERTIFY_OTHER)
        signSub.setPreferredSymmetricAlgorithms(
            false, intArrayOf(SymmetricKeyAlgorithmTags.AES_256, SymmetricKeyAlgorithmTags.AES_192, SymmetricKeyAlgorithmTags.AES_128)
        )
        signSub.setPreferredHashAlgorithms(false, intArrayOf(HashAlgorithmTags.SHA256, HashAlgorithmTags.SHA512))
        signSub.setPreferredCompressionAlgorithms(false, intArrayOf(CompressionAlgorithmTags.ZLIB))
        val encSub = PGPSignatureSubpacketGenerator()
        encSub.setKeyFlags(false, KeyFlags.ENCRYPT_COMMS or KeyFlags.ENCRYPT_STORAGE)

        val digests = BcPGPDigestCalculatorProvider()
        val encryptor = BcPBESecretKeyEncryptorBuilder(SymmetricKeyAlgorithmTags.AES_256, digests.get(HashAlgorithmTags.SHA256), 0xc0)
            .build(derived)
        val none: PGPSignatureSubpacketVector? = null
        val ringGen = PGPKeyRingGenerator(
            PGPSignature.POSITIVE_CERTIFICATION, signPair, "<$email>",
            digests.get(HashAlgorithmTags.SHA1), signSub.generate(), none,
            BcPGPContentSignerBuilder(signPair.publicKey.algorithm, HashAlgorithmTags.SHA256), encryptor,
        )
        ringGen.addSubKey(encPair, encSub.generate(), none)

        val secret = ringGen.generateSecretKeyRing()
        val pub = ringGen.generatePublicKeyRing()
        val decryptor = BcPBESecretKeyDecryptorBuilder(digests).build(derived)
        val armoredSecret = armor { secret.encode(it) }
        val armoredPublic = armor { pub.encode(it) }
        return NewKey(armoredPublic, blob(salt, MEM_KB, ITER, PAR, armoredSecret), UnlockedKey(email.lowercase(), secret, pub, decryptor))
    }

    /** Throws WrongPassphraseException if the passphrase doesn't open the key. Off the main thread (Argon2). */
    fun unlock(email: String, blobJson: String, passphrase: String): UnlockedKey {
        val o = try { JSONObject(blobJson) } catch (e: Exception) { throw CryptoException("The stored key backup is damaged.") }
        val salt = Base64.getDecoder().decode(o.getString("salt"))
        val derived = derive(passphrase, salt, o.optInt("m", MEM_KB), o.optInt("t", ITER), o.optInt("p", PAR))
        val ring = try {
            PGPSecretKeyRing(
                PGPUtil.getDecoderStream(ByteArrayInputStream(o.getString("key").toByteArray(Charsets.UTF_8))),
                BcKeyFingerprintCalculator(),
            )
        } catch (e: Exception) { throw CryptoException("The stored key backup is damaged.") }
        val decryptor = BcPBESecretKeyDecryptorBuilder(BcPGPDigestCalculatorProvider()).build(derived)
        try {
            ring.secretKey.extractPrivateKey(decryptor)           // proves the passphrase is right
        } catch (e: Exception) {
            throw WrongPassphraseException()
        }
        return UnlockedKey(email.lowercase(), ring, publicRingOf(ring), decryptor)
    }

    /** Re-protects the same key with a new passphrase (fresh salt). Returns the new backup blob and unlocked key. */
    fun changePassphrase(email: String, blobJson: String, oldPassphrase: String, newPassphrase: String): NewKey {
        val old = unlock(email, blobJson, oldPassphrase)
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val derived = derive(newPassphrase, salt, MEM_KB, ITER, PAR)
        val rewrapped = protect(old.secretRing, old.decryptor, derived)
        val decryptor = BcPBESecretKeyDecryptorBuilder(BcPGPDigestCalculatorProvider()).build(derived)
        val pub = publicRingOf(rewrapped)
        return NewKey(
            armor { pub.encode(it) },
            blob(salt, MEM_KB, ITER, PAR, armor { rewrapped.encode(it) }),
            UnlockedKey(old.email, rewrapped, pub, decryptor),
        )
    }

    // ---------------------------------------------------------------- public keys

    fun parsePublic(armored: String): PGPPublicKeyRing =
        PGPPublicKeyRing(PGPUtil.getDecoderStream(ByteArrayInputStream(armored.toByteArray(Charsets.UTF_8))), BcKeyFingerprintCalculator())

    fun armorPublic(ring: PGPPublicKeyRing): String = armor { ring.encode(it) }

    fun fingerprint(ring: PGPPublicKeyRing): String =
        ring.publicKey.fingerprint.joinToString("") { "%02X".format(it) }.chunked(4).joinToString(" ")

    private fun encryptionKey(ring: PGPPublicKeyRing): PGPPublicKey {
        val it = ring.publicKeys
        while (it.hasNext()) {
            val k = it.next()
            if (k.isEncryptionKey && !k.isMasterKey) return k
        }
        val master = ring.publicKey
        if (master.isEncryptionKey) return master
        throw CryptoException("This public key has no encryption key.")
    }

    // ---------------------------------------------------------------- encrypt / decrypt

    fun extractArmoredMessage(text: String): String? {
        val start = text.indexOf(BEGIN)
        if (start < 0) return null
        val end = text.indexOf(END, start)
        if (end < 0) return null
        return text.substring(start, end + END.length)
    }

    /** Signs with the sender's key, then encrypts to every recipient (include the sender so Sent mail stays readable). */
    fun encryptSigned(plaintext: String, recipients: List<PGPPublicKeyRing>, signer: UnlockedKey): String {
        if (recipients.isEmpty()) throw CryptoException("No recipients to encrypt for.")
        val data = plaintext.toByteArray(Charsets.UTF_8)
        val encGen = PGPEncryptedDataGenerator(
            BcPGPDataEncryptorBuilder(SymmetricKeyAlgorithmTags.AES_256).setWithIntegrityPacket(true).setSecureRandom(SecureRandom())
        )
        recipients.forEach { encGen.addMethod(BcPublicKeyKeyEncryptionMethodGenerator(encryptionKey(it))) }

        val signKey = signer.secretRing.secretKey
        val sigGen = PGPSignatureGenerator(BcPGPContentSignerBuilder(signKey.publicKey.algorithm, HashAlgorithmTags.SHA256))
        sigGen.init(PGPSignature.BINARY_DOCUMENT, signKey.extractPrivateKey(signer.decryptor))

        val bos = ByteArrayOutputStream()
        ArmoredOutputStream(bos).use { armored ->
            val encOut = encGen.open(armored, ByteArray(1 shl 16))
            val compGen = PGPCompressedDataGenerator(CompressionAlgorithmTags.ZLIB)
            val compOut = compGen.open(encOut)
            sigGen.generateOnePassVersion(false).encode(compOut)
            val litGen = PGPLiteralDataGenerator()
            val litOut = litGen.open(compOut, PGPLiteralData.UTF8, PGPLiteralData.CONSOLE, data.size.toLong(), Date())
            litOut.write(data)
            sigGen.update(data)
            litGen.close()
            sigGen.generate().encode(compOut)
            compGen.close()
            encOut.close()
        }
        return bos.toString("UTF-8")
    }

    fun decrypt(armored: String, me: UnlockedKey, senderKeys: List<PGPPublicKeyRing>): Decrypted {
        val factory = PGPObjectFactory(
            PGPUtil.getDecoderStream(ByteArrayInputStream(armored.toByteArray(Charsets.UTF_8))),
            BcKeyFingerprintCalculator(),
        )
        var first: Any? = factory.nextObject()
        if (first !is PGPEncryptedDataList) first = factory.nextObject()
        val encList = first as? PGPEncryptedDataList ?: throw CryptoException("This isn't an encrypted message.")

        var chosen: PGPPublicKeyEncryptedData? = null
        var privateKey: PGPPrivateKey? = null
        for (d in encList) {
            if (d is PGPPublicKeyEncryptedData) {
                val sk = me.secretRing.getSecretKey(d.keyID)
                if (sk != null) {
                    chosen = d
                    privateKey = sk.extractPrivateKey(me.decryptor)
                    break
                }
            }
        }
        val pked = chosen
        val priv = privateKey
        if (pked == null || priv == null) throw CryptoException("This message wasn't encrypted to your key.")

        val clear = pked.getDataStream(BcPublicKeyDataDecryptorFactory(priv))
        var f2 = PGPObjectFactory(clear, BcKeyFingerprintCalculator())
        var o2: Any? = f2.nextObject()
        if (o2 is PGPCompressedData) {
            f2 = PGPObjectFactory(o2.dataStream, BcKeyFingerprintCalculator())
            o2 = f2.nextObject()
        }
        var onePass: PGPOnePassSignature? = null
        if (o2 is PGPOnePassSignatureList) {
            onePass = o2[0]
            o2 = f2.nextObject()
        }
        val literal = o2 as? PGPLiteralData ?: throw CryptoException("The message content is unreadable.")
        val bytes = literal.inputStream.readBytes()

        var verification = Verification.None
        val op = onePass
        if (op != null) {
            val signerRing = senderKeys.firstOrNull { it.getPublicKey(op.keyID) != null }
            val signerKey = signerRing?.getPublicKey(op.keyID)
            if (signerKey == null) {
                verification = Verification.SignerUnknown
            } else {
                op.init(BcPGPContentVerifierBuilderProvider(), signerKey)
                op.update(bytes)
                val sigs = f2.nextObject() as? PGPSignatureList
                verification = if (sigs != null && sigs.size() > 0 && op.verify(sigs[0])) Verification.Verified else Verification.Invalid
            }
        }
        if (pked.isIntegrityProtected && !pked.verify()) throw CryptoException("The message was modified after it was encrypted.")
        return Decrypted(String(bytes, Charsets.UTF_8), verification)
    }
}
