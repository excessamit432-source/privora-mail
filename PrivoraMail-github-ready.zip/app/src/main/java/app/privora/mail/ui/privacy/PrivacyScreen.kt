// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (C) 2026 The PRIVORA MAIL authors. See LICENSE-NOTICE.md.
package app.privora.mail.ui.privacy

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import app.privora.mail.core.data.AppSettings
import app.privora.mail.core.design.Privora
import app.privora.mail.core.design.PrivoraCard
import app.privora.mail.core.design.Spacing

private data class Fact(val title: String, val detail: String)

// MAINTENANCE RULE: an entry may sit in `active` only if the code or config in this repo enforces it.
private val active = listOf(
    Fact("End-to-end encryption between PRIVORA users", "When every recipient is a PRIVORA user with a published key, your message is signed and encrypted on this device. The server only stores ciphertext. New in this version and not yet independently audited."),
    Fact("Zero-knowledge key backup", "Your private key is protected on this device by a key stretched from your encryption passphrase (Argon2id). Only that protected backup is uploaded; the server cannot open it."),
    Fact("Honest message badges", "A message is only labelled encrypted after it was actually decrypted here. Signature checks are shown separately."),
    Fact("Encrypted mail connections", "IMAP and SMTP always use TLS, with certificate and server-name verification. Unencrypted connections are never used."),
    Fact("Mailbox password in the Android Keystore", "Your mailbox password is encrypted with a key held in the Android Keystore. It is never logged and never saved in plain text."),
    Fact("No remote content, no tracking pixels", "Emails are shown as plain text, so remote images and tracking pixels are never loaded."),
    Fact("Nothing cached on the device", "Messages are held in memory only. Unlocked keys also live in memory only."),
    Fact("No trackers or analytics", "The app contains no advertising, analytics or crash-reporting SDKs."),
    Fact("No cloud backup, minimal permissions", "Android backup is disabled. The only permission is internet access."),
)

private val notYet = listOf(
    Fact("Mail to other providers is NOT end-to-end encrypted", "Email to Gmail, Outlook and others cannot be, because their servers must read it. You are asked before anything is sent unencrypted."),
    Fact("Hidden subject and addresses", "The subject, sender, recipients and date are visible to the server."),
    Fact("Encrypted attachments and drafts", "Not built yet."),
    Fact("Search inside encrypted messages", "Search covers subject and sender; message text is ciphertext on the server."),
    Fact("Two-step login, security keys, recovery email/phone, trusted devices", "These are server features that don't exist yet."),
    Fact("Independent security audit", "Not done."),
)

@Composable
fun PrivacyScreen(settings: AppSettings, accountCount: Int) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(Spacing.lg)) {
        Text("Privacy Center", style = MaterialTheme.typography.titleLarge, modifier = Modifier.semantics { heading() })
        Spacer(Modifier.height(Spacing.xs))
        Text("This page lists only what is true of this build.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(Spacing.xl))

        Label("Your current settings")
        val now = listOf(
            Fact("App lock", if (settings.appLock) "On (fingerprint, face or screen lock)" else "Off. Turn it on in Settings, then Privacy and security."),
            Fact("Screenshot and app-switcher protection", if (settings.blockScreenshots) "On" else "Off"),
            Fact("Connected accounts", if (accountCount == 0) "None" else "$accountCount"),
        )
        now.forEach { PrivoraCard(Modifier.fillMaxWidth().padding(bottom = Spacing.sm)) { FactRow(it, null, Color.Unspecified) } }
        Spacer(Modifier.height(Spacing.lg))

        Label("Active in this build")
        active.forEach { PrivoraCard(Modifier.fillMaxWidth().padding(bottom = Spacing.sm)) { FactRow(it, Icons.Outlined.CheckCircle, Privora.extras.success) } }
        Spacer(Modifier.height(Spacing.lg))

        Label("Not available yet")
        notYet.forEach { PrivoraCard(Modifier.fillMaxWidth().padding(bottom = Spacing.sm)) { FactRow(it, Icons.Outlined.Schedule, Privora.extras.textTertiary) } }
    }
}

@Composable
private fun Label(text: String) {
    Text(text, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(bottom = Spacing.sm).semantics { heading() })
}

@Composable
private fun FactRow(fact: Fact, icon: ImageVector?, tint: Color) {
    Row(verticalAlignment = Alignment.Top) {
        if (icon != null) {
            Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(24.dp))
            Spacer(Modifier.width(Spacing.md))
        }
        Column {
            Text(fact.title, style = MaterialTheme.typography.titleMedium)
            Text(fact.detail, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
