package app.privora.mail.ui.privacy

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import app.privora.mail.core.design.Privora
import app.privora.mail.core.design.PrivoraCard
import app.privora.mail.core.design.Spacing

private data class Fact(val title: String, val detail: String)

// MAINTENANCE RULE: an entry may sit in `active` only if the code/config in this repo enforces it.
// Move entries across as features ship. Never add decorative scores or "protected" badges.
private val active = listOf(
    Fact("HTTPS only", "Cleartext (HTTP) network traffic is blocked by the app's network security policy."),
    Fact("No trackers", "The app contains no advertising, analytics or crash-reporting SDKs."),
    Fact("No cloud backup", "Android backup and device-transfer of app data are disabled."),
    Fact("No permissions requested", "The app currently requests no Android permissions."),
)

private val notYet = listOf(
    Fact("Encryption at rest", "Planned: encrypted local database with keys in the Android Keystore."),
    Fact("App lock and biometrics", "Planned for the privacy and security step."),
    Fact("End-to-end encryption", "Planned between PRIVORA accounts. It cannot apply to mail sent to other providers."),
    Fact("Trusted devices and sessions", "Requires a backend and sign-in, which do not exist yet."),
)

@Composable
fun PrivacyScreen() {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(Spacing.lg)) {
        Text("Privacy Center", style = MaterialTheme.typography.titleLarge, modifier = Modifier.semantics { heading() })
        Spacer(Modifier.height(Spacing.xs))
        Text(
            "This page lists only what is true of this build.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(Spacing.xl))
        Section("Active in this build", active, Icons.Outlined.CheckCircle, Privora.extras.success)
        Spacer(Modifier.height(Spacing.xl))
        Section("Not available yet", notYet, Icons.Outlined.Schedule, Privora.extras.textTertiary)
    }
}

@Composable
private fun Section(title: String, facts: List<Fact>, icon: ImageVector, tint: Color) {
    Text(title, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.semantics { heading() })
    Spacer(Modifier.height(Spacing.sm))
    facts.forEach { fact ->
        PrivoraCard(Modifier.fillMaxWidth().padding(bottom = Spacing.sm)) {
            Row(verticalAlignment = Alignment.Top) {
                Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(24.dp))
                Spacer(Modifier.width(Spacing.md))
                Column {
                    Text(fact.title, style = MaterialTheme.typography.titleMedium)
                    Text(fact.detail, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}
