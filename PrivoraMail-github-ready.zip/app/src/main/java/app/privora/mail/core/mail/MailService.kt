package app.privora.mail.core.mail

import androidx.core.text.HtmlCompat
import com.sun.mail.imap.IMAPFolder
import java.io.IOException
import java.util.Date
import java.util.Properties
import javax.mail.AuthenticationFailedException
import javax.mail.FetchProfile
import javax.mail.Flags
import javax.mail.Folder
import javax.mail.Message
import javax.mail.MessagingException
import javax.mail.Multipart
import javax.mail.Part
import javax.mail.Session
import javax.mail.Store
import javax.mail.UIDFolder
import javax.mail.internet.AddressException
import javax.mail.internet.InternetAddress
import javax.mail.internet.MimeMessage
import javax.mail.internet.MimeUtility
import javax.mail.search.AndTerm
import javax.mail.search.BodyTerm
import javax.mail.search.FlagTerm
import javax.mail.search.FromStringTerm
import javax.mail.search.OrTerm
import javax.mail.search.RecipientStringTerm
import javax.mail.search.SearchTerm
import javax.mail.search.SubjectTerm
import javax.net.ssl.SSLException

/**
 * Real IMAP/SMTP client. All methods BLOCK, so call them from Dispatchers.IO.
 * Security: TLS always (implicit SSL or required STARTTLS) with server-identity verification.
 * No trust-all sockets. Passwords are passed in per call and never logged or stored here.
 */
class MailService {

    // ---------- connection plumbing ----------

    private fun imapProps(host: String, port: Int) = Properties().apply {
        put("mail.store.protocol", "imaps")
        put("mail.imaps.host", host)
        put("mail.imaps.port", port.toString())
        put("mail.imaps.ssl.enable", "true")
        put("mail.imaps.ssl.checkserveridentity", "true")
        put("mail.imaps.connectiontimeout", "15000")
        put("mail.imaps.timeout", "30000")
        put("mail.imaps.writetimeout", "30000")
    }

    private fun smtpProps(acc: MailAccount) = Properties().apply {
        val ssl = acc.smtpSecurity == SmtpSecurity.SSL
        val p = if (ssl) "mail.smtps" else "mail.smtp"
        put("$p.host", acc.smtpHost)
        put("$p.port", acc.smtpPort.toString())
        put("$p.auth", "true")
        put("$p.ssl.checkserveridentity", "true")
        put("$p.connectiontimeout", "15000")
        put("$p.timeout", "30000")
        put("$p.writetimeout", "30000")
        if (ssl) {
            put("$p.ssl.enable", "true")
        } else {
            put("$p.starttls.enable", "true")
            put("$p.starttls.required", "true")
        }
    }

    private fun <T> withStore(acc: MailAccount, password: String, block: (Store) -> T): T {
        val store = Session.getInstance(imapProps(acc.imapHost, acc.imapPort)).getStore("imaps")
        try {
            store.connect(acc.imapHost, acc.imapPort, acc.email, password)
            return block(store)
        } catch (e: Exception) {
            throw map(e)
        } finally {
            runCatching { store.close() }
        }
    }

    private fun map(e: Throwable): MailException = when (e) {
        is MailException -> e
        is AuthenticationFailedException -> MailException(
            MailException.Kind.Auth,
            "Sign-in was rejected. Check your email and password. Gmail, Yahoo and iCloud need an app password, not your normal one."
        )
        is SSLException -> MailException(
            MailException.Kind.Server,
            "The secure connection failed (certificate or TLS problem). Check the server address."
        )
        is IOException -> MailException(
            MailException.Kind.Network,
            "Could not reach the mail server. Check your internet connection and the server address."
        )
        is MessagingException -> {
            val cause = e.cause
            if (cause != null && cause !is MessagingException) map(cause)
            else MailException(MailException.Kind.Server, e.message ?: "The mail server reported an error.")
        }
        else -> MailException(MailException.Kind.Other, e.message ?: "Unexpected error.")
    }

    // ---------- account / folders ----------

    /** Verifies BOTH incoming (IMAP) and outgoing (SMTP) sign-in. Throws MailException on failure. */
    fun testConnection(acc: MailAccount, password: String) {
        withStore(acc, password) { store -> store.getFolder("INBOX").exists() }
        val session = Session.getInstance(smtpProps(acc))
        val transport = session.getTransport(if (acc.smtpSecurity == SmtpSecurity.SSL) "smtps" else "smtp")
        try {
            transport.connect(acc.smtpHost, acc.smtpPort, acc.email, password)
        } catch (e: Exception) {
            throw map(e)
        } finally {
            runCatching { transport.close() }
        }
    }

    fun resolveFolders(acc: MailAccount, password: String): FolderMap = withStore(acc, password) { store ->
        var sent: String? = null
        var drafts: String? = null
        var spam: String? = null
        var trash: String? = null
        var all: String? = null
        val folders = store.defaultFolder.list("*")
        for (f in folders) {
            val attrs = (f as? IMAPFolder)?.attributes ?: continue
            for (a in attrs) {
                when (a.lowercase()) {
                    "\\sent" -> sent = f.fullName
                    "\\drafts" -> drafts = f.fullName
                    "\\junk" -> spam = f.fullName
                    "\\trash" -> trash = f.fullName
                    "\\all" -> all = f.fullName
                }
            }
        }
        fun byName(vararg names: String): String? =
            folders.firstOrNull { it.name.lowercase() in names }?.fullName
        FolderMap(
            inbox = "INBOX",
            sent = sent ?: byName("sent", "sent items", "sent mail", "sent messages"),
            drafts = drafts ?: byName("drafts", "draft"),
            spam = spam ?: byName("spam", "junk", "junk e-mail", "junk email", "bulk mail"),
            trash = trash ?: byName("trash", "deleted items", "deleted messages", "bin"),
            all = all,
        )
    }

    // ---------- reading ----------

    private fun buildTerm(query: String?, flaggedOnly: Boolean): SearchTerm? {
        val q = query?.trim().orEmpty()
        val text: SearchTerm? = if (q.isEmpty()) null else OrTerm(
            arrayOf<SearchTerm>(
                SubjectTerm(q),
                FromStringTerm(q),
                RecipientStringTerm(Message.RecipientType.TO, q),
                BodyTerm(q),
            )
        )
        val flagged: SearchTerm? = if (flaggedOnly) FlagTerm(Flags(Flags.Flag.FLAGGED), true) else null
        return when {
            text != null && flagged != null -> AndTerm(text, flagged)
            text != null -> text
            else -> flagged
        }
    }

    /** Newest first. `query` runs a real server-side IMAP SEARCH (subject, sender, recipient, body). */
    fun fetchHeaders(
        acc: MailAccount, password: String, folder: String, limit: Int,
        query: String?, flaggedOnly: Boolean,
    ): List<MailHeader> = withStore(acc, password) { store ->
        val f = store.getFolder(folder) as IMAPFolder
        f.open(Folder.READ_ONLY)
        try {
            val term = buildTerm(query, flaggedOnly)
            val msgs: Array<Message> = if (term == null) {
                val n = f.messageCount
                if (n == 0) emptyArray<Message>() else f.getMessages(maxOf(1, n - limit + 1), n)
            } else {
                val found = f.search(term)
                if (found.size > limit) found.copyOfRange(found.size - limit, found.size) else found
            }
            val profile = FetchProfile().apply {
                add(FetchProfile.Item.ENVELOPE)
                add(FetchProfile.Item.FLAGS)
                add(FetchProfile.Item.CONTENT_INFO)
                add(UIDFolder.FetchProfileItem.UID)
            }
            f.fetch(msgs, profile)
            msgs.reversed().map { toHeader(f, it, folder) }
        } finally {
            runCatching { f.close(false) }
        }
    }

    private fun toHeader(f: IMAPFolder, m: Message, folder: String): MailHeader {
        val from = runCatching { m.from?.firstOrNull() as? InternetAddress }.getOrNull()
        val name = from?.personal?.takeIf { it.isNotBlank() } ?: from?.address ?: "(unknown sender)"
        val flags = m.flags
        return MailHeader(
            uid = f.getUID(m),
            folder = folder,
            fromName = name,
            fromAddress = from?.address.orEmpty(),
            subject = runCatching { m.subject }.getOrNull()?.takeIf { it.isNotBlank() } ?: "(no subject)",
            dateMillis = (m.receivedDate ?: m.sentDate)?.time ?: 0L,
            unread = !flags.contains(Flags.Flag.SEEN),
            starred = flags.contains(Flags.Flag.FLAGGED),
            hasAttachment = runCatching { m.isMimeType("multipart/mixed") }.getOrDefault(false),
        )
    }

    fun fetchBody(acc: MailAccount, password: String, folder: String, uid: Long): MailBody =
        withStore(acc, password) { store ->
            val f = store.getFolder(folder) as IMAPFolder
            f.open(Folder.READ_WRITE)
            try {
                val m = f.getMessageByUID(uid)
                    ?: throw MailException(MailException.Kind.Server, "This message no longer exists on the server.")
                val out = Extracted()
                walk(m, out)
                m.setFlag(Flags.Flag.SEEN, true)
                val header = toHeader(f, m, folder).copy(unread = false)
                fun addrs(type: Message.RecipientType): List<String> =
                    runCatching { m.getRecipients(type) }.getOrNull()
                        ?.map { (it as? InternetAddress)?.toUnicodeString() ?: it.toString() }.orEmpty()
                MailBody(
                    header = header,
                    to = addrs(Message.RecipientType.TO),
                    cc = addrs(Message.RecipientType.CC),
                    text = out.text ?: out.html?.let { htmlToText(it) } ?: "",
                    attachments = out.attachments,
                    messageId = (m as? MimeMessage)?.messageID,
                )
            } finally {
                runCatching { f.close(false) }
            }
        }

    private class Extracted {
        var text: String? = null
        var html: String? = null
        val attachments = mutableListOf<AttachmentInfo>()
    }

    private fun walk(p: Part, out: Extracted) {
        if (p.isMimeType("multipart/*")) {
            val mp = p.content as Multipart
            for (i in 0 until mp.count) walk(mp.getBodyPart(i), out)
            return
        }
        val disposition = runCatching { p.disposition }.getOrNull()
        val rawName = runCatching { p.fileName }.getOrNull()
        val fileName = rawName?.let { runCatching { MimeUtility.decodeText(it) }.getOrDefault(it) }
        if (Part.INLINE.equals(disposition, ignoreCase = true) && p.isMimeType("image/*")) return
        if (Part.ATTACHMENT.equals(disposition, ignoreCase = true) || (fileName != null && !p.isMimeType("text/*"))) {
            out.attachments += AttachmentInfo(fileName ?: "attachment", maxOf(0, p.size).toLong())
            return
        }
        if (p.isMimeType("text/plain") && out.text == null) {
            out.text = runCatching { p.content as? String }.getOrNull()
        } else if (p.isMimeType("text/html") && out.html == null) {
            out.html = runCatching { p.content as? String }.getOrNull()
        }
    }

    /** Converts HTML to plain text. Nothing is rendered as HTML, so remote images and trackers never load. */
    private fun htmlToText(html: String): String {
        val cleaned = html
            .replace(Regex("(?is)<(script|style|head)[^>]*>.*?</\\1>"), "")
        return HtmlCompat.fromHtml(cleaned, HtmlCompat.FROM_HTML_MODE_LEGACY).toString()
            .replace("\uFFFC", "")
            .replace(Regex("[ \\t]+\\n"), "\n")
            .replace(Regex("\\n{3,}"), "\n\n")
            .trim()
    }

    // ---------- changing mail ----------

    fun setFlag(acc: MailAccount, password: String, folder: String, uid: Long, flag: Flags.Flag, value: Boolean) {
        withStore(acc, password) { store ->
            val f = store.getFolder(folder) as IMAPFolder
            f.open(Folder.READ_WRITE)
            try {
                f.getMessageByUID(uid)?.setFlag(flag, value)
            } finally {
                runCatching { f.close(false) }
            }
        }
    }

    /**
     * Moves to Trash. If the message is already in Trash it is deleted permanently.
     * If no Trash folder can be found it REFUSES rather than risk permanent loss.
     */
    fun delete(acc: MailAccount, password: String, folder: String, uid: Long, trashFolder: String?) {
        if (trashFolder == null && folder.lowercase() != "trash") {
            throw MailException(MailException.Kind.Other, "No Trash folder was found on this account, so nothing was deleted.")
        }
        withStore(acc, password) { store ->
            val f = store.getFolder(folder) as IMAPFolder
            f.open(Folder.READ_WRITE)
            try {
                val m = f.getMessageByUID(uid) ?: return@withStore
                if (trashFolder != null && trashFolder != folder) {
                    f.copyMessages(arrayOf(m), store.getFolder(trashFolder))
                }
                m.setFlag(Flags.Flag.DELETED, true)
                try {
                    f.expunge(arrayOf(m))      // UIDPLUS: removes only this message
                } catch (e: MessagingException) {
                    f.expunge()
                }
            } finally {
                runCatching { f.close(false) }
            }
        }
    }

    // ---------- sending ----------

    private fun parseAddresses(raw: String, label: String): Array<InternetAddress> {
        val cleaned = raw.replace(';', ',').trim()
        if (cleaned.isEmpty()) return emptyArray()
        return try {
            InternetAddress.parse(cleaned, true)
        } catch (e: AddressException) {
            throw MailException(MailException.Kind.Other, "The $label address looks invalid: ${e.ref ?: cleaned}")
        }
    }

    fun send(acc: MailAccount, password: String, mail: OutgoingMail, sentFolder: String?) {
        val to = parseAddresses(mail.to, "To")
        val cc = parseAddresses(mail.cc, "Cc")
        val bcc = parseAddresses(mail.bcc, "Bcc")
        if (to.isEmpty()) throw MailException(MailException.Kind.Other, "Add at least one recipient.")

        val session = Session.getInstance(smtpProps(acc))
        val msg = MimeMessage(session).apply {
            setFrom(InternetAddress(acc.email, acc.displayName.ifBlank { null }, "UTF-8"))
            setRecipients(Message.RecipientType.TO, to)
            if (cc.isNotEmpty()) setRecipients(Message.RecipientType.CC, cc)
            if (bcc.isNotEmpty()) setRecipients(Message.RecipientType.BCC, bcc)
            setSubject(mail.subject, "UTF-8")
            setText(mail.body, "UTF-8")
            sentDate = Date()
            mail.inReplyTo?.takeIf { it.isNotBlank() }?.let {
                setHeader("In-Reply-To", it)
                setHeader("References", it)
            }
            saveChanges()
        }

        val transport = session.getTransport(if (acc.smtpSecurity == SmtpSecurity.SSL) "smtps" else "smtp")
        try {
            transport.connect(acc.smtpHost, acc.smtpPort, acc.email, password)
            transport.sendMessage(msg, msg.allRecipients)
        } catch (e: Exception) {
            throw map(e)
        } finally {
            runCatching { transport.close() }
        }

        // Best effort: the mail has already been sent, so a failure here must not look like a send failure.
        if (acc.appendSent && sentFolder != null) {
            runCatching {
                withStore(acc, password) { store ->
                    val f = store.getFolder(sentFolder)
                    f.open(Folder.READ_WRITE)
                    try {
                        f.appendMessages(arrayOf<Message>(msg))
                    } finally {
                        runCatching { f.close(false) }
                    }
                }
            }
        }
    }
}
