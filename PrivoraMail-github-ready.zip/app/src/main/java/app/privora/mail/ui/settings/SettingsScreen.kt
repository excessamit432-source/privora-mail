package app.privora.mail.ui.settings

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.outlined.AlternateEmail
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Key
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Mail
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.outlined.Smartphone
import androidx.compose.material.icons.outlined.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import app.privora.mail.AppViewModel
import app.privora.mail.core.data.AppSettings
import app.privora.mail.core.design.MotionMode
import app.privora.mail.core.design.Privora
import app.privora.mail.core.design.PrivoraAvatar
import app.privora.mail.core.design.PrivoraCard
import app.privora.mail.core.design.PrivoraGradientButton
import app.privora.mail.core.design.Spacing
import app.privora.mail.core.design.ThemeMode
import app.privora.mail.core.design.privoraFieldColors
import app.privora.mail.core.mail.Providers
import app.privora.mail.core.security.LocalAuthenticator
import app.privora.mail.ui.mail.MailUiState
import app.privora.mail.ui.mail.MailViewModel
import kotlinx.coroutines.delay

enum class SettingsPage(val title: String) {
    Main("Settings"), Accounts("Email accounts"), Appearance("Appearance"),
    MailPrefs("Mail preferences"), Security("Privacy and security"), About("About"),
}

@Composable
fun SettingsScreen(
    settings: AppSettings,
    mail: MailUiState,
    appVm: AppViewModel,
    mailVm: MailViewModel,
    onAddAccount: () -> Unit,
) {
    var page by rememberSaveable { mutableStateOf(SettingsPage.Main) }
    BackHandler(enabled = page != SettingsPage.Main) { page = SettingsPage.Main }

    when (page) {
        SettingsPage.Main -> MainPage(mail) { page = it }
        SettingsPage.Accounts -> SubPage(page.title, { page = SettingsPage.Main }) { AccountsPage(mail, mailVm, onAddAccount) }
        SettingsPage.Appearance -> SubPage(page.title, { page = SettingsPage.Main }) { AppearancePage(settings, appVm) }
        SettingsPage.MailPrefs -> SubPage(page.title, { page = SettingsPage.Main }) { MailPrefsPage(settings, appVm) }
        SettingsPage.Security -> SubPage(page.title, { page = SettingsPage.Main }) { SecurityPage(settings, appVm, mailVm) }
        SettingsPage.About -> SubPage(page.title, { page = SettingsPage.Main }) { AboutPage() }
    }
}

// ---------------------------------------------------------------- main page

@Composable
private fun MainPage(mail: MailUiState, open: (SettingsPage) -> Unit) {
    val uri = LocalUriHandler.current
    val active = mail.active
    val preset = active?.let { Providers.forEmail(it.email) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(Spacing.lg)) {
        Text("Settings", style = MaterialTheme.typography.titleLarge, modifier = Modifier.semantics { heading() })
        Spacer(Modifier.height(Spacing.lg))

        PrivoraCard(Modifier.fillMaxWidth(), onClick = { open(SettingsPage.Accounts) }) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                PrivoraAvatar(active?.shortName ?: "P", 48.dp)
                Spacer(Modifier.width(Spacing.md))
                Column(Modifier.weight(1f)) {
                    Text(active?.shortName ?: "No account connected", style = MaterialTheme.typography.titleMedium)
                    Text(active?.email ?: "Tap to add an email account", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Chevron()
            }
        }
        Spacer(Modifier.height(Spacing.xl))

        Label("Account security")
        val url: String? = preset?.securityUrl
        if (preset != null && url != null) {
            Group {
                SettingsRow(Icons.Outlined.VerifiedUser, "Two-step verification", "Protect sign-in with a second step") { openUrl(uri, url) }
                RowDivider()
                SettingsRow(Icons.Outlined.AlternateEmail, "Recovery email", "Add a backup email to recover your account") { openUrl(uri, url) }
                RowDivider()
                SettingsRow(Icons.Outlined.Smartphone, "Recovery phone number", "Add a phone number for verification codes") { openUrl(uri, url) }
                RowDivider()
                SettingsRow(Icons.Outlined.Key, "App passwords", "Create the password this app signs in with") { openUrl(uri, preset.appPasswordUrl ?: url) }
                RowDivider()
                SettingsRow(Icons.Outlined.Lock, "Password management", "Change your ${preset.name} password") { openUrl(uri, url) }
            }
            Spacer(Modifier.height(Spacing.sm))
            Text(
                "These open ${preset.name}'s own security page, because ${preset.name} controls them. PRIVORA can't change them for you.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        } else {
            PrivoraCard(Modifier.fillMaxWidth()) {
                Text(
                    "Two-step verification, recovery email and recovery phone are controlled by your email provider. Connect a Gmail, Yahoo or iCloud account to get direct links to those pages.",
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        Spacer(Modifier.height(Spacing.sm))
        Text(
            "PRIVORA's own sign-in protections (its own two-step verification, security keys, recovery email and phone, trusted devices) need a PRIVORA account system and server. That doesn't exist yet.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(Spacing.xl))

        Label("Preferences")
        Group {
            SettingsRow(Icons.Outlined.Palette, "Appearance", "Theme and motion") { open(SettingsPage.Appearance) }
            RowDivider()
            SettingsRow(Icons.Outlined.Mail, "Mail preferences", "Signature, list size, delete confirmation") { open(SettingsPage.MailPrefs) }
            RowDivider()
            SettingsRow(Icons.Outlined.Shield, "Privacy and security", "App lock, screenshot protection") { open(SettingsPage.Security) }
        }
        Spacer(Modifier.height(Spacing.xl))

        Label("About")
        Group { SettingsRow(Icons.Outlined.Info, "About PRIVORA MAIL", null) { open(SettingsPage.About) } }
        Spacer(Modifier.height(Spacing.xl))
    }
}

// ---------------------------------------------------------------- sub pages

@Composable
private fun SubPage(title: String, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = Spacing.xs), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back to settings") }
            Text(title, style = MaterialTheme.typography.titleLarge, modifier = Modifier.semantics { heading() })
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = Spacing.lg), content = content)
    }
}

@Composable
private fun ColumnScope.AccountsPage(mail: MailUiState, mailVm: MailViewModel, onAddAccount: () -> Unit) {
    var removing by remember { mutableStateOf<String?>(null) }
    if (mail.accounts.isEmpty()) {
        Text("No accounts connected.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(Spacing.lg))
    }
    mail.accounts.forEach { a ->
        val isActive = a.id == mail.active?.id
        PrivoraCard(Modifier.fillMaxWidth().padding(bottom = Spacing.md)) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    PrivoraAvatar(a.shortName, 44.dp)
                    Spacer(Modifier.width(Spacing.md))
                    Column(Modifier.weight(1f)) {
                        Text(a.email, style = MaterialTheme.typography.titleSmall)
                        Text(
                            (Providers.forEmail(a.email)?.name ?: a.imapHost) + if (isActive) " · Active" else "",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                    if (!isActive) TextButton(onClick = { mailVm.setActive(a.id) }) { Text("Make active") }
                    TextButton(onClick = { removing = a.id }) { Text("Remove", color = MaterialTheme.colorScheme.error) }
                }
            }
        }
    }
    Spacer(Modifier.height(Spacing.sm))
    PrivoraGradientButton("Add account", onAddAccount, Modifier.fillMaxWidth())
    Spacer(Modifier.height(Spacing.xl))

    val target = mail.accounts.firstOrNull { it.id == removing }
    if (target != null) {
        AlertDialog(
            onDismissRequest = { removing = null },
            title = { Text("Remove ${target.email}?") },
            text = { Text("The saved password is deleted from this device. Your email stays safe on the server.") },
            confirmButton = { TextButton(onClick = { mailVm.removeAccount(target.id); removing = null }) { Text("Remove") } },
            dismissButton = { TextButton(onClick = { removing = null }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun ColumnScope.AppearancePage(settings: AppSettings, appVm: AppViewModel) {
    Label("Theme")
    Group {
        Column(Modifier.selectableGroup()) {
            OptionRow("System default", "Follow your device setting", settings.themeMode == ThemeMode.System) { appVm.setTheme(ThemeMode.System) }
            OptionRow("Dark", null, settings.themeMode == ThemeMode.Dark) { appVm.setTheme(ThemeMode.Dark) }
            OptionRow("Light", null, settings.themeMode == ThemeMode.Light) { appVm.setTheme(ThemeMode.Light) }
        }
    }
    Spacer(Modifier.height(Spacing.xl))
    Label("Motion")
    Group {
        Column(Modifier.selectableGroup()) {
            OptionRow("Full", "All animations as designed", settings.motionMode == MotionMode.Full) { appVm.setMotion(MotionMode.Full) }
            OptionRow("Reduced", "Shorter, simpler transitions", settings.motionMode == MotionMode.Reduced) { appVm.setMotion(MotionMode.Reduced) }
            OptionRow("Minimal", "Instant changes, no decorative movement", settings.motionMode == MotionMode.Minimal) { appVm.setMotion(MotionMode.Minimal) }
        }
    }
    Spacer(Modifier.height(Spacing.sm))
    Text("Android's system setting to remove animations always takes priority.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
private fun ColumnScope.MailPrefsPage(settings: AppSettings, appVm: AppViewModel) {
    var sig by rememberSaveable { mutableStateOf(settings.signature) }
    LaunchedEffect(sig) {
        delay(500)
        if (sig != settings.signature) appVm.setSignature(sig)
    }
    Label("Signature")
    OutlinedTextField(
        value = sig, onValueChange = { sig = it },
        modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp),
        label = { Text("Added to new messages and replies") },
        colors = privoraFieldColors(), shape = MaterialTheme.shapes.medium,
        keyboardOptions = KeyboardOptions(),
    )
    Spacer(Modifier.height(Spacing.xl))
    Label("Messages loaded per refresh")
    Group {
        Column(Modifier.selectableGroup()) {
            listOf(25, 50, 100).forEach { n ->
                OptionRow("$n messages", if (n == 50) "Recommended" else null, settings.fetchLimit == n) { appVm.setFetchLimit(n) }
            }
        }
    }
    Spacer(Modifier.height(Spacing.xl))
    Label("Deleting")
    Group {
        SwitchRow("Confirm before deleting", "Ask before moving a message to Trash", settings.confirmDelete) { appVm.setConfirmDelete(it) }
    }
}

@Composable
private fun ColumnScope.SecurityPage(settings: AppSettings, appVm: AppViewModel, mailVm: MailViewModel) {
    val auth = LocalAuthenticator.current
    val canAuth = remember { auth?.canAuthenticate() == true }
    var confirmWipe by remember { mutableStateOf(false) }

    Label("App lock")
    Group {
        SwitchRow(
            "App lock",
            if (!canAuth && !settings.appLock) "Set up a screen lock or fingerprint in Android settings first."
            else "Require your fingerprint, face or screen lock to open PRIVORA MAIL",
            settings.appLock,
            enabled = canAuth || settings.appLock,
        ) { want ->
            auth?.authenticate(if (want) "Turn on app lock" else "Turn off app lock") { ok -> if (ok) appVm.setAppLock(want) }
        }
        if (settings.appLock) {
            RowDivider()
            Text("Lock after", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(start = Spacing.lg, top = Spacing.md))
            Column(Modifier.selectableGroup().padding(horizontal = Spacing.sm)) {
                listOf(0 to "Immediately when I leave", 60 to "After 1 minute", 300 to "After 5 minutes", 900 to "After 15 minutes").forEach { (sec, label) ->
                    OptionRow(label, null, settings.lockTimeoutSec == sec) { appVm.setLockTimeout(sec) }
                }
            }
        }
    }
    Spacer(Modifier.height(Spacing.xl))

    Label("Screen privacy")
    Group {
        SwitchRow(
            "Block screenshots and hide in app switcher",
            "Stops screenshots and screen recording of this app, and blanks it in recent apps",
            settings.blockScreenshots,
        ) { appVm.setBlockScreenshots(it) }
    }
    Spacer(Modifier.height(Spacing.xl))

    Label("How your mail is protected")
    PrivoraCard(Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(Spacing.sm)) {
            Text("• Mail connections use TLS with certificate checking.")
            Text("• Your password is encrypted with the Android Keystore.")
            Text("• Emails show as plain text. Remote images and tracking pixels never load.")
            Text("• No email content is saved on this device.")
            Text("See the Privacy tab for the full list, including what is not available yet.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
    Spacer(Modifier.height(Spacing.xl))

    Label("Your data on this device")
    OutlinedButton(onClick = { confirmWipe = true }, modifier = Modifier.fillMaxWidth()) {
        Text("Remove all accounts from this device", color = MaterialTheme.colorScheme.error)
    }
    Spacer(Modifier.height(Spacing.xl))

    if (confirmWipe) {
        AlertDialog(
            onDismissRequest = { confirmWipe = false },
            title = { Text("Remove all accounts?") },
            text = { Text("Saved passwords are deleted from this device. Your email stays safe on the servers.") },
            confirmButton = { TextButton(onClick = { mailVm.removeAllAccounts(); confirmWipe = false }) { Text("Remove all") } },
            dismissButton = { TextButton(onClick = { confirmWipe = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun ColumnScope.AboutPage() {
    val context = LocalContext.current
    val version = remember {
        runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull() ?: "unknown"
    }
    PrivoraCard(Modifier.fillMaxWidth()) {
        Column {
            Text("PRIVORA MAIL", style = MaterialTheme.typography.titleMedium)
            Text("Privacy Without Compromise.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(Spacing.sm))
            Text("Version $version (development build)", style = MaterialTheme.typography.bodyMedium)
        }
    }
    Spacer(Modifier.height(Spacing.md))
    Text(
        "A development build. Privacy policy and terms will be linked here once they exist.",
        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

// ---------------------------------------------------------------- building blocks

private fun openUrl(handler: androidx.compose.ui.platform.UriHandler, url: String) {
    runCatching { handler.openUri(url) }
}

@Composable
private fun Label(text: String) {
    Text(
        text, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(bottom = Spacing.sm).semantics { heading() },
    )
}

@Composable
private fun Group(content: @Composable ColumnScope.() -> Unit) {
    PrivoraCard(Modifier.fillMaxWidth(), contentPadding = PaddingValues(0.dp)) { Column(content = content) }
}

@Composable
private fun RowDivider() {
    HorizontalDivider(color = Privora.extras.border, modifier = Modifier.padding(start = 56.dp))
}

@Composable
private fun Chevron() {
    Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
private fun SettingsRow(icon: ImageVector, title: String, subtitle: String?, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().heightIn(min = 60.dp)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = Spacing.lg, vertical = Spacing.md),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(Spacing.lg))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Chevron()
    }
}

@Composable
private fun SwitchRow(title: String, subtitle: String?, checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().heightIn(min = 60.dp)
            .toggleable(value = checked, enabled = enabled, role = Role.Switch, onValueChange = onChange)
            .padding(horizontal = Spacing.lg, vertical = Spacing.md),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.width(Spacing.md))
        Switch(checked = checked, onCheckedChange = null, enabled = enabled)
    }
}

@Composable
private fun OptionRow(title: String, description: String?, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().heightIn(min = Spacing.minTouch)
            .selectable(selected = selected, onClick = onClick, role = Role.RadioButton)
            .padding(horizontal = Spacing.md, vertical = Spacing.sm),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = null)
        Spacer(Modifier.width(Spacing.md))
        Column {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (description != null) Text(description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
