package app.privora.mail.ui.settings

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import app.privora.mail.core.data.AppSettings
import app.privora.mail.core.design.MotionMode
import app.privora.mail.core.design.PrivoraCard
import app.privora.mail.core.design.Spacing
import app.privora.mail.core.design.ThemeMode

@Composable
fun SettingsScreen(
    settings: AppSettings,
    onTheme: (ThemeMode) -> Unit,
    onMotion: (MotionMode) -> Unit,
) {
    val context = LocalContext.current
    val version = remember {
        runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull() ?: "unknown"
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(Spacing.lg)) {
        Text("Settings", style = MaterialTheme.typography.titleLarge, modifier = Modifier.semantics { heading() })
        Spacer(Modifier.height(Spacing.xl))

        SectionLabel("Theme")
        PrivoraCard(Modifier.fillMaxWidth(), contentPadding = PaddingValues(vertical = Spacing.xs, horizontal = Spacing.sm)) {
            Column(Modifier.selectableGroup()) {
                OptionRow("System default", "Follow your device setting", settings.themeMode == ThemeMode.System) { onTheme(ThemeMode.System) }
                OptionRow("Dark", null, settings.themeMode == ThemeMode.Dark) { onTheme(ThemeMode.Dark) }
                OptionRow("Light", null, settings.themeMode == ThemeMode.Light) { onTheme(ThemeMode.Light) }
            }
        }
        Spacer(Modifier.height(Spacing.xl))

        SectionLabel("Motion")
        PrivoraCard(Modifier.fillMaxWidth(), contentPadding = PaddingValues(vertical = Spacing.xs, horizontal = Spacing.sm)) {
            Column(Modifier.selectableGroup()) {
                OptionRow("Full", "All animations as designed", settings.motionMode == MotionMode.Full) { onMotion(MotionMode.Full) }
                OptionRow("Reduced", "Shorter, simpler transitions", settings.motionMode == MotionMode.Reduced) { onMotion(MotionMode.Reduced) }
                OptionRow("Minimal", "Instant changes, no decorative movement", settings.motionMode == MotionMode.Minimal) { onMotion(MotionMode.Minimal) }
            }
        }
        Spacer(Modifier.height(Spacing.sm))
        Text(
            "Android's system setting to remove animations always takes priority over this choice.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(Spacing.xl))

        SectionLabel("About")
        PrivoraCard(Modifier.fillMaxWidth()) {
            Column {
                Text("PRIVORA MAIL", style = MaterialTheme.typography.titleMedium)
                Text("Version $version (development build)", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        // Account, notifications, mail preferences, security, storage, sync, accessibility, privacy policy, terms
        // and support sections are added as the features behind them exist. No inert rows.
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(bottom = Spacing.sm).semantics { heading() },
    )
}

@Composable
private fun OptionRow(title: String, description: String?, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = Spacing.minTouch)
            .selectable(selected = selected, onClick = onClick, role = Role.RadioButton)
            .padding(horizontal = Spacing.sm, vertical = Spacing.sm),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = null)
        Spacer(Modifier.width(Spacing.md))
        Column {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (description != null) {
                Text(description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
