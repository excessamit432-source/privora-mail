package app.privora.mail.core.design

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

enum class ThemeMode { System, Light, Dark }

internal val LocalExtras = staticCompositionLocalOf { DarkExtras }

/** Access point for tokens that Material 3 does not model: `Privora.extras`, `Privora.motion`. */
object Privora {
    val extras: PrivoraExtras
        @Composable @ReadOnlyComposable get() = LocalExtras.current
    val motion: PrivoraMotion
        @Composable @ReadOnlyComposable get() = LocalMotion.current
}

@Composable
fun PrivoraTheme(
    themeMode: ThemeMode,
    motionMode: MotionMode,
    content: @Composable () -> Unit,
) {
    val dark = when (themeMode) {
        ThemeMode.System -> isSystemInDarkTheme()
        ThemeMode.Light -> false
        ThemeMode.Dark -> true
    }
    val effectiveMotion = rememberEffectiveMotionMode(motionMode)
    val motion = remember(effectiveMotion) { PrivoraMotion(effectiveMotion) }

    // Keep system-bar icon contrast correct when the in-app theme differs from the system theme.
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = !dark
                isAppearanceLightNavigationBars = !dark
            }
        }
    }

    CompositionLocalProvider(
        LocalExtras provides if (dark) DarkExtras else LightExtras,
        LocalMotion provides motion,
    ) {
        MaterialTheme(
            colorScheme = if (dark) DarkScheme else LightScheme,
            typography = PrivoraTypography,
            shapes = PrivoraShapes,
            content = content,
        )
    }
}
