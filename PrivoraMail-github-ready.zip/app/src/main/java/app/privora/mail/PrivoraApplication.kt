package app.privora.mail

import android.app.Application
import app.privora.mail.core.data.AccountRepository
import app.privora.mail.core.data.SettingsRepository
import app.privora.mail.core.mail.MailService

/** Manual DI container; Hilt arrives when the graph grows enough to justify it. */
class PrivoraApplication : Application() {
    val settingsRepository: SettingsRepository by lazy { SettingsRepository(this) }
    val accountRepository: AccountRepository by lazy { AccountRepository(this) }
    val mailService: MailService by lazy { MailService() }
}
