package app.privora.mail

import android.app.Application
import app.privora.mail.core.data.SettingsRepository

/** Manual DI container for now; Hilt arrives with the data layer when there is enough to inject. */
class PrivoraApplication : Application() {
    val settingsRepository: SettingsRepository by lazy { SettingsRepository(this) }
}
