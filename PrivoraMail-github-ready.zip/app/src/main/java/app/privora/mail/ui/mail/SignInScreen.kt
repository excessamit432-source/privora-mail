// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (C) 2026 The PRIVORA MAIL authors. See LICENSE-NOTICE.md.
package app.privora.mail.ui.mail

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import app.privora.mail.core.PrivoraConfig
import app.privora.mail.core.design.PrivoraCard
import app.privora.mail.core.design.PrivoraGradientButton
import app.privora.mail.core.design.Spacing
import app.privora.mail.core.design.privoraFieldColors

/** Sign in to a PRIVORA mailbox, then create or unlock its end-to-end encryption key. */
@Composable
fun SignInScreen(
    state: SignInState,
    onContinue: (username: String, password: String) -> Unit,
    onFinish: (passphrase: String, confirm: String) -> Unit,
    onClose: () -> Unit,
) {
    var username by rememberSaveable { mutableStateOf("") }
    var password by rememberSaveable { mutableStateOf("") }
    var passphrase by rememberSaveable { mutableStateOf("") }
    var confirm by rememberSaveable { mutableStateOf("") }
    var understood by rememberSaveable { mutableStateOf(false) }
    var show by rememberSaveable { mutableStateOf(false) }
    val visual = if (show) VisualTransformation.None else PasswordVisualTransformation()

    BackHandler { if (!state.busy) onClose() }

    Column(Modifier.fillMaxSize().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = Spacing.xs), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { if (!state.busy) onClose() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
            Text(
                when (state.stage) {
                    SignInStage.Credentials -> "Sign in to PRIVORA"
                    SignInStage.CreatePassphrase -> "Create your encryption key"
                    SignInStage.EnterPassphrase -> "Unlock your encryption key"
                },
                style = MaterialTheme.typography.titleLarge, modifier = Modifier.semantics { heading() },
            )
        }

        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = Spacing.lg)) {
            when (state.stage) {
                SignInStage.Credentials -> {
                    Text(
                        "Use the PRIVORA address and mailbox password you were given. Your password is encrypted on this device and only ever sent to the PRIVORA server.",
                        style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(Spacing.lg))
                    OutlinedTextField(
                        value = username, onValueChange = { username = it },
                        modifier = Modifier.fillMaxWidth(), label = { Text("Address") }, singleLine = true,
                        suffix = { Text("@${PrivoraConfig.DOMAIN}") },
                        colors = privoraFieldColors(), shape = MaterialTheme.shapes.medium,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email, imeAction = ImeAction.Next),
                    )
                    Spacer(Modifier.height(Spacing.sm))
                    OutlinedTextField(
                        value = password, onValueChange = { password = it },
                        modifier = Modifier.fillMaxWidth(), label = { Text("Mailbox password") }, singleLine = true,
                        visualTransformation = visual,
                        trailingIcon = { VisibilityToggle(show) { show = it } },
                        colors = privoraFieldColors(), shape = MaterialTheme.shapes.medium,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
                    )
                    Spacer(Modifier.height(Spacing.md))
                    Text(
                        "Accounts are created by the server administrator for now. Self-service sign-up isn't available yet.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }

                SignInStage.CreatePassphrase -> {
                    PrivoraCard(Modifier.fillMaxWidth()) {
                        Column {
                            Text("This passphrase protects your encryption key.", style = MaterialTheme.typography.titleSmall)
                            Spacer(Modifier.height(Spacing.xs))
                            Text(
                                "It never leaves this device and it is different from your mailbox password. Nobody, including the server administrator, can reset or recover it. If you forget it you permanently lose access to your encrypted mail.",
                                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                    Spacer(Modifier.height(Spacing.lg))
                    PassphraseField("Encryption passphrase (12+ characters)", passphrase, visual, show, { show = it }) { passphrase = it }
                    Spacer(Modifier.height(Spacing.sm))
                    PassphraseField("Repeat passphrase", confirm, visual, show, { show = it }) { confirm = it }
                    Spacer(Modifier.height(Spacing.md))
                    Row(
                        Modifier.fillMaxWidth().toggleable(value = understood, role = Role.Checkbox, onValueChange = { understood = it }),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Checkbox(checked = understood, onCheckedChange = null)
                        Spacer(Modifier.size(Spacing.sm))
                        Text("I understand that a forgotten passphrase cannot be recovered.", style = MaterialTheme.typography.bodyMedium)
                    }
                }

                SignInStage.EnterPassphrase -> {
                    Text(
                        "This address already has an encryption key. Enter its passphrase to open it on this device. The passphrase is never sent to the server.",
                        style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(Spacing.lg))
                    PassphraseField("Encryption passphrase", passphrase, visual, show, { show = it }) { passphrase = it }
                }
            }

            if (state.error != null) {
                Spacer(Modifier.height(Spacing.md))
                Text(state.error, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
            }
            Spacer(Modifier.height(Spacing.xl))

            if (state.busy) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.secondary)
                    Spacer(Modifier.size(Spacing.md))
                    Text(state.busyLabel)
                }
            } else {
                when (state.stage) {
                    SignInStage.Credentials -> PrivoraGradientButton("Continue", { onContinue(username, password) }, Modifier.fillMaxWidth())
                    SignInStage.CreatePassphrase -> PrivoraGradientButton(
                        "Create encryption key", { onFinish(passphrase, confirm) }, Modifier.fillMaxWidth(), enabled = understood,
                    )
                    SignInStage.EnterPassphrase -> PrivoraGradientButton("Unlock", { onFinish(passphrase, "") }, Modifier.fillMaxWidth())
                }
            }
            Spacer(Modifier.height(Spacing.xxxl))
        }
    }
}

@Composable
private fun VisibilityToggle(shown: Boolean, onChange: (Boolean) -> Unit) {
    IconButton(onClick = { onChange(!shown) }) {
        Icon(
            if (shown) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
            contentDescription = if (shown) "Hide" else "Show",
        )
    }
}

@Composable
private fun PassphraseField(
    label: String, value: String, visual: VisualTransformation, shown: Boolean,
    onShown: (Boolean) -> Unit, onChange: (String) -> Unit,
) {
    OutlinedTextField(
        value = value, onValueChange = onChange, modifier = Modifier.fillMaxWidth(),
        label = { Text(label) }, singleLine = true, visualTransformation = visual,
        trailingIcon = { VisibilityToggle(shown, onShown) },
        colors = privoraFieldColors(), shape = MaterialTheme.shapes.medium,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Next),
    )
}

/** Asks for the encryption passphrase after an app restart (the key only ever lives in memory). */
@Composable
fun UnlockDialog(busy: Boolean, error: String?, onUnlock: (String) -> Unit, onDismiss: () -> Unit) {
    var pass by remember { mutableStateOf("") }
    var show by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text("Unlock encryption") },
        text = {
            Column {
                Text("Enter your encryption passphrase. It stays on this device.", style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(Spacing.md))
                PassphraseField(
                    "Encryption passphrase", pass,
                    if (show) VisualTransformation.None else PasswordVisualTransformation(), show, { show = it },
                ) { pass = it }
                if (error != null) {
                    Spacer(Modifier.height(Spacing.sm))
                    Text(error, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
                if (busy) {
                    Spacer(Modifier.height(Spacing.md))
                    CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp)
                }
            }
        },
        confirmButton = { TextButton(onClick = { onUnlock(pass) }, enabled = !busy && pass.isNotEmpty()) { Text("Unlock") } },
        dismissButton = { TextButton(onClick = onDismiss, enabled = !busy) { Text("Cancel") } },
    )
}
