package app.privora.mail.ui.mail

import android.util.Patterns
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import app.privora.mail.core.design.PrivoraCard
import app.privora.mail.core.design.PrivoraGradientButton
import app.privora.mail.core.design.Spacing
import app.privora.mail.core.design.privoraFieldColors
import app.privora.mail.core.mail.Providers
import app.privora.mail.core.mail.SmtpSecurity

@Composable
fun AddAccountScreen(
    connecting: Boolean,
    error: String?,
    onConnect: (NewAccountInput) -> Unit,
    onClose: () -> Unit,
    onDismissError: () -> Unit,
) {
    var email by rememberSaveable { mutableStateOf("") }
    var password by rememberSaveable { mutableStateOf("") }
    var name by rememberSaveable { mutableStateOf("") }
    var showPassword by rememberSaveable { mutableStateOf(false) }
    var advanced by rememberSaveable { mutableStateOf(false) }
    var imapHost by rememberSaveable { mutableStateOf("") }
    var imapPort by rememberSaveable { mutableStateOf("993") }
    var smtpHost by rememberSaveable { mutableStateOf("") }
    var smtpPort by rememberSaveable { mutableStateOf("465") }
    var security by rememberSaveable { mutableStateOf(SmtpSecurity.SSL) }
    var localError by rememberSaveable { mutableStateOf<String?>(null) }

    val preset = Providers.forEmail(email)
    val unsupported = Providers.unsupportedNote(email)
    val uriHandler = LocalUriHandler.current
    val showServers = advanced || (preset == null && email.contains('@') && unsupported == null)

    LaunchedEffect(preset?.key) {
        if (preset != null) {
            imapHost = preset.imapHost; imapPort = preset.imapPort.toString()
            smtpHost = preset.smtpHost; smtpPort = preset.smtpPort.toString(); security = preset.smtpSecurity
        }
    }
    BackHandler { if (!connecting) onClose() }

    Column(Modifier.fillMaxSize().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = Spacing.xs), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { if (!connecting) onClose() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
            Text("Add email account", style = MaterialTheme.typography.titleLarge, modifier = Modifier.semantics { heading() })
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = Spacing.lg)) {
            Text(
                "Sign in with your existing email account. Your password is encrypted with a key in the Android Keystore and only ever sent to your own mail server.",
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(Spacing.lg))

            OutlinedTextField(
                value = email, onValueChange = { email = it; localError = null; onDismissError() },
                modifier = Modifier.fillMaxWidth(), label = { Text("Email address") }, singleLine = true,
                colors = privoraFieldColors(), shape = MaterialTheme.shapes.medium,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email, imeAction = ImeAction.Next),
            )
            Spacer(Modifier.height(Spacing.sm))
            OutlinedTextField(
                value = password, onValueChange = { password = it; localError = null; onDismissError() },
                modifier = Modifier.fillMaxWidth(), label = { Text(if (preset != null) "App password" else "Password") }, singleLine = true,
                colors = privoraFieldColors(), shape = MaterialTheme.shapes.medium,
                visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Next),
                trailingIcon = {
                    IconButton(onClick = { showPassword = !showPassword }) {
                        Icon(
                            if (showPassword) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                            contentDescription = if (showPassword) "Hide password" else "Show password",
                        )
                    }
                },
            )
            Spacer(Modifier.height(Spacing.sm))
            OutlinedTextField(
                value = name, onValueChange = { name = it },
                modifier = Modifier.fillMaxWidth(), label = { Text("Your name (shown to recipients, optional)") }, singleLine = true,
                colors = privoraFieldColors(), shape = MaterialTheme.shapes.medium,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
            )

            if (unsupported != null) {
                Spacer(Modifier.height(Spacing.md))
                PrivoraCard(Modifier.fillMaxWidth()) { Text(unsupported, style = MaterialTheme.typography.bodyMedium) }
            } else if (preset != null) {
                Spacer(Modifier.height(Spacing.md))
                PrivoraCard(Modifier.fillMaxWidth()) {
                    Column {
                        Text(preset.name, style = MaterialTheme.typography.titleSmall)
                        Text(preset.passwordNote.orEmpty(), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        preset.appPasswordUrl?.let { url ->
                            TextButton(onClick = { runCatching { uriHandler.openUri(url) } }) { Text("Create an app password") }
                        }
                    }
                }
            }

            if (preset != null && !advanced) {
                TextButton(onClick = { advanced = true }) { Text("Show server settings") }
            }
            if (showServers) {
                Spacer(Modifier.height(Spacing.md))
                Text("Server settings", style = MaterialTheme.typography.titleSmall)
                Spacer(Modifier.height(Spacing.sm))
                OutlinedTextField(value = imapHost, onValueChange = { imapHost = it }, modifier = Modifier.fillMaxWidth(),
                    label = { Text("IMAP server (incoming)") }, singleLine = true, colors = privoraFieldColors(), shape = MaterialTheme.shapes.medium,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Next))
                Spacer(Modifier.height(Spacing.sm))
                OutlinedTextField(value = imapPort, onValueChange = { imapPort = it.filter(Char::isDigit) }, modifier = Modifier.fillMaxWidth(),
                    label = { Text("IMAP port (SSL, usually 993)") }, singleLine = true, colors = privoraFieldColors(), shape = MaterialTheme.shapes.medium,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next))
                Spacer(Modifier.height(Spacing.sm))
                OutlinedTextField(value = smtpHost, onValueChange = { smtpHost = it }, modifier = Modifier.fillMaxWidth(),
                    label = { Text("SMTP server (outgoing)") }, singleLine = true, colors = privoraFieldColors(), shape = MaterialTheme.shapes.medium,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Next))
                Spacer(Modifier.height(Spacing.sm))
                OutlinedTextField(value = smtpPort, onValueChange = { smtpPort = it.filter(Char::isDigit) }, modifier = Modifier.fillMaxWidth(),
                    label = { Text("SMTP port (465 SSL or 587 STARTTLS)") }, singleLine = true, colors = privoraFieldColors(), shape = MaterialTheme.shapes.medium,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done))
                Spacer(Modifier.height(Spacing.sm))
                SmtpSecurity.entries.forEach { opt ->
                    Row(
                        Modifier.fillMaxWidth().selectable(selected = security == opt, onClick = { security = opt }, role = Role.RadioButton)
                            .padding(vertical = Spacing.xs),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(Spacing.sm),
                    ) {
                        RadioButton(selected = security == opt, onClick = null)
                        Text(if (opt == SmtpSecurity.SSL) "SSL/TLS (implicit)" else "STARTTLS (required)")
                    }
                }
                Text("Connections are always encrypted. Unencrypted mail servers are not supported.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            val shown = localError ?: error
            if (shown != null) {
                Spacer(Modifier.height(Spacing.md))
                Text(shown, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
            }
            Spacer(Modifier.height(Spacing.xl))

            if (connecting) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.secondary)
                    Spacer(Modifier.size(Spacing.md))
                    Text("Checking incoming and outgoing mail…")
                }
            } else {
                PrivoraGradientButton(
                    text = "Connect",
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        val addr = email.trim()
                        val p = if (showServers) null else preset
                        val iHost = p?.imapHost ?: imapHost.trim()
                        val iPort = p?.imapPort ?: imapPort.toIntOrNull()
                        val sHost = p?.smtpHost ?: smtpHost.trim()
                        val sPort = p?.smtpPort ?: smtpPort.toIntOrNull()
                        val sSec = p?.smtpSecurity ?: security
                        localError = when {
                            !Patterns.EMAIL_ADDRESS.matcher(addr).matches() -> "Enter a valid email address."
                            unsupported != null -> unsupported
                            password.isEmpty() -> "Enter your password."
                            iHost.isBlank() || sHost.isBlank() -> "Enter the IMAP and SMTP server addresses."
                            iPort == null || iPort !in 1..65535 || sPort == null || sPort !in 1..65535 -> "Enter valid port numbers."
                            else -> null
                        }
                        if (localError == null && iPort != null && sPort != null) {
                            onConnect(
                                NewAccountInput(
                                    email = addr, password = password, displayName = name.trim(),
                                    imapHost = iHost, imapPort = iPort, smtpHost = sHost, smtpPort = sPort,
                                    smtpSecurity = sSec, appendSent = preset?.appendSent ?: true,
                                    providerKey = preset?.key ?: "custom",
                                )
                            )
                        }
                    },
                )
            }
            Spacer(Modifier.height(Spacing.xxxl))
        }
    }
}
