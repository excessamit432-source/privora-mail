package app.privora.mail.core.design

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldColors
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Initial-letter avatar; colour is derived from the name so the same sender is always the same colour. */
@Composable
fun PrivoraAvatar(label: String, size: Dp = 44.dp, modifier: Modifier = Modifier) {
    val initial = label.trim().firstOrNull { it.isLetterOrDigit() }?.uppercaseChar()?.toString() ?: "?"
    val palette = listOf(Brand.Purple, Derived.ButtonBlue, Color(0xFF6D28D9), Color(0xFF0F766E), Color(0xFFB4235A))
    val bg = palette[(label.lowercase().hashCode() and Int.MAX_VALUE) % palette.size]
    Box(
        modifier = modifier.size(size).clip(CircleShape).background(bg),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            initial,
            color = Color.White,
            style = MaterialTheme.typography.titleMedium.copy(fontSize = (size.value * 0.4f).sp),
        )
    }
}

@Composable
fun privoraFieldColors(): TextFieldColors = OutlinedTextFieldDefaults.colors(
    focusedContainerColor = MaterialTheme.colorScheme.surfaceContainer,
    unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainer,
    focusedBorderColor = MaterialTheme.colorScheme.secondary,
    unfocusedBorderColor = MaterialTheme.colorScheme.outline,
    cursorColor = MaterialTheme.colorScheme.secondary,
)
