// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (C) 2026 The PRIVORA MAIL authors. See LICENSE-NOTICE.md.
package app.privora.mail.ui.mail

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import app.privora.mail.PrivoraApplication
import app.privora.mail.core.PrivoraConfig
import app.privora.mail.core.crypto.CryptoException
import app.privora.mail.core.crypto.CryptoSession
import app.privora.mail.core.crypto.KeyDirectoryClient
import app.privora.mail.core.crypto.PrivoraCrypto
import app.privora.mail.core.crypto.Verification
import app.privora.mail.core.crypto.WrongPassphraseException
import app.privora.mail.core.data.KeyMaterial
import app.privora.mail.core.mail.MessageSecurity
import org.bouncycastle.openpgp.PGPPublicKeyRing
import java.util.concurrent.ConcurrentHashMap
import app.privora.mail.core.data.AccountRepository
import app.privora.mail.core.data.SettingsRepository
import app.privora.mail.core.mail.FolderMap
import app.privora.mail.core.mail.MailAccount
import app.privora.mail.core.mail.MailBody
import app.privora.mail.core.mail.MailException
import app.privora.mail.core.mail.MailHeader
import app.privora.mail.core.mail.MailService
import app.privora.mail.core.mail.OutgoingMail
import app.privora.mail.core.mail.SmtpSecurity
import app.privora.mail.core.security.SecretBox
import app.privora.mail.ui.main.MailFolder
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID
import javax.mail.Flags

data class DetailState(
    val header: MailHeader,
    val body: MailBody? = null,
    val loading: Boolean = true,
    val error: String? = null,
)

enum class SignInStage { Credentials, CreatePassphrase, EnterPassphrase }

data class SignInState(
    val stage: SignInStage = SignInStage.Credentials,
    val email: String = "",
    val busy: Boolean = false,
    val busyLabel: String = "",
    val error: String? = null,
)

data class MailUiState(
    val accounts: List<MailAccount> = emptyList(),
    val active: MailAccount? = null,
    val folder: MailFolder = MailFolder.Inbox,
    val query: String = "",
    val headers: List<MailHeader> = emptyList(),
    val loading: Boolean = false,
    val error: String? = null,
    val detail: DetailState? = null,
    val sending: Boolean = false,
    val sendError: String? = null,
    /** Recipients who cannot get end-to-end encrypted mail; non-null = ask the user before sending unencrypted. */
    val plainWarning: List<String>? = null,
    val signIn: SignInState = SignInState(),
    val encryptionLocked: Boolean = false,
    val keyFingerprint: String? = null,
    val publicKeyArmored: String? = null,
    val cryptoBusy: Boolean = false,
    val cryptoError: String? = null,
    /** One-shot message for a snackbar. */
    val notice: String? = null,
)

private sealed interface Prepared {
    class Ready(val mail: OutgoingMail, val encrypted: Boolean) : Prepared
    class Confirm(val unreachable: List<String>) : Prepared
}

class MailViewModel(
    private val accounts: AccountRepository,
    private val settings: SettingsRepository,
    private val service: MailService,
    private val keys: KeyDirectoryClient,
    private val session: CryptoSession,
) : ViewModel() {

    private val _state = MutableStateFlow(MailUiState())
    val state: StateFlow<MailUiState> = _state.asStateFlow()

    private val folderMaps = HashMap<String, FolderMap>()
    private var loadJob: Job? = null
    private var lastActiveId: String? = null
    private val keyCache = ConcurrentHashMap<String, String>()
    private var pendingAccount: MailAccount? = null
    private var pendingPassword: String? = null
    private var pendingBlob: String? = null
    private var pendingPlain: OutgoingMail? = null

    init {
        viewModelScope.launch {
            accounts.state.collect { st ->
                // Earlier test builds allowed other providers; this build is PRIVORA-only, so drop those.
                val foreign = st.accounts.filter { !PrivoraConfig.isPrivoraAddress(it.email) }
                foreign.forEach { accounts.remove(it.id) }
                val mine = st.accounts - foreign.toSet()
                val active = st.active?.takeIf { it in mine } ?: mine.firstOrNull()
                _state.update { it.copy(accounts = mine, active = active) }
                val id = active?.id
                if (id != lastActiveId) {
                    lastActiveId = id
                    loadJob?.cancel()
                    _state.update { it.copy(headers = emptyList(), error = null, query = "", detail = null, loading = false, keyFingerprint = null, publicKeyArmored = null) }
                    if (id != null) { refresh(); active?.let { loadKeyInfo(it) } }
                    refreshLockState()
                }
            }
        }
        viewModelScope.launch { session.keys.collect { refreshLockState() } }
    }

    private fun refreshLockState() {
        _state.update { s -> s.copy(encryptionLocked = s.active != null && session.get(s.active.email) == null) }
    }

    private fun loadKeyInfo(acc: MailAccount) {
        viewModelScope.launch {
            val m = accounts.keyMaterial(acc.email) ?: return@launch
            val fp = runCatching { PrivoraCrypto.fingerprint(PrivoraCrypto.parsePublic(m.publicArmored)) }.getOrNull()
            _state.update { it.copy(keyFingerprint = fp, publicKeyArmored = m.publicArmored) }
        }
    }

    // ---------- listing ----------

    fun refresh() {
        val acc = _state.value.active ?: return
        loadJob?.cancel()
        loadJob = viewModelScope.launch {
            _state.update { it.copy(loading = true, error = null) }
            val limit = settings.settings.first().fetchLimit
            val result = runCatching { withContext(Dispatchers.IO) { load(acc, limit) } }
            val list = result.getOrNull()
            if (list != null) {
                _state.update { it.copy(headers = list, loading = false) }
            } else {
                val e = result.exceptionOrNull()
                if (e is CancellationException) throw e
                _state.update { it.copy(loading = false, error = describe(e)) }
            }
        }
    }

    private fun load(acc: MailAccount, limit: Int): List<MailHeader> {
        val pw = accounts.password(acc)
        val st = _state.value
        val maps = folderMaps.getOrPut(acc.id) { service.resolveFolders(acc, pw) }
        val (name, flagged) = when (st.folder) {
            MailFolder.Inbox -> maps.inbox to false
            MailFolder.AllMail -> (maps.all ?: maps.inbox) to false
            MailFolder.Starred -> (maps.all ?: maps.inbox) to true
            MailFolder.Sent -> (maps.sent ?: throw missing("Sent")) to false
            MailFolder.Drafts -> (maps.drafts ?: throw missing("Drafts")) to false
            MailFolder.Spam -> (maps.spam ?: throw missing("Spam")) to false
            MailFolder.Trash -> (maps.trash ?: throw missing("Trash")) to false
        }
        return service.fetchHeaders(acc, pw, name, limit, st.query, flagged)
    }

    private fun missing(what: String) =
        MailException(MailException.Kind.Other, "This account has no $what folder.")

    fun setFolder(f: MailFolder) {
        _state.update { it.copy(folder = f, query = "", headers = emptyList(), error = null) }
        refresh()
    }

    fun setQuery(q: String) {
        if (q == _state.value.query) return
        _state.update { it.copy(query = q) }
        refresh()
    }

    // ---------- reading ----------

    fun open(header: MailHeader) {
        val acc = _state.value.active ?: return
        _state.update { s ->
            s.copy(
                detail = DetailState(header = header.copy(unread = false)),
                headers = s.headers.map { if (same(it, header)) it.copy(unread = false) else it },
            )
        }
        viewModelScope.launch {
            val r = runCatching {
                withContext(Dispatchers.IO) {
                    processBody(acc, service.fetchBody(acc, accounts.password(acc), header.folder, header.uid))
                }
            }
            val body = r.getOrNull()
            _state.update { s ->
                val d = s.detail
                if (d == null || !same(d.header, header)) s
                else if (body != null) s.copy(detail = d.copy(body = body, loading = false))
                else s.copy(detail = d.copy(loading = false, error = describe(r.exceptionOrNull())))
            }
        }
    }

    fun closeDetail() { _state.update { it.copy(detail = null) } }

    private fun same(a: MailHeader, b: MailHeader) = a.uid == b.uid && a.folder == b.folder

    private fun applyLocal(target: MailHeader, change: (MailHeader) -> MailHeader) {
        _state.update { s ->
            s.copy(
                headers = s.headers.map { if (same(it, target)) change(it) else it },
                detail = s.detail?.let { d ->
                    if (same(d.header, target)) {
                        d.copy(header = change(d.header), body = d.body?.let { b -> b.copy(header = change(b.header)) })
                    } else d
                },
            )
        }
    }

    // ---------- actions (optimistic, rolled back on failure) ----------

    fun toggleStar(h: MailHeader) {
        val acc = _state.value.active ?: return
        val newValue = !h.starred
        applyLocal(h) { it.copy(starred = newValue) }
        if (!newValue && _state.value.folder == MailFolder.Starred) {
            _state.update { s -> s.copy(headers = s.headers.filterNot { same(it, h) }) }
        }
        viewModelScope.launch {
            val r = runCatching {
                withContext(Dispatchers.IO) {
                    service.setFlag(acc, accounts.password(acc), h.folder, h.uid, Flags.Flag.FLAGGED, newValue)
                }
            }
            if (r.isFailure) {
                applyLocal(h) { it.copy(starred = !newValue) }
                notice("Couldn't update the star: ${describe(r.exceptionOrNull())}")
            }
        }
    }

    fun markUnread(h: MailHeader) {
        val acc = _state.value.active ?: return
        applyLocal(h) { it.copy(unread = true) }
        closeDetail()
        viewModelScope.launch {
            val r = runCatching {
                withContext(Dispatchers.IO) {
                    service.setFlag(acc, accounts.password(acc), h.folder, h.uid, Flags.Flag.SEEN, false)
                }
            }
            if (r.isFailure) {
                applyLocal(h) { it.copy(unread = false) }
                notice("Couldn't mark as unread: ${describe(r.exceptionOrNull())}")
            }
        }
    }

    fun delete(h: MailHeader) {
        val acc = _state.value.active ?: return
        _state.update { s -> s.copy(headers = s.headers.filterNot { same(it, h) }, detail = null) }
        viewModelScope.launch {
            val r = runCatching {
                withContext(Dispatchers.IO) {
                    val pw = accounts.password(acc)
                    val maps = folderMaps.getOrPut(acc.id) { service.resolveFolders(acc, pw) }
                    service.delete(acc, pw, h.folder, h.uid, maps.trash)
                }
            }
            if (r.isFailure) {
                notice(describe(r.exceptionOrNull()))
                refresh()
            } else {
                notice(if (h.folder == folderMaps[acc.id]?.trash) "Deleted permanently" else "Moved to Trash")
            }
        }
    }

    // ---------- encryption helpers ----------

    private fun publicKey(email: String): String? {
        val e = email.lowercase()
        keyCache[e]?.let { return it }
        return keys.getPublicKey(e)?.also { keyCache[e] = it }
    }

    private fun splitAddresses(raw: String): List<String> =
        raw.split(',', ';').map { part ->
            val t = part.trim()
            (Regex("<([^>]+)>").find(t)?.groupValues?.get(1) ?: t).trim().lowercase()
        }.filter { it.isNotEmpty() }

    private fun senderKeyRings(from: String, myEmail: String, myRing: PGPPublicKeyRing): List<PGPPublicKeyRing> {
        if (from.equals(myEmail, ignoreCase = true)) return listOf(myRing)
        val armored = if (PrivoraConfig.isPrivoraAddress(from)) runCatching { publicKey(from) }.getOrNull() else null
        return armored?.let { listOf(PrivoraCrypto.parsePublic(it)) } ?: emptyList()
    }

    /** Decrypts PRIVORA end-to-end messages. The lock badge is only ever set from what was actually verified here. */
    private fun processBody(acc: MailAccount, body: MailBody): MailBody {
        val armored = PrivoraCrypto.extractArmoredMessage(body.text) ?: return body
        val me = session.get(acc.email) ?: return body.copy(
            text = "", security = MessageSecurity.EncryptedLocked,
            securityNote = "This message is end-to-end encrypted. Unlock encryption to read it.",
        )
        return try {
            val d = PrivoraCrypto.decrypt(armored, me, senderKeyRings(body.header.fromAddress, acc.email, me.publicRing))
            when (d.verification) {
                Verification.Verified -> body.copy(text = d.text, security = MessageSecurity.EncryptedVerified)
                Verification.Invalid -> body.copy(
                    text = d.text, security = MessageSecurity.EncryptedBadSignature,
                    securityNote = "The sender's signature did NOT match. This message may have been forged or altered.",
                )
                else -> body.copy(
                    text = d.text, security = MessageSecurity.EncryptedUnverified,
                    securityNote = "The sender couldn't be verified (no signature, or their key wasn't found).",
                )
            }
        } catch (e: Exception) {
            body.copy(text = "", security = MessageSecurity.EncryptedFailed, securityNote = e.message ?: "Could not decrypt this message.")
        }
    }

    private fun prepare(acc: MailAccount, mail: OutgoingMail, allowPlain: Boolean): Prepared {
        val recipients = (splitAddresses(mail.to) + splitAddresses(mail.cc) + splitAddresses(mail.bcc)).distinct()
        if (recipients.isEmpty()) throw MailException(MailException.Kind.Other, "Add at least one recipient.")
        val rings = ArrayList<PGPPublicKeyRing>()
        val unreachable = ArrayList<String>()
        for (r in recipients) {
            val armored = if (PrivoraConfig.isPrivoraAddress(r)) publicKey(r) else null
            if (armored == null) unreachable.add(r) else rings.add(PrivoraCrypto.parsePublic(armored))
        }
        if (unreachable.isEmpty()) {
            val me = session.get(acc.email) ?: throw MailException(
                MailException.Kind.Other, "Unlock encryption first to send end-to-end encrypted mail."
            )
            val everyone = rings.toMutableList().apply { add(me.publicRing) }
            val sealed = PrivoraCrypto.encryptSigned(mail.body, everyone, me)   // sender included: Sent stays readable
            return Prepared.Ready(mail.copy(body = sealed), true)
        }
        if (!allowPlain) return Prepared.Confirm(unreachable)
        return Prepared.Ready(mail, false)
    }

    // ---------- sending ----------

    fun send(mail: OutgoingMail, onSent: () -> Unit) = sendInternal(mail, false, onSent)

    fun confirmPlainSend(onSent: () -> Unit) {
        val m = pendingPlain ?: return
        pendingPlain = null
        _state.update { it.copy(plainWarning = null) }
        sendInternal(m, true, onSent)
    }

    fun cancelPlainSend() {
        pendingPlain = null
        _state.update { it.copy(plainWarning = null) }
    }

    private fun sendInternal(mail: OutgoingMail, allowPlain: Boolean, onSent: () -> Unit) {
        val acc = _state.value.active ?: return
        if (_state.value.sending) return
        _state.update { it.copy(sending = true, sendError = null) }
        viewModelScope.launch {
            val r = runCatching {
                withContext(Dispatchers.IO) {
                    val prepared = prepare(acc, mail, allowPlain)
                    if (prepared is Prepared.Ready) {
                        val pw = accounts.password(acc)
                        val sent = runCatching { folderMaps.getOrPut(acc.id) { service.resolveFolders(acc, pw) }.sent }.getOrNull()
                        service.send(acc, pw, prepared.mail, sent)
                    }
                    prepared
                }
            }
            val prepared = r.getOrNull()
            when {
                prepared is Prepared.Confirm -> {
                    pendingPlain = mail
                    _state.update { it.copy(sending = false, plainWarning = prepared.unreachable) }
                }
                prepared is Prepared.Ready -> {
                    val label = if (prepared.encrypted) "Message sent, end-to-end encrypted" else "Message sent (NOT end-to-end encrypted)"
                    _state.update { it.copy(sending = false, notice = label) }
                    onSent()
                    if (_state.value.folder == MailFolder.Sent) refresh()
                }
                else -> _state.update { it.copy(sending = false, sendError = describe(r.exceptionOrNull())) }
            }
        }
    }

    // ---------- sign-in and encryption ----------

    private fun setSignIn(change: (SignInState) -> SignInState) { _state.update { it.copy(signIn = change(it.signIn)) } }

    /** Step 1: verify the mailbox, then find out whether this address already has an encryption key. */
    fun startSignIn(username: String, password: String) {
        if (_state.value.signIn.busy) return
        val email = PrivoraConfig.normalizeAddress(username)
        when {
            email == null -> { setSignIn { it.copy(error = "Enter your PRIVORA address (name@${PrivoraConfig.DOMAIN}) or just the part before the @.") }; return }
            password.isEmpty() -> { setSignIn { it.copy(error = "Enter your mailbox password.") }; return }
            _state.value.accounts.any { it.email == email } -> { setSignIn { it.copy(error = "You're already signed in with this address.") }; return }
        }
        val address = email ?: return
        setSignIn { it.copy(busy = true, busyLabel = "Checking your mailbox…", error = null, email = address) }
        viewModelScope.launch {
            val r = runCatching {
                withContext(Dispatchers.IO) {
                    val account = MailAccount(
                        id = UUID.randomUUID().toString(), email = address, displayName = "",
                        imapHost = PrivoraConfig.IMAP_HOST, imapPort = PrivoraConfig.IMAP_PORT,
                        smtpHost = PrivoraConfig.SMTP_HOST, smtpPort = PrivoraConfig.SMTP_PORT,
                        smtpSecurity = SmtpSecurity.SSL, appendSent = true, providerKey = "privora",
                        encryptedPassword = SecretBox.encrypt(password),
                    )
                    service.testConnection(account, password)
                    account to keys.getBackup(address, password)
                }
            }
            val found = r.getOrNull()
            if (found == null) {
                setSignIn { it.copy(busy = false, error = describe(r.exceptionOrNull())) }
                return@launch
            }
            pendingAccount = found.first
            pendingPassword = password
            pendingBlob = found.second
            setSignIn {
                SignInState(
                    stage = if (found.second == null) SignInStage.CreatePassphrase else SignInStage.EnterPassphrase,
                    email = address,
                )
            }
        }
    }

    /** Step 2: create a brand-new key (new address) or unlock the existing one (returning address). */
    fun finishSignIn(passphrase: String, confirm: String, onDone: () -> Unit) {
        val acc = pendingAccount ?: return
        val pw = pendingPassword ?: return
        val st = _state.value.signIn
        if (st.busy) return
        val creating = st.stage == SignInStage.CreatePassphrase
        val problem = when {
            creating && passphrase.length < 12 -> "Use at least 12 characters. Longer is better: a few random words work well."
            creating && passphrase != confirm -> "The two passphrases don't match."
            !creating && passphrase.isEmpty() -> "Enter your encryption passphrase."
            else -> null
        }
        if (problem != null) { setSignIn { it.copy(error = problem) }; return }

        setSignIn { it.copy(busy = true, error = null, busyLabel = if (creating) "Creating your encryption key… this takes a few seconds" else "Unlocking…") }
        viewModelScope.launch {
            val r = runCatching {
                withContext(Dispatchers.Default) {
                    if (creating) {
                        val fresh = PrivoraCrypto.createKey(acc.email, passphrase)
                        withContext(Dispatchers.IO) { keys.publish(acc.email, pw, fresh.publicArmored, fresh.blobJson) }
                        Triple(fresh.unlocked, fresh.publicArmored, fresh.blobJson)
                    } else {
                        val blob = pendingBlob ?: throw CryptoException("The key backup is missing. Please start again.")
                        val u = PrivoraCrypto.unlock(acc.email, blob, passphrase)
                        Triple(u, PrivoraCrypto.armorPublic(u.publicRing), blob)
                    }
                }
            }
            val done = r.getOrNull()
            if (done == null) {
                setSignIn { it.copy(busy = false, error = describe(r.exceptionOrNull())) }
                return@launch
            }
            accounts.saveKeyMaterial(acc.email, KeyMaterial(done.second, done.third))
            session.put(done.first)
            accounts.add(acc)
            pendingAccount = null; pendingPassword = null; pendingBlob = null
            _state.update { it.copy(signIn = SignInState(), notice = "Signed in as ${acc.email}") }
            onDone()
        }
    }

    fun cancelSignIn() {
        pendingAccount = null; pendingPassword = null; pendingBlob = null
        _state.update { it.copy(signIn = SignInState()) }
    }

    /** After an app restart the key is locked (it only ever lives in memory); the passphrase reopens it. */
    fun unlockEncryption(passphrase: String, onDone: () -> Unit) {
        val acc = _state.value.active ?: return
        if (_state.value.cryptoBusy) return
        _state.update { it.copy(cryptoBusy = true, cryptoError = null) }
        viewModelScope.launch {
            val r = runCatching {
                withContext(Dispatchers.Default) {
                    val m = accounts.keyMaterial(acc.email)
                        ?: throw CryptoException("No key is stored on this device. Sign out and sign in again.")
                    PrivoraCrypto.unlock(acc.email, m.backupBlob, passphrase)
                }
            }
            val key = r.getOrNull()
            if (key == null) {
                _state.update { it.copy(cryptoBusy = false, cryptoError = describe(r.exceptionOrNull())) }
            } else {
                session.put(key)
                _state.update { it.copy(cryptoBusy = false, cryptoError = null) }
                _state.value.detail?.let { open(it.header) }   // re-read an open encrypted message
                onDone()
            }
        }
    }

    fun lockEncryption() {
        _state.value.active?.let { session.lock(it.email) }
    }

    fun changePassphrase(old: String, new: String, confirm: String, onDone: () -> Unit) {
        val acc = _state.value.active ?: return
        if (_state.value.cryptoBusy) return
        val problem = when {
            new.length < 12 -> "Use at least 12 characters."
            new != confirm -> "The new passphrases don't match."
            else -> null
        }
        if (problem != null) { _state.update { it.copy(cryptoError = problem) }; return }
        _state.update { it.copy(cryptoBusy = true, cryptoError = null) }
        viewModelScope.launch {
            val r = runCatching {
                withContext(Dispatchers.Default) {
                    val m = accounts.keyMaterial(acc.email) ?: throw CryptoException("No key is stored on this device.")
                    val fresh = PrivoraCrypto.changePassphrase(acc.email, m.backupBlob, old, new)
                    withContext(Dispatchers.IO) { keys.publish(acc.email, accounts.password(acc), fresh.publicArmored, fresh.blobJson) }
                    accounts.saveKeyMaterial(acc.email, KeyMaterial(fresh.publicArmored, fresh.blobJson))
                    fresh
                }
            }
            val fresh = r.getOrNull()
            if (fresh == null) {
                _state.update { it.copy(cryptoBusy = false, cryptoError = describe(r.exceptionOrNull())) }
            } else {
                session.put(fresh.unlocked)
                _state.update { it.copy(cryptoBusy = false, cryptoError = null, notice = "Encryption passphrase changed") }
                onDone()
            }
        }
    }

    fun dismissCryptoError() { _state.update { it.copy(cryptoError = null) } }

    // ---------- accounts ----------

    fun setActive(id: String) { viewModelScope.launch { accounts.setActive(id) } }

    fun removeAccount(id: String) {
        folderMaps.remove(id)
        _state.value.accounts.firstOrNull { it.id == id }?.let { session.lock(it.email) }
        viewModelScope.launch { accounts.remove(id) }
    }

    fun removeAllAccounts() {
        folderMaps.clear()
        session.lockAll()
        viewModelScope.launch { accounts.clearAll() }
    }

    // ---------- misc ----------

    fun consumeNotice() { _state.update { it.copy(notice = null) } }
    fun dismissSendError() { _state.update { it.copy(sendError = null) } }

    private fun notice(text: String) { _state.update { it.copy(notice = text) } }

    private fun describe(e: Throwable?): String = when (e) {
        null -> "Something went wrong."
        is MailException -> e.message ?: "Mail error."
        is WrongPassphraseException -> e.message ?: "Wrong encryption passphrase."
        is CryptoException -> e.message ?: "Encryption error."
        is java.security.GeneralSecurityException ->
            "Your saved password could not be read (secure key changed). Remove the account and add it again."
        else -> e.message ?: "Something went wrong."
    }

    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val app = this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as PrivoraApplication
                MailViewModel(app.accountRepository, app.settingsRepository, app.mailService, app.keyDirectory, app.cryptoSession)
            }
        }
    }
}
