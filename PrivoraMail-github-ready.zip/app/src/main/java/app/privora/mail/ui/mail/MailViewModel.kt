package app.privora.mail.ui.mail

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import app.privora.mail.PrivoraApplication
import app.privora.mail.core.data.AccountRepository
import app.privora.mail.core.data.SettingsRepository
import app.privora.mail.core.mail.FolderMap
import app.privora.mail.core.mail.MailAccount
import app.privora.mail.core.mail.MailBody
import app.privora.mail.core.mail.MailException
import app.privora.mail.core.mail.MailHeader
import app.privora.mail.core.mail.MailService
import app.privora.mail.core.mail.OutgoingMail
import app.privora.mail.core.mail.SmtpSecurity
import app.privora.mail.core.security.SecretBox
import app.privora.mail.ui.main.MailFolder
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID
import javax.mail.Flags

data class DetailState(
    val header: MailHeader,
    val body: MailBody? = null,
    val loading: Boolean = true,
    val error: String? = null,
)

data class MailUiState(
    val accounts: List<MailAccount> = emptyList(),
    val active: MailAccount? = null,
    val folder: MailFolder = MailFolder.Inbox,
    val query: String = "",
    val headers: List<MailHeader> = emptyList(),
    val loading: Boolean = false,
    val error: String? = null,
    val detail: DetailState? = null,
    val sending: Boolean = false,
    val sendError: String? = null,
    val connecting: Boolean = false,
    val connectError: String? = null,
    /** One-shot message for a snackbar. */
    val notice: String? = null,
)

data class NewAccountInput(
    val email: String,
    val password: String,
    val displayName: String,
    val imapHost: String,
    val imapPort: Int,
    val smtpHost: String,
    val smtpPort: Int,
    val smtpSecurity: SmtpSecurity,
    val appendSent: Boolean,
    val providerKey: String,
)

class MailViewModel(
    private val accounts: AccountRepository,
    private val settings: SettingsRepository,
    private val service: MailService,
) : ViewModel() {

    private val _state = MutableStateFlow(MailUiState())
    val state: StateFlow<MailUiState> = _state.asStateFlow()

    private val folderMaps = HashMap<String, FolderMap>()
    private var loadJob: Job? = null
    private var lastActiveId: String? = null

    init {
        viewModelScope.launch {
            accounts.state.collect { s ->
                _state.update { it.copy(accounts = s.accounts, active = s.active) }
                val id = s.active?.id
                if (id != lastActiveId) {
                    lastActiveId = id
                    loadJob?.cancel()
                    _state.update { it.copy(headers = emptyList(), error = null, query = "", detail = null, loading = false) }
                    if (id != null) refresh()
                }
            }
        }
    }

    // ---------- listing ----------

    fun refresh() {
        val acc = _state.value.active ?: return
        loadJob?.cancel()
        loadJob = viewModelScope.launch {
            _state.update { it.copy(loading = true, error = null) }
            val limit = settings.settings.first().fetchLimit
            val result = runCatching { withContext(Dispatchers.IO) { load(acc, limit) } }
            val list = result.getOrNull()
            if (list != null) {
                _state.update { it.copy(headers = list, loading = false) }
            } else {
                val e = result.exceptionOrNull()
                if (e is CancellationException) throw e
                _state.update { it.copy(loading = false, error = describe(e)) }
            }
        }
    }

    private fun load(acc: MailAccount, limit: Int): List<MailHeader> {
        val pw = accounts.password(acc)
        val st = _state.value
        val maps = folderMaps.getOrPut(acc.id) { service.resolveFolders(acc, pw) }
        val (name, flagged) = when (st.folder) {
            MailFolder.Inbox -> maps.inbox to false
            MailFolder.AllMail -> (maps.all ?: maps.inbox) to false
            MailFolder.Starred -> (maps.all ?: maps.inbox) to true
            MailFolder.Sent -> (maps.sent ?: throw missing("Sent")) to false
            MailFolder.Drafts -> (maps.drafts ?: throw missing("Drafts")) to false
            MailFolder.Spam -> (maps.spam ?: throw missing("Spam")) to false
            MailFolder.Trash -> (maps.trash ?: throw missing("Trash")) to false
        }
        return service.fetchHeaders(acc, pw, name, limit, st.query, flagged)
    }

    private fun missing(what: String) =
        MailException(MailException.Kind.Other, "This account has no $what folder.")

    fun setFolder(f: MailFolder) {
        _state.update { it.copy(folder = f, query = "", headers = emptyList(), error = null) }
        refresh()
    }

    fun setQuery(q: String) {
        if (q == _state.value.query) return
        _state.update { it.copy(query = q) }
        refresh()
    }

    // ---------- reading ----------

    fun open(header: MailHeader) {
        val acc = _state.value.active ?: return
        _state.update { s ->
            s.copy(
                detail = DetailState(header = header.copy(unread = false)),
                headers = s.headers.map { if (same(it, header)) it.copy(unread = false) else it },
            )
        }
        viewModelScope.launch {
            val r = runCatching {
                withContext(Dispatchers.IO) { service.fetchBody(acc, accounts.password(acc), header.folder, header.uid) }
            }
            val body = r.getOrNull()
            _state.update { s ->
                val d = s.detail
                if (d == null || !same(d.header, header)) s
                else if (body != null) s.copy(detail = d.copy(body = body, loading = false))
                else s.copy(detail = d.copy(loading = false, error = describe(r.exceptionOrNull())))
            }
        }
    }

    fun closeDetail() { _state.update { it.copy(detail = null) } }

    private fun same(a: MailHeader, b: MailHeader) = a.uid == b.uid && a.folder == b.folder

    private fun applyLocal(target: MailHeader, change: (MailHeader) -> MailHeader) {
        _state.update { s ->
            s.copy(
                headers = s.headers.map { if (same(it, target)) change(it) else it },
                detail = s.detail?.let { d ->
                    if (same(d.header, target)) {
                        d.copy(header = change(d.header), body = d.body?.let { b -> b.copy(header = change(b.header)) })
                    } else d
                },
            )
        }
    }

    // ---------- actions (optimistic, rolled back on failure) ----------

    fun toggleStar(h: MailHeader) {
        val acc = _state.value.active ?: return
        val newValue = !h.starred
        applyLocal(h) { it.copy(starred = newValue) }
        if (!newValue && _state.value.folder == MailFolder.Starred) {
            _state.update { s -> s.copy(headers = s.headers.filterNot { same(it, h) }) }
        }
        viewModelScope.launch {
            val r = runCatching {
                withContext(Dispatchers.IO) {
                    service.setFlag(acc, accounts.password(acc), h.folder, h.uid, Flags.Flag.FLAGGED, newValue)
                }
            }
            if (r.isFailure) {
                applyLocal(h) { it.copy(starred = !newValue) }
                notice("Couldn't update the star: ${describe(r.exceptionOrNull())}")
            }
        }
    }

    fun markUnread(h: MailHeader) {
        val acc = _state.value.active ?: return
        applyLocal(h) { it.copy(unread = true) }
        closeDetail()
        viewModelScope.launch {
            val r = runCatching {
                withContext(Dispatchers.IO) {
                    service.setFlag(acc, accounts.password(acc), h.folder, h.uid, Flags.Flag.SEEN, false)
                }
            }
            if (r.isFailure) {
                applyLocal(h) { it.copy(unread = false) }
                notice("Couldn't mark as unread: ${describe(r.exceptionOrNull())}")
            }
        }
    }

    fun delete(h: MailHeader) {
        val acc = _state.value.active ?: return
        _state.update { s -> s.copy(headers = s.headers.filterNot { same(it, h) }, detail = null) }
        viewModelScope.launch {
            val r = runCatching {
                withContext(Dispatchers.IO) {
                    val pw = accounts.password(acc)
                    val maps = folderMaps.getOrPut(acc.id) { service.resolveFolders(acc, pw) }
                    service.delete(acc, pw, h.folder, h.uid, maps.trash)
                }
            }
            if (r.isFailure) {
                notice(describe(r.exceptionOrNull()))
                refresh()
            } else {
                notice(if (h.folder == folderMaps[acc.id]?.trash) "Deleted permanently" else "Moved to Trash")
            }
        }
    }

    // ---------- sending ----------

    fun send(mail: OutgoingMail, onSent: () -> Unit) {
        val acc = _state.value.active ?: return
        if (_state.value.sending) return
        _state.update { it.copy(sending = true, sendError = null) }
        viewModelScope.launch {
            val r = runCatching {
                withContext(Dispatchers.IO) {
                    val pw = accounts.password(acc)
                    val sent = if (acc.appendSent) {
                        runCatching { folderMaps.getOrPut(acc.id) { service.resolveFolders(acc, pw) }.sent }.getOrNull()
                    } else null
                    service.send(acc, pw, mail, sent)
                }
            }
            if (r.isSuccess) {
                _state.update { it.copy(sending = false, notice = "Message sent") }
                onSent()
                if (_state.value.folder == MailFolder.Sent) refresh()
            } else {
                _state.update { it.copy(sending = false, sendError = describe(r.exceptionOrNull())) }
            }
        }
    }

    // ---------- accounts ----------

    fun addAccount(input: NewAccountInput, onDone: () -> Unit) {
        if (_state.value.connecting) return
        if (_state.value.accounts.any { it.email.equals(input.email, ignoreCase = true) }) {
            _state.update { it.copy(connectError = "This account is already connected.") }
            return
        }
        _state.update { it.copy(connecting = true, connectError = null) }
        viewModelScope.launch {
            val r = runCatching {
                withContext(Dispatchers.IO) {
                    val account = MailAccount(
                        id = UUID.randomUUID().toString(),
                        email = input.email, displayName = input.displayName,
                        imapHost = input.imapHost, imapPort = input.imapPort,
                        smtpHost = input.smtpHost, smtpPort = input.smtpPort,
                        smtpSecurity = input.smtpSecurity, appendSent = input.appendSent,
                        providerKey = input.providerKey,
                        encryptedPassword = SecretBox.encrypt(input.password),
                    )
                    service.testConnection(account, input.password)
                    account
                }
            }
            val account = r.getOrNull()
            if (account != null) {
                accounts.add(account)
                _state.update { it.copy(connecting = false, notice = "${account.email} connected") }
                onDone()
            } else {
                _state.update { it.copy(connecting = false, connectError = describe(r.exceptionOrNull())) }
            }
        }
    }

    fun setActive(id: String) { viewModelScope.launch { accounts.setActive(id) } }

    fun removeAccount(id: String) {
        folderMaps.remove(id)
        viewModelScope.launch { accounts.remove(id) }
    }

    fun removeAllAccounts() {
        folderMaps.clear()
        viewModelScope.launch { accounts.clearAll() }
    }

    // ---------- misc ----------

    fun consumeNotice() { _state.update { it.copy(notice = null) } }
    fun dismissSendError() { _state.update { it.copy(sendError = null) } }
    fun dismissConnectError() { _state.update { it.copy(connectError = null) } }

    private fun notice(text: String) { _state.update { it.copy(notice = text) } }

    private fun describe(e: Throwable?): String = when (e) {
        null -> "Something went wrong."
        is MailException -> e.message ?: "Mail error."
        is java.security.GeneralSecurityException ->
            "Your saved password could not be read (secure key changed). Remove the account and add it again."
        else -> e.message ?: "Something went wrong."
    }

    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val app = this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as PrivoraApplication
                MailViewModel(app.accountRepository, app.settingsRepository, app.mailService)
            }
        }
    }
}
