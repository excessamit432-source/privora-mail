// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (C) 2026 The PRIVORA MAIL authors. See LICENSE-NOTICE.md.
package app.privora.mail.core.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import app.privora.mail.core.mail.MailAccount
import app.privora.mail.core.mail.SmtpSecurity
import app.privora.mail.core.security.SecretBox
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

private val Context.accountStore by preferencesDataStore(name = "privora_accounts")

data class AccountState(
    val accounts: List<MailAccount> = emptyList(),
    val activeId: String? = null,
) {
    val active: MailAccount? get() = accounts.firstOrNull { it.id == activeId } ?: accounts.firstOrNull()
}

/** Local copy of the user's public key and passphrase-protected key backup (both safe to store). */
data class KeyMaterial(val publicArmored: String, val backupBlob: String)

/** Account metadata lives here; the password inside each account is Keystore-encrypted (see SecretBox). */
class AccountRepository(private val context: Context) {

    private object Keys {
        val accounts = stringPreferencesKey("accounts_json")
        val active = stringPreferencesKey("active_account_id")
    }

    val state: Flow<AccountState> = context.accountStore.data
        .catch { e -> if (e is IOException) emit(emptyPreferences()) else throw e }
        .map { p ->
            val list = runCatching { parse(p[Keys.accounts].orEmpty()) }.getOrDefault(emptyList())
            AccountState(list, p[Keys.active])
        }

    suspend fun add(account: MailAccount) {
        context.accountStore.edit { p ->
            val list = runCatching { parse(p[Keys.accounts].orEmpty()) }.getOrDefault(emptyList())
            p[Keys.accounts] = serialize(list + account)
            p[Keys.active] = account.id
        }
    }

    suspend fun remove(id: String) {
        context.accountStore.edit { p ->
            val list = runCatching { parse(p[Keys.accounts].orEmpty()) }.getOrDefault(emptyList())
            val rest = list.filterNot { it.id == id }
            list.firstOrNull { it.id == id }?.let { gone ->
                p.remove(stringPreferencesKey("pub:" + gone.email.lowercase()))
                p.remove(stringPreferencesKey("blob:" + gone.email.lowercase()))
            }
            p[Keys.accounts] = serialize(rest)
            if (p[Keys.active] == id) {
                rest.firstOrNull()?.let { p[Keys.active] = it.id } ?: p.remove(Keys.active)
            }
        }
    }

    suspend fun saveKeyMaterial(email: String, material: KeyMaterial) {
        context.accountStore.edit {
            it[stringPreferencesKey("pub:" + email.lowercase())] = material.publicArmored
            it[stringPreferencesKey("blob:" + email.lowercase())] = material.backupBlob
        }
    }

    suspend fun keyMaterial(email: String): KeyMaterial? {
        val p = context.accountStore.data.first()
        val pub = p[stringPreferencesKey("pub:" + email.lowercase())] ?: return null
        val blob = p[stringPreferencesKey("blob:" + email.lowercase())] ?: return null
        return KeyMaterial(pub, blob)
    }

    suspend fun setActive(id: String) { context.accountStore.edit { it[Keys.active] = id } }

    suspend fun clearAll() { context.accountStore.edit { it.clear() } }

    /** Throws if the Keystore key is gone (e.g. after a device reset). Callers surface "re-add account". */
    fun password(account: MailAccount): String = SecretBox.decrypt(account.encryptedPassword)

    private fun serialize(list: List<MailAccount>): String {
        val arr = JSONArray()
        list.forEach { a ->
            arr.put(
                JSONObject()
                    .put("id", a.id).put("email", a.email).put("displayName", a.displayName)
                    .put("imapHost", a.imapHost).put("imapPort", a.imapPort)
                    .put("smtpHost", a.smtpHost).put("smtpPort", a.smtpPort)
                    .put("smtpSecurity", a.smtpSecurity.name)
                    .put("appendSent", a.appendSent).put("providerKey", a.providerKey)
                    .put("pw", a.encryptedPassword)
            )
        }
        return arr.toString()
    }

    private fun parse(json: String): List<MailAccount> {
        if (json.isBlank()) return emptyList()
        val arr = JSONArray(json)
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            MailAccount(
                id = o.getString("id"), email = o.getString("email"), displayName = o.optString("displayName"),
                imapHost = o.getString("imapHost"), imapPort = o.getInt("imapPort"),
                smtpHost = o.getString("smtpHost"), smtpPort = o.getInt("smtpPort"),
                smtpSecurity = SmtpSecurity.valueOf(o.getString("smtpSecurity")),
                appendSent = o.optBoolean("appendSent", true), providerKey = o.optString("providerKey", "custom"),
                encryptedPassword = o.getString("pw"),
            )
        }
    }
}
