// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (C) 2026 The PRIVORA MAIL authors. See LICENSE-NOTICE.md.
package app.privora.mail

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import app.privora.mail.core.data.AppSettings
import app.privora.mail.core.data.SettingsRepository
import app.privora.mail.core.design.MotionMode
import app.privora.mail.core.design.ThemeMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AppViewModel(private val repo: SettingsRepository) : ViewModel() {

    private var initialised = false

    // Starts locked; resolved from the saved setting the moment preferences are read (before any UI uses it).
    private val _locked = MutableStateFlow(true)
    val locked: StateFlow<Boolean> = _locked.asStateFlow()

    /** null = still reading preferences from disk (real startup work, no artificial delay). */
    val settings: StateFlow<AppSettings?> = repo.settings
        .onEach { s ->
            if (!initialised) {
                initialised = true
                _locked.value = s.appLock
            }
        }
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    fun unlock() { _locked.value = false }

    /** Called when the app returns to the foreground after `awayMillis` in the background. */
    fun onReturned(awayMillis: Long) {
        val s = settings.value ?: return
        if (s.appLock && awayMillis >= s.lockTimeoutSec * 1000L) _locked.value = true
    }

    fun setTheme(mode: ThemeMode) { viewModelScope.launch { repo.setTheme(mode) } }
    fun setMotion(mode: MotionMode) { viewModelScope.launch { repo.setMotion(mode) } }
    fun completeOnboarding() { viewModelScope.launch { repo.completeOnboarding() } }
    fun setAppLock(on: Boolean) { viewModelScope.launch { repo.setAppLock(on) } }
    fun setLockTimeout(sec: Int) { viewModelScope.launch { repo.setLockTimeout(sec) } }
    fun setBlockScreenshots(on: Boolean) { viewModelScope.launch { repo.setBlockScreenshots(on) } }
    fun setSignature(text: String) { viewModelScope.launch { repo.setSignature(text) } }
    fun setFetchLimit(n: Int) { viewModelScope.launch { repo.setFetchLimit(n) } }
    fun setConfirmDelete(on: Boolean) { viewModelScope.launch { repo.setConfirmDelete(on) } }

    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val app = this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as PrivoraApplication
                AppViewModel(app.settingsRepository)
            }
        }
    }
}
