package app.privora.mail

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import app.privora.mail.core.data.AppSettings
import app.privora.mail.core.data.SettingsRepository
import app.privora.mail.core.design.MotionMode
import app.privora.mail.core.design.ThemeMode
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AppViewModel(private val repo: SettingsRepository) : ViewModel() {

    /** null = still reading preferences from disk (real startup work, no artificial delay). */
    val settings: StateFlow<AppSettings?> =
        repo.settings.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    fun setTheme(mode: ThemeMode) { viewModelScope.launch { repo.setTheme(mode) } }
    fun setMotion(mode: MotionMode) { viewModelScope.launch { repo.setMotion(mode) } }
    fun completeOnboarding() { viewModelScope.launch { repo.completeOnboarding() } }

    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val app = this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as PrivoraApplication
                AppViewModel(app.settingsRepository)
            }
        }
    }
}
