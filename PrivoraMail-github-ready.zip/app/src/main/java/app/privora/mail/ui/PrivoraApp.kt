package app.privora.mail.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.privora.mail.AppViewModel
import app.privora.mail.core.design.MotionMode
import app.privora.mail.core.design.MotionTokens
import app.privora.mail.core.design.Privora
import app.privora.mail.core.design.PrivoraTheme
import app.privora.mail.core.design.ThemeMode
import app.privora.mail.ui.main.MainShell
import app.privora.mail.ui.onboarding.OnboardingScreen
import app.privora.mail.ui.splash.SplashScreen

private enum class Stage { Loading, Onboarding, Main }

@Composable
fun PrivoraApp(viewModel: AppViewModel) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val current = settings

    PrivoraTheme(
        themeMode = current?.themeMode ?: ThemeMode.System,
        motionMode = current?.motionMode ?: MotionMode.Full,
    ) {
        val stage = when {
            current == null -> Stage.Loading
            !current.onboardingDone -> Stage.Onboarding
            else -> Stage.Main
        }
        val motion = Privora.motion // captured here: transitionSpec is not a composable scope
        AnimatedContent(
            targetState = stage,
            transitionSpec = {
                fadeIn(motion.tween(MotionTokens.Screen)) togetherWith fadeOut(motion.tween(MotionTokens.Micro))
            },
            label = "app-stage",
        ) { target ->
            when (target) {
                Stage.Loading -> SplashScreen()
                Stage.Onboarding -> OnboardingScreen(onFinish = viewModel::completeOnboarding)
                Stage.Main -> {
                    if (current != null) MainShell(current, viewModel)
                }
            }
        }
    }
}
