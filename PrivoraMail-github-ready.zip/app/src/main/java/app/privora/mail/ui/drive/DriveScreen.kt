package app.privora.mail.ui.drive

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Cloud
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import app.privora.mail.core.design.PrivoraEmptyState
import app.privora.mail.core.design.Spacing

@Composable
fun DriveScreen() {
    Column(Modifier.fillMaxSize()) {
        Text(
            "PRIVORA Drive",
            style = MaterialTheme.typography.titleLarge,
            modifier = Modifier.padding(Spacing.lg).semantics { heading() },
        )
        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            PrivoraEmptyState(
                icon = Icons.Outlined.Cloud,
                title = "Drive isn't available yet",
                body = "Drive needs a storage service. No storage figures are shown until a real one exists.",
            )
        }
    }
}
