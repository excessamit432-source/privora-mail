// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (C) 2026 The PRIVORA MAIL authors. See LICENSE-NOTICE.md.
package app.privora.mail.core.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import app.privora.mail.core.design.MotionMode
import app.privora.mail.core.design.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.settingsStore by preferencesDataStore(name = "privora_settings")

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.System,
    val motionMode: MotionMode = MotionMode.Full,
    val onboardingDone: Boolean = false,
    val appLock: Boolean = false,
    /** Seconds the app may be in the background before it locks. 0 = lock every time you leave. */
    val lockTimeoutSec: Int = 60,
    val blockScreenshots: Boolean = false,
    val signature: String = "",
    val fetchLimit: Int = 50,
    val confirmDelete: Boolean = true,
)

/** Non-sensitive UI preferences only. Credentials and tokens will NEVER live here (Keystore-backed storage later). */
class SettingsRepository(private val context: Context) {

    private object Keys {
        val theme = stringPreferencesKey("theme_mode")
        val motion = stringPreferencesKey("motion_mode")
        val onboarding = booleanPreferencesKey("onboarding_done")
        val appLock = booleanPreferencesKey("app_lock")
        val lockTimeout = intPreferencesKey("lock_timeout_sec")
        val blockShots = booleanPreferencesKey("block_screenshots")
        val signature = stringPreferencesKey("signature")
        val fetchLimit = intPreferencesKey("fetch_limit")
        val confirmDelete = booleanPreferencesKey("confirm_delete")
    }

    val settings: Flow<AppSettings> = context.settingsStore.data
        .catch { e -> if (e is IOException) emit(emptyPreferences()) else throw e }
        .map { p ->
            AppSettings(
                themeMode = p[Keys.theme].toEnumOrDefault(ThemeMode.System),
                motionMode = p[Keys.motion].toEnumOrDefault(MotionMode.Full),
                onboardingDone = p[Keys.onboarding] ?: false,
                appLock = p[Keys.appLock] ?: false,
                lockTimeoutSec = p[Keys.lockTimeout] ?: 60,
                blockScreenshots = p[Keys.blockShots] ?: false,
                signature = p[Keys.signature] ?: "",
                fetchLimit = p[Keys.fetchLimit] ?: 50,
                confirmDelete = p[Keys.confirmDelete] ?: true,
            )
        }

    suspend fun setTheme(mode: ThemeMode) { context.settingsStore.edit { it[Keys.theme] = mode.name } }
    suspend fun setMotion(mode: MotionMode) { context.settingsStore.edit { it[Keys.motion] = mode.name } }
    suspend fun completeOnboarding() { context.settingsStore.edit { it[Keys.onboarding] = true } }
    suspend fun setAppLock(on: Boolean) { context.settingsStore.edit { it[Keys.appLock] = on } }
    suspend fun setLockTimeout(sec: Int) { context.settingsStore.edit { it[Keys.lockTimeout] = sec } }
    suspend fun setBlockScreenshots(on: Boolean) { context.settingsStore.edit { it[Keys.blockShots] = on } }
    suspend fun setSignature(text: String) { context.settingsStore.edit { it[Keys.signature] = text } }
    suspend fun setFetchLimit(n: Int) { context.settingsStore.edit { it[Keys.fetchLimit] = n } }
    suspend fun setConfirmDelete(on: Boolean) { context.settingsStore.edit { it[Keys.confirmDelete] = on } }
}

private inline fun <reified E : Enum<E>> String?.toEnumOrDefault(default: E): E =
    this?.let { name -> enumValues<E>().firstOrNull { it.name == name } } ?: default
