package app.privora.mail.core.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import app.privora.mail.core.design.MotionMode
import app.privora.mail.core.design.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.settingsStore by preferencesDataStore(name = "privora_settings")

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.System,
    val motionMode: MotionMode = MotionMode.Full,
    val onboardingDone: Boolean = false,
)

/** Non-sensitive UI preferences only. Credentials and tokens will NEVER live here (Keystore-backed storage later). */
class SettingsRepository(private val context: Context) {

    private object Keys {
        val theme = stringPreferencesKey("theme_mode")
        val motion = stringPreferencesKey("motion_mode")
        val onboarding = booleanPreferencesKey("onboarding_done")
    }

    val settings: Flow<AppSettings> = context.settingsStore.data
        .catch { e -> if (e is IOException) emit(emptyPreferences()) else throw e }
        .map { p ->
            AppSettings(
                themeMode = p[Keys.theme].toEnumOrDefault(ThemeMode.System),
                motionMode = p[Keys.motion].toEnumOrDefault(MotionMode.Full),
                onboardingDone = p[Keys.onboarding] ?: false,
            )
        }

    suspend fun setTheme(mode: ThemeMode) { context.settingsStore.edit { it[Keys.theme] = mode.name } }
    suspend fun setMotion(mode: MotionMode) { context.settingsStore.edit { it[Keys.motion] = mode.name } }
    suspend fun completeOnboarding() { context.settingsStore.edit { it[Keys.onboarding] = true } }
}

private inline fun <reified E : Enum<E>> String?.toEnumOrDefault(default: E): E =
    this?.let { name -> enumValues<E>().firstOrNull { it.name == name } } ?: default
