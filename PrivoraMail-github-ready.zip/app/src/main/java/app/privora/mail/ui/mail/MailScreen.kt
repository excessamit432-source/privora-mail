package app.privora.mail.ui.mail

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.outlined.Mail
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import app.privora.mail.core.design.PrivoraEmptyState
import app.privora.mail.core.design.Spacing
import app.privora.mail.ui.main.MailFolder

@Composable
fun MailScreen(folder: MailFolder, onOpenDrawer: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = Spacing.sm, vertical = Spacing.xs),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onOpenDrawer) {
                Icon(Icons.Filled.Menu, contentDescription = "Open navigation menu")
            }
            Text(
                folder.label,
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.padding(start = Spacing.xs).semantics { heading() },
            )
        }
        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            // Honest state: there is no account, so there is no mail, and nothing has synced.
            PrivoraEmptyState(
                icon = Icons.Outlined.Mail,
                title = "No mail account connected",
                body = "Account setup is the next development step. Nothing is synced yet and no data leaves your device.",
            )
        }
    }
}
