// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (C) 2026 The PRIVORA MAIL authors. See LICENSE-NOTICE.md.
package app.privora.mail.ui.mail

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.AttachFile
import androidx.compose.material.icons.outlined.Mail
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.privora.mail.core.design.Brand
import app.privora.mail.core.design.Privora
import app.privora.mail.core.design.PrivoraAvatar
import app.privora.mail.core.design.PrivoraEmptyState
import app.privora.mail.core.design.PrivoraGradientButton
import app.privora.mail.core.design.Spacing
import app.privora.mail.core.design.privoraFieldColors
import app.privora.mail.core.mail.MailHeader
import kotlinx.coroutines.delay
import java.time.Instant
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

enum class MailFilter { All, Unread, Starred }

fun formatMailDate(millis: Long): String {
    if (millis <= 0L) return ""
    val zone = ZoneId.systemDefault()
    val dt = Instant.ofEpochMilli(millis).atZone(zone)
    val now = ZonedDateTime.now(zone)
    val pattern = when {
        dt.toLocalDate() == now.toLocalDate() -> "h:mm a"
        dt.year == now.year -> "d MMM"
        else -> "d MMM yyyy"
    }
    return DateTimeFormatter.ofPattern(pattern).format(dt)
}

private fun greeting(): String {
    val h = LocalTime.now().hour
    return when {
        h < 12 -> "Good morning"
        h < 17 -> "Good afternoon"
        else -> "Good evening"
    }
}

@Composable
fun MailScreen(
    state: MailUiState,
    onOpenDrawer: () -> Unit,
    onRefresh: () -> Unit,
    onQuery: (String) -> Unit,
    onOpen: (MailHeader) -> Unit,
    onToggleStar: (MailHeader) -> Unit,
    onCompose: () -> Unit,
    onAddAccount: () -> Unit,
    onUnlockRequest: () -> Unit,
) {
    var filter by rememberSaveable { mutableStateOf(MailFilter.All) }
    var text by rememberSaveable { mutableStateOf("") }
    val focus = LocalFocusManager.current

    // Debounced real server-side search: fires 600 ms after typing stops (or immediately on the keyboard's Search key).
    LaunchedEffect(text) {
        if (text != state.query) {
            delay(600)
            onQuery(text)
        }
    }
    // The ViewModel clears the query on account/folder change; keep the box in sync.
    LaunchedEffect(state.query) {
        if (state.query.isEmpty() && text.isNotEmpty()) text = ""
    }

    val visible = when (filter) {
        MailFilter.All -> state.headers
        MailFilter.Unread -> state.headers.filter { it.unread }
        MailFilter.Starred -> state.headers.filter { it.starred }
    }
    val unreadCount = state.headers.count { it.unread }
    val starredCount = state.headers.count { it.starred }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            // Header: avatar (opens menu/accounts) + greeting + refresh
            Row(
                Modifier.fillMaxWidth().padding(horizontal = Spacing.lg, vertical = Spacing.sm),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Surface(onClick = onOpenDrawer, shape = CircleShape, color = Color.Transparent,
                    modifier = Modifier.size(Spacing.minTouch).semantics { contentDescription = "Open menu and accounts" }) {
                    Box(contentAlignment = Alignment.Center) {
                        PrivoraAvatar(state.active?.shortName ?: "P", size = 44.dp)
                    }
                }
                Spacer(Modifier.width(Spacing.md))
                Column(Modifier.weight(1f).semantics(mergeDescendants = true) { heading() }) {
                    Text(
                        if (state.active != null) greeting() + "," else "Welcome to",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Text(
                        state.active?.shortName ?: "PRIVORA MAIL",
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                    )
                }
                if (state.active != null) {
                    IconButton(onClick = onRefresh) { Icon(Icons.Filled.Refresh, contentDescription = "Refresh") }
                }
            }

            if (state.active != null) {
                // Search
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = Spacing.lg),
                    placeholder = { Text("Search ${state.folder.label.lowercase()} (subject, sender)…") },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                    trailingIcon = {
                        if (text.isNotEmpty()) {
                            IconButton(onClick = { text = ""; onQuery("") }) {
                                Icon(Icons.Filled.Clear, contentDescription = "Clear search")
                            }
                        }
                    },
                    singleLine = true,
                    shape = CircleShape,
                    colors = privoraFieldColors(),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { onQuery(text); focus.clearFocus() }),
                )
                Spacer(Modifier.height(Spacing.sm))
                // Filter chips
                Row(
                    Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = Spacing.lg),
                    horizontalArrangement = Arrangement.spacedBy(Spacing.sm),
                ) {
                    val chipColors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primary,
                        selectedLabelColor = MaterialTheme.colorScheme.onPrimary,
                    )
                    FilterChip(filter == MailFilter.All, { filter = MailFilter.All }, { Text("All ${state.headers.size}") }, colors = chipColors)
                    FilterChip(filter == MailFilter.Unread, { filter = MailFilter.Unread }, { Text("Unread $unreadCount") }, colors = chipColors)
                    FilterChip(filter == MailFilter.Starred, { filter = MailFilter.Starred }, { Text("Starred $starredCount") }, colors = chipColors)
                }
                Text(
                    state.folder.label,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = Spacing.lg, vertical = Spacing.sm),
                )
                if (state.encryptionLocked) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = Spacing.lg),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            "Encryption is locked. Encrypted mail can't be read yet.",
                            style = MaterialTheme.typography.bodySmall, color = Privora.extras.warning, modifier = Modifier.weight(1f),
                        )
                        TextButton(onClick = onUnlockRequest) { Text("Unlock") }
                    }
                }
                if (state.loading && state.headers.isNotEmpty()) {
                    LinearProgressIndicator(Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.secondary)
                }
            }

            Box(Modifier.weight(1f).fillMaxWidth()) {
                when {
                    state.active == null -> Column(
                        Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                    ) {
                        PrivoraEmptyState(
                            icon = Icons.Outlined.Mail,
                            title = "Sign in to PRIVORA",
                            body = "Sign in with your PRIVORA address to read and send end-to-end encrypted email.",
                        )
                        PrivoraGradientButton("Sign in", onAddAccount)
                    }

                    state.error != null && state.headers.isEmpty() -> Column(
                        Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                    ) {
                        PrivoraEmptyState(Icons.Outlined.Mail, "Couldn't load mail", state.error)
                        PrivoraGradientButton("Try again", onRefresh)
                    }

                    state.loading && state.headers.isEmpty() ->
                        CircularProgressIndicator(Modifier.align(Alignment.Center), color = MaterialTheme.colorScheme.secondary)

                    visible.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        PrivoraEmptyState(
                            Icons.Outlined.Mail,
                            if (state.query.isNotEmpty()) "No results" else "Nothing here",
                            if (state.query.isNotEmpty()) "No messages match \"${state.query}\"." else "This view has no messages.",
                        )
                    }

                    else -> LazyColumn(contentPadding = PaddingValues(bottom = 96.dp)) {
                        if (state.error != null) {
                            item {
                                Text(
                                    state.error,
                                    color = MaterialTheme.colorScheme.error,
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.padding(horizontal = Spacing.lg, vertical = Spacing.sm),
                                )
                            }
                        }
                        items(visible, key = { "${it.folder}:${it.uid}" }) { h ->
                            MailRow(h, onOpen = { onOpen(h) }, onToggleStar = { onToggleStar(h) })
                            HorizontalDivider(color = Privora.extras.border, modifier = Modifier.padding(start = 76.dp))
                        }
                    }
                }
            }
        }

        if (state.active != null) {
            ComposeFab(onCompose, Modifier.align(Alignment.BottomEnd).padding(Spacing.lg))
        }
    }
}

@Composable
private fun ComposeFab(onClick: () -> Unit, modifier: Modifier) {
    Surface(
        onClick = onClick,
        modifier = modifier.size(60.dp),
        shape = CircleShape,
        color = Color.Transparent,
        shadowElevation = 6.dp,
    ) {
        Box(Modifier.drawBehind { drawRect(brush = Brush.horizontalGradient(listOf(Brand.Purple, Brand.ElectricBlue))) }, contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.Edit, contentDescription = "Compose new message", tint = Color.White)
        }
    }
}

@Composable
private fun MailRow(h: MailHeader, onOpen: () -> Unit, onToggleStar: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClickLabel = "Open message", onClick = onOpen)
            .padding(start = Spacing.lg, top = Spacing.md, bottom = Spacing.md, end = Spacing.xs),
        verticalAlignment = Alignment.Top,
    ) {
        PrivoraAvatar(h.fromName, 44.dp)
        Spacer(Modifier.width(Spacing.md))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    h.fromName,
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = if (h.unread) FontWeight.Bold else FontWeight.Normal),
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
                if (h.unread) {
                    Box(Modifier.padding(end = Spacing.xs).size(8.dp).clip(CircleShape).background(MaterialTheme.colorScheme.secondary))
                }
                Text(
                    formatMailDate(h.dateMillis),
                    style = MaterialTheme.typography.bodySmall,
                    color = if (h.unread) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Text(
                h.subject,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = if (h.unread) FontWeight.SemiBold else FontWeight.Normal),
                color = if (h.unread) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2, overflow = TextOverflow.Ellipsis,
            )
            if (h.hasAttachment) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = Spacing.xs)) {
                    Icon(Icons.Outlined.AttachFile, contentDescription = "Has attachment", modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        IconButton(onClick = onToggleStar) {
            Icon(
                if (h.starred) Icons.Filled.Star else Icons.Outlined.StarBorder,
                contentDescription = if (h.starred) "Remove star" else "Star",
                tint = if (h.starred) Privora.extras.warning else MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
