package app.privora.mail.core.mail

enum class SmtpSecurity { SSL, STARTTLS }

data class MailAccount(
    val id: String,
    val email: String,
    val displayName: String,
    val imapHost: String,
    val imapPort: Int,
    val smtpHost: String,
    val smtpPort: Int,
    val smtpSecurity: SmtpSecurity,
    /** Save a copy to the Sent folder ourselves (Gmail already does this server-side). */
    val appendSent: Boolean,
    val providerKey: String,
    /** Keystore-encrypted. Never log or display. */
    val encryptedPassword: String,
) {
    val shortName: String get() = displayName.ifBlank { email.substringBefore('@') }
}

data class ProviderPreset(
    val key: String,
    val name: String,
    val domains: List<String>,
    val imapHost: String,
    val imapPort: Int,
    val smtpHost: String,
    val smtpPort: Int,
    val smtpSecurity: SmtpSecurity,
    val appendSent: Boolean,
    val appPasswordUrl: String?,
    val securityUrl: String?,
    val passwordNote: String?,
)

object Providers {
    val gmail = ProviderPreset(
        key = "gmail", name = "Gmail", domains = listOf("gmail.com", "googlemail.com"),
        imapHost = "imap.gmail.com", imapPort = 993, smtpHost = "smtp.gmail.com", smtpPort = 465,
        smtpSecurity = SmtpSecurity.SSL, appendSent = false,
        appPasswordUrl = "https://myaccount.google.com/apppasswords",
        securityUrl = "https://myaccount.google.com/security",
        passwordNote = "Gmail needs an app password (2-step verification must be on in your Google account). Your normal password will not work.",
    )
    val yahoo = ProviderPreset(
        key = "yahoo", name = "Yahoo Mail",
        domains = listOf("yahoo.com", "yahoo.in", "yahoo.co.in", "ymail.com", "rocketmail.com"),
        imapHost = "imap.mail.yahoo.com", imapPort = 993, smtpHost = "smtp.mail.yahoo.com", smtpPort = 465,
        smtpSecurity = SmtpSecurity.SSL, appendSent = true,
        appPasswordUrl = "https://login.yahoo.com/account/security",
        securityUrl = "https://login.yahoo.com/account/security",
        passwordNote = "Yahoo needs an app password generated in your Yahoo account security settings.",
    )
    val icloud = ProviderPreset(
        key = "icloud", name = "iCloud Mail", domains = listOf("icloud.com", "me.com", "mac.com"),
        imapHost = "imap.mail.me.com", imapPort = 993, smtpHost = "smtp.mail.me.com", smtpPort = 587,
        smtpSecurity = SmtpSecurity.STARTTLS, appendSent = true,
        appPasswordUrl = "https://appleid.apple.com/",
        securityUrl = "https://appleid.apple.com/",
        passwordNote = "iCloud needs an app-specific password from your Apple Account page.",
    )

    val all = listOf(gmail, yahoo, icloud)

    fun forEmail(email: String): ProviderPreset? {
        val domain = email.substringAfter('@', "").trim().lowercase()
        return all.firstOrNull { domain in it.domains }
    }

    /** Providers that cannot work with a plain IMAP password. Be honest instead of failing mysteriously. */
    fun unsupportedNote(email: String): String? {
        val domain = email.substringAfter('@', "").trim().lowercase()
        return when {
            domain in listOf("outlook.com", "hotmail.com", "live.com", "msn.com", "outlook.in", "hotmail.co.uk") ->
                "Outlook and Hotmail accounts need OAuth sign-in, which this version does not support yet."
            domain in listOf("proton.me", "protonmail.com", "pm.me") ->
                "Proton Mail only allows IMAP through Proton Mail Bridge, which is not available on Android."
            else -> null
        }
    }
}

data class MailHeader(
    val uid: Long,
    val folder: String,
    val fromName: String,
    val fromAddress: String,
    val subject: String,
    val dateMillis: Long,
    val unread: Boolean,
    val starred: Boolean,
    val hasAttachment: Boolean,
)

data class AttachmentInfo(val name: String, val sizeBytes: Long)

data class MailBody(
    val header: MailHeader,
    val to: List<String>,
    val cc: List<String>,
    val text: String,
    val attachments: List<AttachmentInfo>,
    val messageId: String?,
)

data class OutgoingMail(
    val to: String,
    val cc: String,
    val bcc: String,
    val subject: String,
    val body: String,
    val inReplyTo: String?,
)

data class FolderMap(
    val inbox: String,
    val sent: String?,
    val drafts: String?,
    val spam: String?,
    val trash: String?,
    val all: String?,
)

class MailException(val kind: Kind, message: String) : Exception(message) {
    enum class Kind { Auth, Network, Server, Other }
}
