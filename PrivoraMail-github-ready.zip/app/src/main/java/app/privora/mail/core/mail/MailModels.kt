// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (C) 2026 The PRIVORA MAIL authors. See LICENSE-NOTICE.md.
package app.privora.mail.core.mail

enum class SmtpSecurity { SSL, STARTTLS }

data class MailAccount(
    val id: String,
    val email: String,
    val displayName: String,
    val imapHost: String,
    val imapPort: Int,
    val smtpHost: String,
    val smtpPort: Int,
    val smtpSecurity: SmtpSecurity,
    /** Save a copy to the Sent folder ourselves (Gmail already does this server-side). */
    val appendSent: Boolean,
    val providerKey: String,
    /** Keystore-encrypted. Never log or display. */
    val encryptedPassword: String,
) {
    val shortName: String get() = displayName.ifBlank { email.substringBefore('@') }
}

data class MailHeader(
    val uid: Long,
    val folder: String,
    val fromName: String,
    val fromAddress: String,
    val subject: String,
    val dateMillis: Long,
    val unread: Boolean,
    val starred: Boolean,
    val hasAttachment: Boolean,
)

data class AttachmentInfo(val name: String, val sizeBytes: Long)

/** How a message was protected. Only ever set from what was ACTUALLY verified, never assumed. */
enum class MessageSecurity {
    /** Plain email: protected by TLS in transit only. */
    Plain,
    /** Decrypted end-to-end, and the sender's signature checked out. */
    EncryptedVerified,
    /** Decrypted end-to-end, but the sender could not be verified (no key found, or unsigned). */
    EncryptedUnverified,
    /** Decrypted, but the signature did NOT match. Treat as suspicious. */
    EncryptedBadSignature,
    /** Encrypted, and encryption is locked: the passphrase is needed. */
    EncryptedLocked,
    /** Encrypted but could not be decrypted. */
    EncryptedFailed,
}

data class MailBody(
    val header: MailHeader,
    val to: List<String>,
    val cc: List<String>,
    val text: String,
    val attachments: List<AttachmentInfo>,
    val messageId: String?,
    val security: MessageSecurity = MessageSecurity.Plain,
    val securityNote: String? = null,
)

data class OutgoingMail(
    val to: String,
    val cc: String,
    val bcc: String,
    val subject: String,
    val body: String,
    val inReplyTo: String?,
)

data class FolderMap(
    val inbox: String,
    val sent: String?,
    val drafts: String?,
    val spam: String?,
    val trash: String?,
    val all: String?,
)

class MailException(val kind: Kind, message: String) : Exception(message) {
    enum class Kind { Auth, Network, Server, Other }
}
