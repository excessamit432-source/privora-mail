// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (C) 2026 The PRIVORA MAIL authors. See LICENSE-NOTICE.md.
package app.privora.mail.ui.onboarding

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Cloud
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Mail
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import app.privora.mail.core.design.MotionMode
import app.privora.mail.core.design.MotionTokens
import app.privora.mail.core.design.Privora
import app.privora.mail.core.design.PrivoraBackdrop
import app.privora.mail.core.design.PrivoraGradientButton
import app.privora.mail.core.design.Spacing
import kotlinx.coroutines.launch

private data class OnboardingPage(val icon: ImageVector, val title: String, val body: String)

// TODO(copy): re-review every line against shipped features before release. Copy must never outrun the product.
private val pages = listOf(
    OnboardingPage(Icons.Outlined.Shield, "Privacy by design",
        "PRIVORA MAIL contains no advertising, analytics or tracking SDKs. Your mail stays yours."),
    OnboardingPage(Icons.Outlined.Lock, "Security you can verify",
        "The Privacy Center lists only protections that are genuinely active, never decorative badges."),
    OnboardingPage(Icons.Outlined.Mail, "Email, organised",
        "A calm, focused inbox with search, folders and drafts, arriving as mail sync is completed."),
    OnboardingPage(Icons.Outlined.Cloud, "Secure storage",
        "PRIVORA Drive for attachments and files is planned for a later release."),
    OnboardingPage(Icons.Outlined.Tune, "You stay in control",
        "Choose your theme and motion level. Nothing about how the app behaves is hidden from you."),
)

@Composable
fun OnboardingScreen(onFinish: () -> Unit) {
    val pagerState = rememberPagerState(pageCount = { pages.size })
    val scope = rememberCoroutineScope()
    val motion = Privora.motion
    val isLast = pagerState.currentPage == pages.lastIndex

    PrivoraBackdrop {
        Column(Modifier.fillMaxSize().safeDrawingPadding().padding(horizontal = Spacing.xxl)) {
            Box(Modifier.fillMaxWidth().height(Spacing.huge), contentAlignment = Alignment.CenterEnd) {
                if (!isLast) TextButton(onClick = onFinish) { Text("Skip") }
            }

            HorizontalPager(state = pagerState, modifier = Modifier.weight(1f)) { index ->
                val page = pages[index]
                Column(
                    modifier = Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    Box(
                        Modifier.size(140.dp).clip(CircleShape).background(Privora.extras.glow),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(page.icon, contentDescription = null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(64.dp))
                    }
                    Spacer(Modifier.height(Spacing.xxxl))
                    Text(page.title, style = MaterialTheme.typography.headlineMedium, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(Spacing.md))
                    Text(
                        page.body,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center,
                    )
                }
            }

            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(vertical = Spacing.lg)
                    .clearAndSetSemantics { contentDescription = "Page ${pagerState.currentPage + 1} of ${pages.size}" },
                horizontalArrangement = Arrangement.Center,
            ) {
                repeat(pages.size) { i ->
                    val selected = pagerState.currentPage == i
                    val width = animateDpAsState(if (selected) 24.dp else 8.dp, motion.tween(MotionTokens.Micro), label = "dot").value
                    Box(
                        Modifier
                            .padding(horizontal = Spacing.xs)
                            .height(8.dp)
                            .width(width)
                            .clip(CircleShape)
                            .background(
                                if (selected) MaterialTheme.colorScheme.secondary
                                else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
                            )
                    )
                }
            }

            PrivoraGradientButton(
                text = if (isLast) "Get Started" else "Next",
                onClick = {
                    if (isLast) onFinish() else scope.launch {
                        val target = pagerState.currentPage + 1
                        if (motion.mode == MotionMode.Minimal) pagerState.scrollToPage(target)
                        else pagerState.animateScrollToPage(target)
                    }
                },
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(Spacing.lg))
        }
    }
}
