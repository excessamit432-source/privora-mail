package app.privora.mail.ui.mail

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import app.privora.mail.core.design.Privora
import app.privora.mail.core.design.PrivoraAvatar
import app.privora.mail.core.design.PrivoraCard
import app.privora.mail.core.design.Spacing

@Composable
fun MessageScreen(
    detail: DetailState,
    confirmDelete: Boolean,
    onBack: () -> Unit,
    onToggleStar: () -> Unit,
    onDelete: () -> Unit,
    onMarkUnread: () -> Unit,
    onReply: (all: Boolean) -> Unit,
    onForward: () -> Unit,
) {
    BackHandler(onBack = onBack)
    var menu by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf(false) }
    val h = detail.header
    val body = detail.body

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = Spacing.xs), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
            Spacer(Modifier.weight(1f))
            IconButton(onClick = onToggleStar) {
                Icon(
                    if (h.starred) Icons.Filled.Star else Icons.Outlined.StarBorder,
                    contentDescription = if (h.starred) "Remove star" else "Star",
                    tint = if (h.starred) Privora.extras.warning else MaterialTheme.colorScheme.onSurface,
                )
            }
            IconButton(onClick = { if (confirmDelete) confirm = true else onDelete() }) {
                Icon(Icons.Outlined.Delete, contentDescription = "Delete")
            }
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, contentDescription = "More actions") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Mark as unread") }, onClick = { menu = false; onMarkUnread() })
                }
            }
        }

        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = Spacing.lg)) {
            Text(h.subject, style = MaterialTheme.typography.headlineSmall, modifier = Modifier.semantics { heading() })
            Spacer(Modifier.height(Spacing.lg))
            Row(verticalAlignment = Alignment.CenterVertically) {
                PrivoraAvatar(h.fromName, 48.dp)
                Spacer(Modifier.width(Spacing.md))
                Column(Modifier.weight(1f)) {
                    Text(h.fromName, style = MaterialTheme.typography.titleMedium)
                    Text(h.fromAddress, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Text(formatMailDate(h.dateMillis), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (body != null && body.to.isNotEmpty()) {
                Spacer(Modifier.height(Spacing.sm))
                Text("To: " + body.to.joinToString(", "), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (body != null && body.cc.isNotEmpty()) {
                Text("Cc: " + body.cc.joinToString(", "), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.height(Spacing.lg))
            HorizontalDivider(color = Privora.extras.border)
            Spacer(Modifier.height(Spacing.lg))

            when {
                detail.loading -> Box(Modifier.fillMaxWidth().padding(Spacing.xxxl), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = MaterialTheme.colorScheme.secondary)
                }
                detail.error != null -> Text(detail.error, color = MaterialTheme.colorScheme.error)
                body != null -> {
                    SelectionContainer {
                        Text(body.text.ifBlank { "(This message has no text content.)" }, style = MaterialTheme.typography.bodyLarge)
                    }
                    if (body.attachments.isNotEmpty()) {
                        Spacer(Modifier.height(Spacing.xl))
                        Text("Attachments", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(Spacing.sm))
                        body.attachments.forEach { a ->
                            PrivoraCard(Modifier.fillMaxWidth().padding(bottom = Spacing.sm)) {
                                Column {
                                    Text(a.name, style = MaterialTheme.typography.titleSmall)
                                    Text(formatSize(a.sizeBytes), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                        Text(
                            "Downloading attachments isn't supported in this version yet.",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Spacer(Modifier.height(Spacing.xl))
                    Row(verticalAlignment = Alignment.Top) {
                        Icon(Icons.Outlined.Info, contentDescription = null, modifier = Modifier.size(16.dp), tint = Privora.extras.info)
                        Spacer(Modifier.width(Spacing.sm))
                        Text(
                            "Shown as plain text. Remote images and tracking pixels are never loaded.",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Spacer(Modifier.height(Spacing.lg))
                }
            }
        }

        if (body != null) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = Spacing.lg, vertical = Spacing.md),
                horizontalArrangement = Arrangement.spacedBy(Spacing.sm),
            ) {
                OutlinedButton(onClick = { onReply(false) }, modifier = Modifier.weight(1f)) { Text("Reply") }
                OutlinedButton(onClick = { onReply(true) }, modifier = Modifier.weight(1f)) { Text("Reply all") }
                OutlinedButton(onClick = onForward, modifier = Modifier.weight(1f)) { Text("Forward") }
            }
        }
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Delete this message?") },
            text = { Text("It will be moved to Trash. If it is already in Trash it will be deleted permanently.") },
            confirmButton = { TextButton(onClick = { confirm = false; onDelete() }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } },
        )
    }
}

private fun formatSize(bytes: Long): String = when {
    bytes < 1024 -> "$bytes B"
    bytes < 1024 * 1024 -> "${bytes / 1024} KB"
    else -> String.format("%.1f MB", bytes / 1024.0 / 1024.0)
}
