package app.privora.mail.ui.mail

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import app.privora.mail.core.design.Privora
import app.privora.mail.core.design.Spacing
import app.privora.mail.core.design.privoraFieldColors
import app.privora.mail.core.mail.MailAccount
import app.privora.mail.core.mail.MailBody
import app.privora.mail.core.mail.OutgoingMail

data class ComposeDraft(
    val to: String = "",
    val cc: String = "",
    val bcc: String = "",
    val subject: String = "",
    val body: String = "",
    val inReplyTo: String? = null,
)

object Drafts {
    private fun sig(signature: String) = if (signature.isBlank()) "" else "\n\n-- \n${signature.trim()}"

    fun new(signature: String) = ComposeDraft(body = sig(signature))

    fun reply(m: MailBody, all: Boolean, myEmail: String, signature: String): ComposeDraft {
        val h = m.header
        val others = if (all) (m.to + m.cc).filterNot { it.contains(myEmail, ignoreCase = true) } else emptyList()
        val subject = if (h.subject.startsWith("Re:", ignoreCase = true)) h.subject else "Re: ${h.subject}"
        return ComposeDraft(
            to = h.fromAddress,
            cc = others.joinToString(", "),
            subject = subject,
            body = sig(signature) + "\n\n" + quote(m),
            inReplyTo = m.messageId,
        )
    }

    fun forward(m: MailBody, signature: String): ComposeDraft {
        val h = m.header
        val subject = if (h.subject.startsWith("Fwd:", ignoreCase = true)) h.subject else "Fwd: ${h.subject}"
        val head = "---------- Forwarded message ----------\nFrom: ${h.fromName} <${h.fromAddress}>\nDate: ${formatMailDate(h.dateMillis)}\nSubject: ${h.subject}\n\n"
        return ComposeDraft(subject = subject, body = sig(signature) + "\n\n" + head + m.text)
    }

    private fun quote(m: MailBody): String {
        val h = m.header
        val lines = m.text.take(4000).lines().joinToString("\n") { "> $it" }
        return "On ${formatMailDate(h.dateMillis)}, ${h.fromName} <${h.fromAddress}> wrote:\n$lines"
    }
}

@Composable
fun ComposeScreen(
    account: MailAccount,
    initial: ComposeDraft,
    sending: Boolean,
    error: String?,
    onSend: (OutgoingMail) -> Unit,
    onClose: () -> Unit,
    onDismissError: () -> Unit,
) {
    var to by rememberSaveable { mutableStateOf(initial.to) }
    var cc by rememberSaveable { mutableStateOf(initial.cc) }
    var bcc by rememberSaveable { mutableStateOf(initial.bcc) }
    var subject by rememberSaveable { mutableStateOf(initial.subject) }
    var body by rememberSaveable { mutableStateOf(initial.body) }
    var showCc by rememberSaveable { mutableStateOf(initial.cc.isNotBlank() || initial.bcc.isNotBlank()) }
    var confirmDiscard by remember { mutableStateOf(false) }

    val dirty = to.isNotBlank() || cc.isNotBlank() || bcc.isNotBlank() || subject.isNotBlank() || body.trim() != initial.body.trim()
    val canSend = to.isNotBlank() && !sending

    fun tryClose() {
        if (sending) return
        if (dirty) confirmDiscard = true else onClose()
    }
    BackHandler { tryClose() }

    Column(Modifier.fillMaxSize().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = Spacing.xs, vertical = Spacing.xs), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { tryClose() }) { Icon(Icons.Filled.Close, contentDescription = "Close and discard") }
            Text("New message", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f).semantics { heading() })
            Surface(
                onClick = {
                    onDismissError()
                    onSend(OutgoingMail(to, cc, bcc, subject, body, initial.inReplyTo))
                },
                enabled = canSend,
                shape = CircleShape,
                color = Color.Transparent,
                modifier = Modifier.size(48.dp).alpha(if (canSend || sending) 1f else 0.38f),
            ) {
                Box(Modifier.background(Privora.extras.accentBrush), contentAlignment = Alignment.Center) {
                    if (sending) {
                        CircularProgressIndicator(Modifier.size(22.dp), color = Color.White, strokeWidth = 2.dp)
                    } else {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = Color.White)
                    }
                }
            }
            Spacer(Modifier.size(Spacing.sm))
        }

        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = Spacing.lg)) {
            Text("From: ${account.email}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(Spacing.sm))
            Field("To", to, { to = it }, KeyboardType.Email, ImeAction.Next)
            if (!showCc) {
                TextButton(onClick = { showCc = true }) { Text("Add Cc / Bcc") }
            } else {
                Spacer(Modifier.height(Spacing.sm))
                Field("Cc", cc, { cc = it }, KeyboardType.Email, ImeAction.Next)
                Spacer(Modifier.height(Spacing.sm))
                Field("Bcc", bcc, { bcc = it }, KeyboardType.Email, ImeAction.Next)
            }
            Spacer(Modifier.height(Spacing.sm))
            Field("Subject", subject, { subject = it }, KeyboardType.Text, ImeAction.Next)
            Spacer(Modifier.height(Spacing.sm))
            OutlinedTextField(
                value = body,
                onValueChange = { body = it },
                modifier = Modifier.fillMaxWidth().heightIn(min = 240.dp),
                label = { Text("Message") },
                colors = privoraFieldColors(),
                shape = MaterialTheme.shapes.medium,
            )
            Text(
                "Separate several recipients with commas. Plain-text only for now; attachments and formatting are not supported yet.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = Spacing.sm),
            )
            if (error != null) {
                Spacer(Modifier.height(Spacing.md))
                Text("Not sent: $error", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
                Text("Your message is still here. Fix the problem and tap Send to retry.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.height(Spacing.xxxl))
        }
    }

    if (confirmDiscard) {
        AlertDialog(
            onDismissRequest = { confirmDiscard = false },
            title = { Text("Discard this message?") },
            text = { Text("Drafts aren't saved yet, so your text will be lost.") },
            confirmButton = { TextButton(onClick = { confirmDiscard = false; onClose() }) { Text("Discard") } },
            dismissButton = { TextButton(onClick = { confirmDiscard = false }) { Text("Keep editing") } },
        )
    }
}

@Composable
private fun Field(label: String, value: String, onChange: (String) -> Unit, type: KeyboardType, ime: ImeAction) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        modifier = Modifier.fillMaxWidth(),
        label = { Text(label) },
        singleLine = true,
        colors = privoraFieldColors(),
        shape = MaterialTheme.shapes.medium,
        keyboardOptions = KeyboardOptions(keyboardType = type, imeAction = ime),
    )
}
