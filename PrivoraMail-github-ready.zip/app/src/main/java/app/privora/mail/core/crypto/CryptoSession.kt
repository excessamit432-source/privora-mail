// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (C) 2026 The PRIVORA MAIL authors. See LICENSE-NOTICE.md.
package app.privora.mail.core.crypto

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/** Unlocked private keys live ONLY here, in memory. Killing the app (or tapping "Lock") discards them. */
class CryptoSession {
    private val _keys = MutableStateFlow<Map<String, UnlockedKey>>(emptyMap())
    val keys: StateFlow<Map<String, UnlockedKey>> = _keys.asStateFlow()

    fun get(email: String): UnlockedKey? = _keys.value[email.lowercase()]
    fun put(key: UnlockedKey) { _keys.update { it + (key.email.lowercase() to key) } }
    fun lock(email: String) { _keys.update { it - email.lowercase() } }
    fun lockAll() { _keys.value = emptyMap() }
}
