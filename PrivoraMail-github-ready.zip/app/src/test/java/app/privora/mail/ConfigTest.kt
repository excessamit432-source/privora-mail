// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (C) 2026 The PRIVORA MAIL authors. See LICENSE-NOTICE.md.
package app.privora.mail

import app.privora.mail.core.PrivoraConfig
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ConfigTest {
    @Test fun addsTheDomainToABareUsername() {
        assertEquals("alice@${PrivoraConfig.DOMAIN}", PrivoraConfig.normalizeAddress("  Alice "))
    }

    @Test fun acceptsAFullAddressOnTheSameDomain() {
        assertEquals("bob@${PrivoraConfig.DOMAIN}", PrivoraConfig.normalizeAddress("BOB@${PrivoraConfig.DOMAIN}"))
    }

    @Test fun rejectsOtherDomainsAndEmptyInput() {
        assertNull(PrivoraConfig.normalizeAddress("someone@gmail.com"))
        assertNull(PrivoraConfig.normalizeAddress("   "))
        assertNull(PrivoraConfig.normalizeAddress("@${PrivoraConfig.DOMAIN}"))
    }

    @Test fun derivesHostsFromTheSingleDomain() {
        assertEquals("mail.${PrivoraConfig.DOMAIN}", PrivoraConfig.IMAP_HOST)
        assertEquals("https://keys.${PrivoraConfig.DOMAIN}", PrivoraConfig.KEYS_URL)
        assertTrue(PrivoraConfig.isPrivoraAddress("x@${PrivoraConfig.DOMAIN}"))
        assertFalse(PrivoraConfig.isPrivoraAddress("x@other.org"))
    }
}
