package app.privora.mail

import app.privora.mail.core.mail.Providers
import app.privora.mail.core.mail.SmtpSecurity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class ProvidersTest {
    @Test fun detectsGmailCaseInsensitively() {
        assertEquals("gmail", Providers.forEmail("Someone@GMAIL.com")?.key)
        assertEquals(SmtpSecurity.SSL, Providers.gmail.smtpSecurity)
    }

    @Test fun detectsYahooAndIcloud() {
        assertEquals("yahoo", Providers.forEmail("a@yahoo.co.in")?.key)
        assertEquals(SmtpSecurity.STARTTLS, Providers.forEmail("a@icloud.com")?.smtpSecurity)
    }

    @Test fun unknownDomainHasNoPreset() {
        assertNull(Providers.forEmail("me@mycompany.org"))
        assertNull(Providers.forEmail("not-an-email"))
    }

    @Test fun warnsAboutProvidersThatCannotUsePasswordImap() {
        assertNotNull(Providers.unsupportedNote("a@outlook.com"))
        assertNotNull(Providers.unsupportedNote("a@proton.me"))
        assertNull(Providers.unsupportedNote("a@gmail.com"))
    }

    @Test fun gmailDoesNotDoubleSaveSentMail() {
        assertEquals(false, Providers.gmail.appendSent)
    }
}
