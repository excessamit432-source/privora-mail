// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (C) 2026 The PRIVORA MAIL authors. See LICENSE-NOTICE.md.
package app.privora.mail

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import app.privora.mail.core.design.Brand
import app.privora.mail.core.design.DarkExtras
import app.privora.mail.core.design.DarkScheme
import app.privora.mail.core.design.LightExtras
import app.privora.mail.core.design.LightScheme
import org.junit.Assert.assertTrue
import org.junit.Test

/** WCAG 2.x contrast guard: text >= 4.5:1, UI component boundaries >= 3:1. */
class ContrastTest {

    private fun ratio(a: Color, b: Color): Float {
        val hi = maxOf(a.luminance(), b.luminance())
        val lo = minOf(a.luminance(), b.luminance())
        return (hi + 0.05f) / (lo + 0.05f)
    }

    private fun text(name: String, fg: Color, bg: Color) =
        assertTrue("$name = ${ratio(fg, bg)} (< 4.5)", ratio(fg, bg) >= 4.5f)

    private fun ui(name: String, fg: Color, bg: Color) =
        assertTrue("$name = ${ratio(fg, bg)} (< 3.0)", ratio(fg, bg) >= 3.0f)

    @Test fun darkText() {
        val s = DarkScheme
        text("onSurface/background", s.onSurface, s.background)
        text("onSurface/containerHigh", s.onSurface, s.surfaceContainerHigh)
        text("onSurfaceVariant/container", s.onSurfaceVariant, s.surfaceContainer)
        text("onSurfaceVariant/containerHigh", s.onSurfaceVariant, s.surfaceContainerHigh)
        text("secondary/containerHigh", s.secondary, s.surfaceContainerHigh)
        text("tertiary/container", s.tertiary, s.surfaceContainer)
        text("textTertiary/container", DarkExtras.textTertiary, s.surfaceContainer)
        text("onPrimary/primary", s.onPrimary, s.primary)
        text("white/brandPurple", Color.White, Brand.Purple)
        text("success/container", DarkExtras.success, s.surfaceContainer)
        text("warning/container", DarkExtras.warning, s.surfaceContainer)
        text("onPrimaryContainer/primaryContainer", s.onPrimaryContainer, s.primaryContainer)
    }

    @Test fun darkUiComponents() {
        val s = DarkScheme
        ui("outline/background", s.outline, s.background)
        ui("outline/container", s.outline, s.surfaceContainer)
        ui("outline/containerHigh", s.outline, s.surfaceContainerHigh)
        ui("primary/background", s.primary, s.background)
    }

    @Test fun lightText() {
        val s = LightScheme
        text("onSurface/background", s.onSurface, s.background)
        text("onSurfaceVariant/container", s.onSurfaceVariant, s.surfaceContainer)
        text("primary/background", s.primary, s.background)
        text("secondary/background", s.secondary, s.background)
        text("onPrimary/primary", s.onPrimary, s.primary)
        text("success/container", LightExtras.success, s.surfaceContainer)
        text("warning/container", LightExtras.warning, s.surfaceContainer)
        text("textTertiary/containerHighest", LightExtras.textTertiary, s.surfaceContainerHigh)
    }

    @Test fun lightUiComponents() {
        val s = LightScheme
        ui("outline/background", s.outline, s.background)
        ui("outline/container", s.outline, s.surfaceContainer)
    }

    /** Documents WHY derived tokens exist: raw brand colors fail AA in these pairings. */
    @Test fun rawBrandColorsThatFailAreNotUsedForText() {
        assertTrue(ratio(Color.White, Brand.ElectricBlue) < 4.5f)       // button label on raw blue
        assertTrue(ratio(Brand.Cyan, LightScheme.background) < 3.0f)    // cyan text in light theme
    }
}
