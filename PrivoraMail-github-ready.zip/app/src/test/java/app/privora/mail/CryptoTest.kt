// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (C) 2026 The PRIVORA MAIL authors. See LICENSE-NOTICE.md.
package app.privora.mail

import app.privora.mail.core.crypto.CryptoException
import app.privora.mail.core.crypto.PrivoraCrypto
import app.privora.mail.core.crypto.Verification
import app.privora.mail.core.crypto.WrongPassphraseException
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.BeforeClass
import org.junit.Test

/** End-to-end round trips of the OpenPGP layer, run on the JVM. RSA-3072 + Argon2id make these take a few seconds. */
class CryptoTest {
    companion object {
        lateinit var alice: app.privora.mail.core.crypto.NewKey
        lateinit var bob: app.privora.mail.core.crypto.NewKey

        @BeforeClass @JvmStatic fun setUp() {
            alice = PrivoraCrypto.createKey("alice@privora.email", "correct horse battery staple")
            bob = PrivoraCrypto.createKey("bob@privora.email", "another long passphrase here")
        }
    }

    @Test fun encryptedForBobIsReadableByBobAndSignatureVerifies() {
        val armored = PrivoraCrypto.encryptSigned(
            "Hello Bob, this is secret.", listOf(bob.unlocked.publicRing, alice.unlocked.publicRing), alice.unlocked
        )
        assertTrue(armored.contains("BEGIN PGP MESSAGE"))
        assertFalse("ciphertext must not contain the plaintext", armored.contains("secret"))
        val result = PrivoraCrypto.decrypt(armored, bob.unlocked, listOf(alice.unlocked.publicRing))
        assertEquals("Hello Bob, this is secret.", result.text)
        assertEquals(Verification.Verified, result.verification)
    }

    @Test fun senderCanReadTheirOwnSentCopy() {
        val armored = PrivoraCrypto.encryptSigned("note", listOf(bob.unlocked.publicRing, alice.unlocked.publicRing), alice.unlocked)
        assertEquals("note", PrivoraCrypto.decrypt(armored, alice.unlocked, listOf(alice.unlocked.publicRing)).text)
    }

    @Test fun aThirdPartyCannotDecrypt() {
        val armored = PrivoraCrypto.encryptSigned("for bob only", listOf(bob.unlocked.publicRing), alice.unlocked)
        try {
            PrivoraCrypto.decrypt(armored, alice.unlocked, emptyList())
            fail("Alice must not be able to read a message encrypted only to Bob")
        } catch (e: CryptoException) {
            assertTrue(e.message!!.contains("wasn't encrypted to your key"))
        }
    }

    @Test fun unknownSenderIsReportedAsUnverifiedNotVerified() {
        val armored = PrivoraCrypto.encryptSigned("hi", listOf(bob.unlocked.publicRing), alice.unlocked)
        assertEquals(Verification.SignerUnknown, PrivoraCrypto.decrypt(armored, bob.unlocked, emptyList()).verification)
    }

    @Test fun wrongSendersKeyDoesNotVerify() {
        val armored = PrivoraCrypto.encryptSigned("hi", listOf(bob.unlocked.publicRing), alice.unlocked)
        // Presenting Bob's key as if it were Alice's: the signer key id is not found, so it must not verify.
        assertTrue(PrivoraCrypto.decrypt(armored, bob.unlocked, listOf(bob.unlocked.publicRing)).verification != Verification.Verified)
    }

    @Test fun backupUnlocksWithRightPassphraseOnly() {
        val ok = PrivoraCrypto.unlock("alice@privora.email", alice.blobJson, "correct horse battery staple")
        assertNotNull(ok)
        try {
            PrivoraCrypto.unlock("alice@privora.email", alice.blobJson, "wrong passphrase!!")
            fail("wrong passphrase must be rejected")
        } catch (e: WrongPassphraseException) { /* expected */ }
    }

    @Test fun backupBlobNeverContainsAPlainKeyOrThePassphrase() {
        assertFalse(alice.blobJson.contains("correct horse"))
        assertTrue(alice.blobJson.contains("\"kdf\":\"argon2id\""))
        // the armored private key inside is S2K-protected: loading it without the derived secret must fail
        try {
            PrivoraCrypto.unlock("alice@privora.email", alice.blobJson, "")
            fail("empty passphrase must not unlock")
        } catch (e: WrongPassphraseException) { /* expected */ }
    }

    @Test fun changingPassphraseKeepsTheSameKey() {
        val changed = PrivoraCrypto.changePassphrase("bob@privora.email", bob.blobJson, "another long passphrase here", "a brand new passphrase 2")
        assertEquals(PrivoraCrypto.fingerprint(bob.unlocked.publicRing), PrivoraCrypto.fingerprint(changed.unlocked.publicRing))
        try {
            PrivoraCrypto.unlock("bob@privora.email", changed.blobJson, "another long passphrase here")
            fail("old passphrase must stop working")
        } catch (e: WrongPassphraseException) { /* expected */ }
        assertNotNull(PrivoraCrypto.unlock("bob@privora.email", changed.blobJson, "a brand new passphrase 2"))
    }

    @Test fun findsArmoredBlockInsideAMailBody() {
        val body = "preface\n-----BEGIN PGP MESSAGE-----\nabc\n-----END PGP MESSAGE-----\nsignature"
        assertNotNull(PrivoraCrypto.extractArmoredMessage(body))
        assertNull(PrivoraCrypto.extractArmoredMessage("just a normal email"))
    }

    @Test fun publicKeyRoundTripsAndFingerprintIsStable() {
        val parsed = PrivoraCrypto.parsePublic(alice.publicArmored)
        assertEquals(PrivoraCrypto.fingerprint(alice.unlocked.publicRing), PrivoraCrypto.fingerprint(parsed))
    }
}
