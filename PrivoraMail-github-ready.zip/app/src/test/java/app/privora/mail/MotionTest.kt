// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (C) 2026 The PRIVORA MAIL authors. See LICENSE-NOTICE.md.
package app.privora.mail

import app.privora.mail.core.design.MotionMode
import app.privora.mail.core.design.MotionTokens
import app.privora.mail.core.design.PrivoraMotion
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MotionTest {
    @Test fun fullUsesSpecDurations() {
        val m = PrivoraMotion(MotionMode.Full)
        assertEquals(MotionTokens.Screen, m.ms(MotionTokens.Screen))
        assertTrue(m.allowsDecorativeMotion)
    }

    @Test fun reducedHalvesDurationsAndDisablesDecoration() {
        val m = PrivoraMotion(MotionMode.Reduced)
        assertEquals(MotionTokens.Standard / 2, m.ms(MotionTokens.Standard))
        assertFalse(m.allowsDecorativeMotion)
    }

    @Test fun minimalIsInstant() {
        val m = PrivoraMotion(MotionMode.Minimal)
        assertEquals(0, m.ms(MotionTokens.Entrance))
        assertFalse(m.allowsDecorativeMotion)
    }

    @Test fun tokensRespectSpecRanges() {
        assertTrue(MotionTokens.Micro in 120..180)
        assertTrue(MotionTokens.Standard in 250..300)
        assertTrue(MotionTokens.Screen in 200..350)
    }
}
