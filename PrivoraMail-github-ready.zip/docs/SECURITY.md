# Security statement (version 0.3.0)

Rule: this file and `PrivacyScreen.kt` must list only what the code enforces. Update both whenever a feature ships.
**Not independently audited. The encryption layer is new and has only had its own unit tests.**

## Enforced now
- **End-to-end encryption between PRIVORA users.** When every recipient is a PRIVORA user with a published key, the body is signed and
  encrypted on the device (OpenPGP, RSA-3072, AES-256, SHA-256) to each recipient and to the sender. The server stores ciphertext only.
- **Zero-knowledge key backup.** The encryption passphrase is stretched with Argon2id (64 MiB, 3 passes, random 16-byte salt) into a 256-bit secret
  that protects the private key. Only the protected key and salt are uploaded. The passphrase and the unprotected key never leave the device.
- **Keys exist unlocked in memory only.** Closing the app or tapping "Lock" discards them.
- **Honest badges.** "Encrypted" is shown only after a message was actually decrypted; signature status is shown separately
  (verified / sender unknown / failed). Before sending to anyone who cannot receive encrypted mail, the user must confirm sending unencrypted.
- Mail connections (IMAP/SMTP) always use TLS with server-identity verification; no plain-text fallback. The key service is reached over HTTPS only.
- The mailbox password is encrypted with an AES-256-GCM key in the Android Keystore; never logged.
- Mail is displayed as plain text: remote images, tracking pixels and scripts never load. No email content is written to disk.
- Optional app lock (system biometric / device credential) and screenshot / app-switcher protection.
- No analytics, ad or crash-reporting SDKs. Backups disabled. Only permission: INTERNET.

## Not protected / not implemented (do not claim)
- Mail to or from other providers is NOT end-to-end encrypted (their servers read it).
- Subject, sender, recipients and date are visible to the server. Recipient key IDs are visible inside the encrypted message.
- The mail server sees the mailbox password at login (IMAP/SMTP require it). This is why the encryption passphrase is separate.
- Search covers subject and sender only; message text is ciphertext on the server.
- No two-step login, security keys, recovery email/phone, trusted devices or sessions (server features that do not exist yet).
- Key trust: the key directory is operator-run. A malicious or compromised server could publish a wrong public key for someone.
  Users should compare fingerprints (Settings, Encryption keys). Key transparency is future work.
- No encrypted attachments, drafts, or offline cache.

## Known caveats
- The dev debug keystore (`app/debug-dev.keystore`, password `android`) is public on purpose so CI builds are signed consistently. Never use it for a store release.
- A forgotten encryption passphrase cannot be recovered by anyone.
- App lock is only as strong as the device screen lock.
- Not yet tested against a live PRIVORA server.
