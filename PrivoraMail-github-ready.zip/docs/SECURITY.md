# Security statement (this build)

Rule: this file and `PrivacyScreen.kt` must list only what the code enforces. Update both whenever a feature ships.

## Enforced now
- Cleartext HTTP blocked; system trust anchors only (`network_security_config.xml`).
- `allowBackup=false` plus data-extraction rules excluding all domains (no cloud backup / device transfer of app data).
- No analytics, advertising or crash-reporting SDKs in the dependency graph.
- No Android permissions declared. (INTERNET is added with mail sync.)
- Stored data is non-sensitive UI preferences only (theme, motion, onboarding flag) in DataStore.

## Not implemented (do not claim)
- Encryption at rest, Android Keystore key management, SQLCipher
- App lock / biometrics, session management, trusted devices
- End-to-end encryption. When built, it applies only between PRIVORA accounts (or via PGP); it cannot apply to mail exchanged with other providers.
- Tracking protection (remote-image blocking, link cleaning)

## Rules for contributors
- Use established libraries only; never custom cryptography.
- Never commit secrets, keystores, `google-services.json` or OAuth client secrets.
- Never log message content, addresses or tokens.
- Distinguish transport encryption, encryption at rest and end-to-end encryption in all UI copy.
