# Security statement (version 0.2.0)

Rule: this file and `PrivacyScreen.kt` must list only what the code enforces. Update both whenever a feature ships.

## Enforced now
- Mail connections (IMAP and SMTP) always use TLS: implicit SSL, or STARTTLS with `starttls.required`. Server identity (hostname) is verified (`ssl.checkserveridentity`). No trust-all sockets and no plain-text fallback.
- Mail passwords are encrypted with an AES-256-GCM key stored in the Android Keystore (`SecretBox`). They are decrypted only in memory when connecting, never logged, never stored in plain text.
- Email is displayed as plain text. HTML is converted to text, so remote images, tracking pixels and scripts never load.
- No email content is written to disk. Messages live in memory only.
- Optional app lock (system biometric prompt with device-credential fallback) with a configurable timeout. Optional screenshot and app-switcher protection (FLAG_SECURE).
- Cleartext HTTP blocked; `allowBackup=false` with data-extraction rules excluding all data; no analytics, ad or crash-reporting SDKs.
- Only permission: INTERNET.
- Deleting a message refuses to run if no Trash folder is found, to avoid accidental permanent loss.

## Not implemented (do not claim)
- End-to-end encryption. Ordinary email between providers cannot be end-to-end encrypted.
- PRIVORA-owned accounts: its own two-step verification, security keys, recovery email/phone, trusted devices, sessions. These need a backend that does not exist.
- OAuth sign-in (Outlook/Hotmail and "Sign in with Google" are unsupported; Gmail uses app passwords).
- Encrypted offline cache, push notifications, attachment download/upload.

## Known caveats
- The dev debug keystore (`app/debug-dev.keystore`, password `android`) is public on purpose so CI builds are signed consistently. It must never be used for a store release.
- App lock is only as strong as the device screen lock.
- Real-server behaviour (Gmail/Yahoo/iCloud/custom) has not been tested by the developer; see README.
